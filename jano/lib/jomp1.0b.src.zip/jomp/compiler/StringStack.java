/*  1:   */ package jomp.compiler;
/*  2:   */ 
/*  3:   */ public class StringStack
/*  4:   */ {
/*  5: 9 */   StringStack next = null;
/*  6:   */   String myString;
/*  7:13 */   boolean isInUse = false;
/*  8:15 */   StringStack pos = null;
/*  9:   */   
/* 10:   */   public void PushNameList(ASTVarNameList paramASTVarNameList)
/* 11:   */   {
/* 12:22 */     for (int i = 0; i < paramASTVarNameList.jjtGetNumChildren(); i++) {
/* 13:23 */       Push(((SimpleNode)paramASTVarNameList.jjtGetChild(i)).getFirstToken().toString());
/* 14:   */     }
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void Push(String paramString)
/* 18:   */   {
/* 19:32 */     this.pos = this;
/* 20:33 */     if (this.isInUse)
/* 21:   */     {
/* 22:34 */       StringStack localStringStack = new StringStack();
/* 23:35 */       localStringStack.isInUse = true;
/* 24:36 */       localStringStack.next = this.next;
/* 25:37 */       localStringStack.myString = this.myString;
/* 26:38 */       this.next = localStringStack;
/* 27:   */     }
/* 28:   */     else
/* 29:   */     {
/* 30:40 */       this.isInUse = true;
/* 31:   */     }
/* 32:42 */     this.myString = paramString;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public String Pop()
/* 36:   */   {
/* 37:50 */     String str = this.myString;
/* 38:51 */     if (this.next == null)
/* 39:   */     {
/* 40:52 */       this.isInUse = false;
/* 41:53 */       this.myString = null;
/* 42:   */     }
/* 43:   */     else
/* 44:   */     {
/* 45:55 */       this.myString = this.next.myString;
/* 46:56 */       this.next = this.next.next;
/* 47:   */     }
/* 48:58 */     return str;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public String Cycle()
/* 52:   */   {
/* 53:66 */     if ((this.pos == null) || (!this.pos.isInUse)) {
/* 54:67 */       return null;
/* 55:   */     }
/* 56:69 */     String str = this.pos.myString;
/* 57:70 */     this.pos = this.pos.next;
/* 58:71 */     return str;
/* 59:   */   }
/* 60:   */   
/* 61:   */   public void Recycle()
/* 62:   */   {
/* 63:79 */     this.pos = this;
/* 64:   */   }
/* 65:   */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.compiler.StringStack
 * JD-Core Version:    0.7.0.1
 */