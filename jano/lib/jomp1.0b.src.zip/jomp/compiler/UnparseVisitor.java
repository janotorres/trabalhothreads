/*   1:    */ package jomp.compiler;
/*   2:    */ 
/*   3:    */ import java.io.PrintWriter;
/*   4:    */ 
/*   5:    */ public class UnparseVisitor
/*   6:    */   implements JavaParserVisitor
/*   7:    */ {
/*   8:    */   protected PrintWriter out;
/*   9:    */   
/*  10:    */   public UnparseVisitor(PrintWriter paramPrintWriter)
/*  11:    */   {
/*  12: 13 */     this.out = paramPrintWriter;
/*  13:    */   }
/*  14:    */   
/*  15:    */   public PrintWriter swapOut(PrintWriter paramPrintWriter)
/*  16:    */   {
/*  17: 17 */     PrintWriter localPrintWriter = this.out;
/*  18: 18 */     this.out = paramPrintWriter;
/*  19: 19 */     return localPrintWriter;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public Object print(SimpleNode paramSimpleNode, Object paramObject)
/*  23:    */   {
/*  24: 24 */     Token localToken1 = paramSimpleNode.getFirstToken();
/*  25: 25 */     Token localToken2 = new Token();
/*  26: 26 */     localToken2.next = localToken1;
/*  27: 29 */     for (int i = 0; i < paramSimpleNode.jjtGetNumChildren(); i++)
/*  28:    */     {
/*  29: 30 */       SimpleNode localSimpleNode = (SimpleNode)paramSimpleNode.jjtGetChild(i);
/*  30:    */       for (;;)
/*  31:    */       {
/*  32: 32 */         localToken2 = localToken2.next;
/*  33: 33 */         if (localToken2 == localSimpleNode.getFirstToken()) {
/*  34:    */           break;
/*  35:    */         }
/*  36: 34 */         print(localToken2);
/*  37:    */       }
/*  38: 36 */       localSimpleNode.jjtAccept(this, paramObject);
/*  39: 37 */       localToken2 = localSimpleNode.getLastToken();
/*  40:    */     }
/*  41: 40 */     while (localToken2 != paramSimpleNode.getLastToken())
/*  42:    */     {
/*  43: 41 */       localToken2 = localToken2.next;
/*  44: 42 */       print(localToken2);
/*  45:    */     }
/*  46: 44 */     return paramObject;
/*  47:    */   }
/*  48:    */   
/*  49:    */   protected void print(Token paramToken)
/*  50:    */   {
/*  51: 49 */     Token localToken = paramToken.specialToken;
/*  52: 50 */     if (localToken != null)
/*  53:    */     {
/*  54: 51 */       while (localToken.specialToken != null) {
/*  55: 51 */         localToken = localToken.specialToken;
/*  56:    */       }
/*  57: 52 */       while (localToken != null)
/*  58:    */       {
/*  59: 53 */         this.out.print(addUnicodeEscapes(localToken.image));
/*  60: 54 */         localToken = localToken.next;
/*  61:    */       }
/*  62:    */     }
/*  63: 57 */     this.out.print(addUnicodeEscapes(paramToken.image));
/*  64:    */   }
/*  65:    */   
/*  66:    */   private String addUnicodeEscapes(String paramString)
/*  67:    */   {
/*  68: 62 */     String str1 = "";
/*  69: 64 */     for (int i = 0; i < paramString.length(); i++)
/*  70:    */     {
/*  71: 65 */       char c = paramString.charAt(i);
/*  72: 66 */       if (((c < ' ') || (c > '~')) && (c != '\t') && (c != '\n') && (c != '\r') && (c != '\f'))
/*  73:    */       {
/*  74: 68 */         String str2 = "0000" + Integer.toString(c, 16);
/*  75: 69 */         str1 = str1 + "\\u" + str2.substring(str2.length() - 4, str2.length());
/*  76:    */       }
/*  77:    */       else
/*  78:    */       {
/*  79: 71 */         str1 = str1 + c;
/*  80:    */       }
/*  81:    */     }
/*  82: 74 */     return str1;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public Object visit(SimpleNode paramSimpleNode, Object paramObject)
/*  86:    */   {
/*  87: 80 */     return print(paramSimpleNode, paramObject);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public Object visit(ASTCompilationUnit paramASTCompilationUnit, Object paramObject)
/*  91:    */   {
/*  92: 85 */     return print(paramASTCompilationUnit, paramObject);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public Object visit(ASTPackageDeclaration paramASTPackageDeclaration, Object paramObject)
/*  96:    */   {
/*  97: 90 */     return print(paramASTPackageDeclaration, paramObject);
/*  98:    */   }
/*  99:    */   
/* 100:    */   public Object visit(ASTImportDeclaration paramASTImportDeclaration, Object paramObject)
/* 101:    */   {
/* 102: 95 */     return print(paramASTImportDeclaration, paramObject);
/* 103:    */   }
/* 104:    */   
/* 105:    */   public Object visit(ASTTypeDeclaration paramASTTypeDeclaration, Object paramObject)
/* 106:    */   {
/* 107:100 */     return print(paramASTTypeDeclaration, paramObject);
/* 108:    */   }
/* 109:    */   
/* 110:    */   public Object visit(ASTClassDeclaration paramASTClassDeclaration, Object paramObject)
/* 111:    */   {
/* 112:105 */     return print(paramASTClassDeclaration, paramObject);
/* 113:    */   }
/* 114:    */   
/* 115:    */   public Object visit(ASTUnmodifiedClassDeclaration paramASTUnmodifiedClassDeclaration, Object paramObject)
/* 116:    */   {
/* 117:110 */     return print(paramASTUnmodifiedClassDeclaration, paramObject);
/* 118:    */   }
/* 119:    */   
/* 120:    */   public Object visit(ASTClassBody paramASTClassBody, Object paramObject)
/* 121:    */   {
/* 122:115 */     return print(paramASTClassBody, paramObject);
/* 123:    */   }
/* 124:    */   
/* 125:    */   public Object visit(ASTNestedClassDeclaration paramASTNestedClassDeclaration, Object paramObject)
/* 126:    */   {
/* 127:120 */     return print(paramASTNestedClassDeclaration, paramObject);
/* 128:    */   }
/* 129:    */   
/* 130:    */   public Object visit(ASTClassBodyDeclaration paramASTClassBodyDeclaration, Object paramObject)
/* 131:    */   {
/* 132:125 */     return print(paramASTClassBodyDeclaration, paramObject);
/* 133:    */   }
/* 134:    */   
/* 135:    */   public Object visit(ASTMethodDeclarationLookahead paramASTMethodDeclarationLookahead, Object paramObject)
/* 136:    */   {
/* 137:130 */     return print(paramASTMethodDeclarationLookahead, paramObject);
/* 138:    */   }
/* 139:    */   
/* 140:    */   public Object visit(ASTInterfaceDeclaration paramASTInterfaceDeclaration, Object paramObject)
/* 141:    */   {
/* 142:135 */     return print(paramASTInterfaceDeclaration, paramObject);
/* 143:    */   }
/* 144:    */   
/* 145:    */   public Object visit(ASTNestedInterfaceDeclaration paramASTNestedInterfaceDeclaration, Object paramObject)
/* 146:    */   {
/* 147:140 */     return print(paramASTNestedInterfaceDeclaration, paramObject);
/* 148:    */   }
/* 149:    */   
/* 150:    */   public Object visit(ASTUnmodifiedInterfaceDeclaration paramASTUnmodifiedInterfaceDeclaration, Object paramObject)
/* 151:    */   {
/* 152:145 */     return print(paramASTUnmodifiedInterfaceDeclaration, paramObject);
/* 153:    */   }
/* 154:    */   
/* 155:    */   public Object visit(ASTInterfaceMemberDeclaration paramASTInterfaceMemberDeclaration, Object paramObject)
/* 156:    */   {
/* 157:150 */     return print(paramASTInterfaceMemberDeclaration, paramObject);
/* 158:    */   }
/* 159:    */   
/* 160:    */   public Object visit(ASTFieldDeclaration paramASTFieldDeclaration, Object paramObject)
/* 161:    */   {
/* 162:155 */     return print(paramASTFieldDeclaration, paramObject);
/* 163:    */   }
/* 164:    */   
/* 165:    */   public Object visit(ASTVariableDeclarator paramASTVariableDeclarator, Object paramObject)
/* 166:    */   {
/* 167:160 */     return print(paramASTVariableDeclarator, paramObject);
/* 168:    */   }
/* 169:    */   
/* 170:    */   public Object visit(ASTVariableDeclaratorId paramASTVariableDeclaratorId, Object paramObject)
/* 171:    */   {
/* 172:165 */     return print(paramASTVariableDeclaratorId, paramObject);
/* 173:    */   }
/* 174:    */   
/* 175:    */   public Object visit(ASTVariableInitializer paramASTVariableInitializer, Object paramObject)
/* 176:    */   {
/* 177:170 */     return print(paramASTVariableInitializer, paramObject);
/* 178:    */   }
/* 179:    */   
/* 180:    */   public Object visit(ASTArrayInitializer paramASTArrayInitializer, Object paramObject)
/* 181:    */   {
/* 182:175 */     return print(paramASTArrayInitializer, paramObject);
/* 183:    */   }
/* 184:    */   
/* 185:    */   public Object visit(ASTMethodDeclaration paramASTMethodDeclaration, Object paramObject)
/* 186:    */   {
/* 187:180 */     return print(paramASTMethodDeclaration, paramObject);
/* 188:    */   }
/* 189:    */   
/* 190:    */   public Object visit(ASTMethodDeclarator paramASTMethodDeclarator, Object paramObject)
/* 191:    */   {
/* 192:185 */     return print(paramASTMethodDeclarator, paramObject);
/* 193:    */   }
/* 194:    */   
/* 195:    */   public Object visit(ASTFormalParameters paramASTFormalParameters, Object paramObject)
/* 196:    */   {
/* 197:190 */     return print(paramASTFormalParameters, paramObject);
/* 198:    */   }
/* 199:    */   
/* 200:    */   public Object visit(ASTFormalParameter paramASTFormalParameter, Object paramObject)
/* 201:    */   {
/* 202:195 */     return print(paramASTFormalParameter, paramObject);
/* 203:    */   }
/* 204:    */   
/* 205:    */   public Object visit(ASTConstructorDeclaration paramASTConstructorDeclaration, Object paramObject)
/* 206:    */   {
/* 207:200 */     return print(paramASTConstructorDeclaration, paramObject);
/* 208:    */   }
/* 209:    */   
/* 210:    */   public Object visit(ASTExplicitConstructorInvocation paramASTExplicitConstructorInvocation, Object paramObject)
/* 211:    */   {
/* 212:205 */     return print(paramASTExplicitConstructorInvocation, paramObject);
/* 213:    */   }
/* 214:    */   
/* 215:    */   public Object visit(ASTInitializer paramASTInitializer, Object paramObject)
/* 216:    */   {
/* 217:210 */     return print(paramASTInitializer, paramObject);
/* 218:    */   }
/* 219:    */   
/* 220:    */   public Object visit(ASTType paramASTType, Object paramObject)
/* 221:    */   {
/* 222:215 */     return print(paramASTType, paramObject);
/* 223:    */   }
/* 224:    */   
/* 225:    */   public Object visit(ASTPrimitiveType paramASTPrimitiveType, Object paramObject)
/* 226:    */   {
/* 227:220 */     return print(paramASTPrimitiveType, paramObject);
/* 228:    */   }
/* 229:    */   
/* 230:    */   public Object visit(ASTResultType paramASTResultType, Object paramObject)
/* 231:    */   {
/* 232:225 */     return print(paramASTResultType, paramObject);
/* 233:    */   }
/* 234:    */   
/* 235:    */   public Object visit(ASTName paramASTName, Object paramObject)
/* 236:    */   {
/* 237:230 */     return print(paramASTName, paramObject);
/* 238:    */   }
/* 239:    */   
/* 240:    */   public Object visit(ASTNameList paramASTNameList, Object paramObject)
/* 241:    */   {
/* 242:235 */     return print(paramASTNameList, paramObject);
/* 243:    */   }
/* 244:    */   
/* 245:    */   public Object visit(ASTExpression paramASTExpression, Object paramObject)
/* 246:    */   {
/* 247:240 */     return print(paramASTExpression, paramObject);
/* 248:    */   }
/* 249:    */   
/* 250:    */   public Object visit(ASTAssignmentOperator paramASTAssignmentOperator, Object paramObject)
/* 251:    */   {
/* 252:245 */     return print(paramASTAssignmentOperator, paramObject);
/* 253:    */   }
/* 254:    */   
/* 255:    */   public Object visit(ASTConditionalExpression paramASTConditionalExpression, Object paramObject)
/* 256:    */   {
/* 257:250 */     return print(paramASTConditionalExpression, paramObject);
/* 258:    */   }
/* 259:    */   
/* 260:    */   public Object visit(ASTConditionalOrExpression paramASTConditionalOrExpression, Object paramObject)
/* 261:    */   {
/* 262:255 */     return print(paramASTConditionalOrExpression, paramObject);
/* 263:    */   }
/* 264:    */   
/* 265:    */   public Object visit(ASTConditionalAndExpression paramASTConditionalAndExpression, Object paramObject)
/* 266:    */   {
/* 267:260 */     return print(paramASTConditionalAndExpression, paramObject);
/* 268:    */   }
/* 269:    */   
/* 270:    */   public Object visit(ASTInclusiveOrExpression paramASTInclusiveOrExpression, Object paramObject)
/* 271:    */   {
/* 272:265 */     return print(paramASTInclusiveOrExpression, paramObject);
/* 273:    */   }
/* 274:    */   
/* 275:    */   public Object visit(ASTExclusiveOrExpression paramASTExclusiveOrExpression, Object paramObject)
/* 276:    */   {
/* 277:270 */     return print(paramASTExclusiveOrExpression, paramObject);
/* 278:    */   }
/* 279:    */   
/* 280:    */   public Object visit(ASTAndExpression paramASTAndExpression, Object paramObject)
/* 281:    */   {
/* 282:275 */     return print(paramASTAndExpression, paramObject);
/* 283:    */   }
/* 284:    */   
/* 285:    */   public Object visit(ASTEqualityExpression paramASTEqualityExpression, Object paramObject)
/* 286:    */   {
/* 287:280 */     return print(paramASTEqualityExpression, paramObject);
/* 288:    */   }
/* 289:    */   
/* 290:    */   public Object visit(ASTInstanceOfExpression paramASTInstanceOfExpression, Object paramObject)
/* 291:    */   {
/* 292:285 */     return print(paramASTInstanceOfExpression, paramObject);
/* 293:    */   }
/* 294:    */   
/* 295:    */   public Object visit(ASTRelationalExpression paramASTRelationalExpression, Object paramObject)
/* 296:    */   {
/* 297:290 */     return print(paramASTRelationalExpression, paramObject);
/* 298:    */   }
/* 299:    */   
/* 300:    */   public Object visit(ASTShiftExpression paramASTShiftExpression, Object paramObject)
/* 301:    */   {
/* 302:295 */     return print(paramASTShiftExpression, paramObject);
/* 303:    */   }
/* 304:    */   
/* 305:    */   public Object visit(ASTAdditiveExpression paramASTAdditiveExpression, Object paramObject)
/* 306:    */   {
/* 307:300 */     return print(paramASTAdditiveExpression, paramObject);
/* 308:    */   }
/* 309:    */   
/* 310:    */   public Object visit(ASTMultiplicativeExpression paramASTMultiplicativeExpression, Object paramObject)
/* 311:    */   {
/* 312:305 */     return print(paramASTMultiplicativeExpression, paramObject);
/* 313:    */   }
/* 314:    */   
/* 315:    */   public Object visit(ASTUnaryExpression paramASTUnaryExpression, Object paramObject)
/* 316:    */   {
/* 317:310 */     return print(paramASTUnaryExpression, paramObject);
/* 318:    */   }
/* 319:    */   
/* 320:    */   public Object visit(ASTPreIncrementExpression paramASTPreIncrementExpression, Object paramObject)
/* 321:    */   {
/* 322:315 */     return print(paramASTPreIncrementExpression, paramObject);
/* 323:    */   }
/* 324:    */   
/* 325:    */   public Object visit(ASTPreDecrementExpression paramASTPreDecrementExpression, Object paramObject)
/* 326:    */   {
/* 327:320 */     return print(paramASTPreDecrementExpression, paramObject);
/* 328:    */   }
/* 329:    */   
/* 330:    */   public Object visit(ASTUnaryExpressionNotPlusMinus paramASTUnaryExpressionNotPlusMinus, Object paramObject)
/* 331:    */   {
/* 332:325 */     return print(paramASTUnaryExpressionNotPlusMinus, paramObject);
/* 333:    */   }
/* 334:    */   
/* 335:    */   public Object visit(ASTCastLookahead paramASTCastLookahead, Object paramObject)
/* 336:    */   {
/* 337:330 */     return print(paramASTCastLookahead, paramObject);
/* 338:    */   }
/* 339:    */   
/* 340:    */   public Object visit(ASTPostfixExpression paramASTPostfixExpression, Object paramObject)
/* 341:    */   {
/* 342:335 */     return print(paramASTPostfixExpression, paramObject);
/* 343:    */   }
/* 344:    */   
/* 345:    */   public Object visit(ASTCastExpression paramASTCastExpression, Object paramObject)
/* 346:    */   {
/* 347:340 */     return print(paramASTCastExpression, paramObject);
/* 348:    */   }
/* 349:    */   
/* 350:    */   public Object visit(ASTPrimaryExpression paramASTPrimaryExpression, Object paramObject)
/* 351:    */   {
/* 352:345 */     return print(paramASTPrimaryExpression, paramObject);
/* 353:    */   }
/* 354:    */   
/* 355:    */   public Object visit(ASTPrimaryPrefix paramASTPrimaryPrefix, Object paramObject)
/* 356:    */   {
/* 357:350 */     return print(paramASTPrimaryPrefix, paramObject);
/* 358:    */   }
/* 359:    */   
/* 360:    */   public Object visit(ASTPrimarySuffix paramASTPrimarySuffix, Object paramObject)
/* 361:    */   {
/* 362:355 */     return print(paramASTPrimarySuffix, paramObject);
/* 363:    */   }
/* 364:    */   
/* 365:    */   public Object visit(ASTLiteral paramASTLiteral, Object paramObject)
/* 366:    */   {
/* 367:360 */     return print(paramASTLiteral, paramObject);
/* 368:    */   }
/* 369:    */   
/* 370:    */   public Object visit(ASTBooleanLiteral paramASTBooleanLiteral, Object paramObject)
/* 371:    */   {
/* 372:365 */     return print(paramASTBooleanLiteral, paramObject);
/* 373:    */   }
/* 374:    */   
/* 375:    */   public Object visit(ASTNullLiteral paramASTNullLiteral, Object paramObject)
/* 376:    */   {
/* 377:370 */     return print(paramASTNullLiteral, paramObject);
/* 378:    */   }
/* 379:    */   
/* 380:    */   public Object visit(ASTArguments paramASTArguments, Object paramObject)
/* 381:    */   {
/* 382:375 */     return print(paramASTArguments, paramObject);
/* 383:    */   }
/* 384:    */   
/* 385:    */   public Object visit(ASTArgumentList paramASTArgumentList, Object paramObject)
/* 386:    */   {
/* 387:380 */     return print(paramASTArgumentList, paramObject);
/* 388:    */   }
/* 389:    */   
/* 390:    */   public Object visit(ASTAllocationExpression paramASTAllocationExpression, Object paramObject)
/* 391:    */   {
/* 392:385 */     return print(paramASTAllocationExpression, paramObject);
/* 393:    */   }
/* 394:    */   
/* 395:    */   public Object visit(ASTArrayDimsAndInits paramASTArrayDimsAndInits, Object paramObject)
/* 396:    */   {
/* 397:390 */     return print(paramASTArrayDimsAndInits, paramObject);
/* 398:    */   }
/* 399:    */   
/* 400:    */   public Object visit(ASTStatement paramASTStatement, Object paramObject)
/* 401:    */   {
/* 402:395 */     return print(paramASTStatement, paramObject);
/* 403:    */   }
/* 404:    */   
/* 405:    */   public Object visit(ASTLabeledStatement paramASTLabeledStatement, Object paramObject)
/* 406:    */   {
/* 407:400 */     return print(paramASTLabeledStatement, paramObject);
/* 408:    */   }
/* 409:    */   
/* 410:    */   public Object visit(ASTBlock paramASTBlock, Object paramObject)
/* 411:    */   {
/* 412:405 */     return print(paramASTBlock, paramObject);
/* 413:    */   }
/* 414:    */   
/* 415:    */   public Object visit(ASTBlockStatement paramASTBlockStatement, Object paramObject)
/* 416:    */   {
/* 417:410 */     return print(paramASTBlockStatement, paramObject);
/* 418:    */   }
/* 419:    */   
/* 420:    */   public Object visit(ASTLocalVariableDeclaration paramASTLocalVariableDeclaration, Object paramObject)
/* 421:    */   {
/* 422:415 */     return print(paramASTLocalVariableDeclaration, paramObject);
/* 423:    */   }
/* 424:    */   
/* 425:    */   public Object visit(ASTEmptyStatement paramASTEmptyStatement, Object paramObject)
/* 426:    */   {
/* 427:420 */     return print(paramASTEmptyStatement, paramObject);
/* 428:    */   }
/* 429:    */   
/* 430:    */   public Object visit(ASTStatementExpression paramASTStatementExpression, Object paramObject)
/* 431:    */   {
/* 432:425 */     return print(paramASTStatementExpression, paramObject);
/* 433:    */   }
/* 434:    */   
/* 435:    */   public Object visit(ASTSwitchStatement paramASTSwitchStatement, Object paramObject)
/* 436:    */   {
/* 437:430 */     return print(paramASTSwitchStatement, paramObject);
/* 438:    */   }
/* 439:    */   
/* 440:    */   public Object visit(ASTSwitchLabel paramASTSwitchLabel, Object paramObject)
/* 441:    */   {
/* 442:435 */     return print(paramASTSwitchLabel, paramObject);
/* 443:    */   }
/* 444:    */   
/* 445:    */   public Object visit(ASTIfStatement paramASTIfStatement, Object paramObject)
/* 446:    */   {
/* 447:440 */     return print(paramASTIfStatement, paramObject);
/* 448:    */   }
/* 449:    */   
/* 450:    */   public Object visit(ASTWhileStatement paramASTWhileStatement, Object paramObject)
/* 451:    */   {
/* 452:445 */     return print(paramASTWhileStatement, paramObject);
/* 453:    */   }
/* 454:    */   
/* 455:    */   public Object visit(ASTDoStatement paramASTDoStatement, Object paramObject)
/* 456:    */   {
/* 457:450 */     return print(paramASTDoStatement, paramObject);
/* 458:    */   }
/* 459:    */   
/* 460:    */   public Object visit(ASTForStatement paramASTForStatement, Object paramObject)
/* 461:    */   {
/* 462:455 */     return print(paramASTForStatement, paramObject);
/* 463:    */   }
/* 464:    */   
/* 465:    */   public Object visit(ASTForInit paramASTForInit, Object paramObject)
/* 466:    */   {
/* 467:460 */     return print(paramASTForInit, paramObject);
/* 468:    */   }
/* 469:    */   
/* 470:    */   public Object visit(ASTStatementExpressionList paramASTStatementExpressionList, Object paramObject)
/* 471:    */   {
/* 472:465 */     return print(paramASTStatementExpressionList, paramObject);
/* 473:    */   }
/* 474:    */   
/* 475:    */   public Object visit(ASTForUpdate paramASTForUpdate, Object paramObject)
/* 476:    */   {
/* 477:470 */     return print(paramASTForUpdate, paramObject);
/* 478:    */   }
/* 479:    */   
/* 480:    */   public Object visit(ASTBreakStatement paramASTBreakStatement, Object paramObject)
/* 481:    */   {
/* 482:475 */     return print(paramASTBreakStatement, paramObject);
/* 483:    */   }
/* 484:    */   
/* 485:    */   public Object visit(ASTContinueStatement paramASTContinueStatement, Object paramObject)
/* 486:    */   {
/* 487:480 */     return print(paramASTContinueStatement, paramObject);
/* 488:    */   }
/* 489:    */   
/* 490:    */   public Object visit(ASTReturnStatement paramASTReturnStatement, Object paramObject)
/* 491:    */   {
/* 492:485 */     return print(paramASTReturnStatement, paramObject);
/* 493:    */   }
/* 494:    */   
/* 495:    */   public Object visit(ASTThrowStatement paramASTThrowStatement, Object paramObject)
/* 496:    */   {
/* 497:490 */     return print(paramASTThrowStatement, paramObject);
/* 498:    */   }
/* 499:    */   
/* 500:    */   public Object visit(ASTSynchronizedStatement paramASTSynchronizedStatement, Object paramObject)
/* 501:    */   {
/* 502:495 */     return print(paramASTSynchronizedStatement, paramObject);
/* 503:    */   }
/* 504:    */   
/* 505:    */   public Object visit(ASTTryStatement paramASTTryStatement, Object paramObject)
/* 506:    */   {
/* 507:500 */     return print(paramASTTryStatement, paramObject);
/* 508:    */   }
/* 509:    */   
/* 510:    */   public Object visit(ASTOMPDirective paramASTOMPDirective, Object paramObject)
/* 511:    */   {
/* 512:507 */     return print(paramASTOMPDirective, paramObject);
/* 513:    */   }
/* 514:    */   
/* 515:    */   public Object visit(ASTOMPParallelDirective paramASTOMPParallelDirective, Object paramObject)
/* 516:    */   {
/* 517:511 */     return print(paramASTOMPParallelDirective, paramObject);
/* 518:    */   }
/* 519:    */   
/* 520:    */   public Object visit(ASTOMPMasterDirective paramASTOMPMasterDirective, Object paramObject)
/* 521:    */   {
/* 522:515 */     return print(paramASTOMPMasterDirective, paramObject);
/* 523:    */   }
/* 524:    */   
/* 525:    */   public Object visit(ASTOMPOrderedDirective paramASTOMPOrderedDirective, Object paramObject)
/* 526:    */   {
/* 527:519 */     return print(paramASTOMPOrderedDirective, paramObject);
/* 528:    */   }
/* 529:    */   
/* 530:    */   public Object visit(ASTOMPBarrierDirective paramASTOMPBarrierDirective, Object paramObject)
/* 531:    */   {
/* 532:523 */     return print(paramASTOMPBarrierDirective, paramObject);
/* 533:    */   }
/* 534:    */   
/* 535:    */   public Object visit(ASTOMPSingleDirective paramASTOMPSingleDirective, Object paramObject)
/* 536:    */   {
/* 537:527 */     return print(paramASTOMPSingleDirective, paramObject);
/* 538:    */   }
/* 539:    */   
/* 540:    */   public Object visit(ASTOMPForDirective paramASTOMPForDirective, Object paramObject)
/* 541:    */   {
/* 542:531 */     return print(paramASTOMPForDirective, paramObject);
/* 543:    */   }
/* 544:    */   
/* 545:    */   public Object visit(ASTOMPForStatement paramASTOMPForStatement, Object paramObject)
/* 546:    */   {
/* 547:535 */     return print(paramASTOMPForStatement, paramObject);
/* 548:    */   }
/* 549:    */   
/* 550:    */   public Object visit(ASTOMPSimpleRelation paramASTOMPSimpleRelation, Object paramObject)
/* 551:    */   {
/* 552:539 */     return print(paramASTOMPSimpleRelation, paramObject);
/* 553:    */   }
/* 554:    */   
/* 555:    */   public Object visit(ASTOMPSimpleUpdate paramASTOMPSimpleUpdate, Object paramObject)
/* 556:    */   {
/* 557:543 */     return print(paramASTOMPSimpleUpdate, paramObject);
/* 558:    */   }
/* 559:    */   
/* 560:    */   public Object visit(ASTOMPLongUpdate paramASTOMPLongUpdate, Object paramObject)
/* 561:    */   {
/* 562:547 */     return print(paramASTOMPLongUpdate, paramObject);
/* 563:    */   }
/* 564:    */   
/* 565:    */   public Object visit(ASTOMPSectionsDirective paramASTOMPSectionsDirective, Object paramObject)
/* 566:    */   {
/* 567:551 */     return print(paramASTOMPSectionsDirective, paramObject);
/* 568:    */   }
/* 569:    */   
/* 570:    */   public Object visit(ASTOMPSectionDirective paramASTOMPSectionDirective, Object paramObject)
/* 571:    */   {
/* 572:555 */     return print(paramASTOMPSectionDirective, paramObject);
/* 573:    */   }
/* 574:    */   
/* 575:    */   public Object visit(ASTOMPSectionsBlock paramASTOMPSectionsBlock, Object paramObject)
/* 576:    */   {
/* 577:559 */     return print(paramASTOMPSectionsBlock, paramObject);
/* 578:    */   }
/* 579:    */   
/* 580:    */   public Object visit(ASTOMPCriticalDirective paramASTOMPCriticalDirective, Object paramObject)
/* 581:    */   {
/* 582:563 */     return print(paramASTOMPCriticalDirective, paramObject);
/* 583:    */   }
/* 584:    */   
/* 585:    */   public Object visit(ASTOMPOnlyDirective paramASTOMPOnlyDirective, Object paramObject)
/* 586:    */   {
/* 587:567 */     return print(paramASTOMPOnlyDirective, paramObject);
/* 588:    */   }
/* 589:    */   
/* 590:    */   public Object visit(ASTOMPClauseList paramASTOMPClauseList, Object paramObject)
/* 591:    */   {
/* 592:571 */     return print(paramASTOMPClauseList, paramObject);
/* 593:    */   }
/* 594:    */   
/* 595:    */   public Object visit(ASTOMPClause paramASTOMPClause, Object paramObject)
/* 596:    */   {
/* 597:575 */     return print(paramASTOMPClause, paramObject);
/* 598:    */   }
/* 599:    */   
/* 600:    */   public Object visit(ASTOMPPrivateClause paramASTOMPPrivateClause, Object paramObject)
/* 601:    */   {
/* 602:579 */     return print(paramASTOMPPrivateClause, paramObject);
/* 603:    */   }
/* 604:    */   
/* 605:    */   public Object visit(ASTOMPFirstPrivateClause paramASTOMPFirstPrivateClause, Object paramObject)
/* 606:    */   {
/* 607:583 */     return print(paramASTOMPFirstPrivateClause, paramObject);
/* 608:    */   }
/* 609:    */   
/* 610:    */   public Object visit(ASTOMPLastPrivateClause paramASTOMPLastPrivateClause, Object paramObject)
/* 611:    */   {
/* 612:587 */     return print(paramASTOMPLastPrivateClause, paramObject);
/* 613:    */   }
/* 614:    */   
/* 615:    */   public Object visit(ASTOMPSharedClause paramASTOMPSharedClause, Object paramObject)
/* 616:    */   {
/* 617:591 */     return print(paramASTOMPSharedClause, paramObject);
/* 618:    */   }
/* 619:    */   
/* 620:    */   public Object visit(ASTOMPDefaultClause paramASTOMPDefaultClause, Object paramObject)
/* 621:    */   {
/* 622:595 */     return print(paramASTOMPDefaultClause, paramObject);
/* 623:    */   }
/* 624:    */   
/* 625:    */   public Object visit(ASTOMPNowaitClause paramASTOMPNowaitClause, Object paramObject)
/* 626:    */   {
/* 627:599 */     return print(paramASTOMPNowaitClause, paramObject);
/* 628:    */   }
/* 629:    */   
/* 630:    */   public Object visit(ASTOMPScheduleClause paramASTOMPScheduleClause, Object paramObject)
/* 631:    */   {
/* 632:603 */     return print(paramASTOMPScheduleClause, paramObject);
/* 633:    */   }
/* 634:    */   
/* 635:    */   public Object visit(ASTOMPOrderedClause paramASTOMPOrderedClause, Object paramObject)
/* 636:    */   {
/* 637:607 */     return print(paramASTOMPOrderedClause, paramObject);
/* 638:    */   }
/* 639:    */   
/* 640:    */   public Object visit(ASTOMPIfClause paramASTOMPIfClause, Object paramObject)
/* 641:    */   {
/* 642:611 */     return print(paramASTOMPIfClause, paramObject);
/* 643:    */   }
/* 644:    */   
/* 645:    */   public Object visit(ASTOMPReductionClause paramASTOMPReductionClause, Object paramObject)
/* 646:    */   {
/* 647:615 */     return print(paramASTOMPReductionClause, paramObject);
/* 648:    */   }
/* 649:    */   
/* 650:    */   public Object visit(ASTOMPReductionOp paramASTOMPReductionOp, Object paramObject)
/* 651:    */   {
/* 652:619 */     return print(paramASTOMPReductionOp, paramObject);
/* 653:    */   }
/* 654:    */   
/* 655:    */   public Object visit(ASTVarNameList paramASTVarNameList, Object paramObject)
/* 656:    */   {
/* 657:624 */     return print(paramASTVarNameList, paramObject);
/* 658:    */   }
/* 659:    */   
/* 660:    */   public Object visit(ASTVarName paramASTVarName, Object paramObject)
/* 661:    */   {
/* 662:629 */     return print(paramASTVarName, paramObject);
/* 663:    */   }
/* 664:    */   
/* 665:    */   public Object visit(ASTIdentifier paramASTIdentifier, Object paramObject)
/* 666:    */   {
/* 667:633 */     return print(paramASTIdentifier, paramObject);
/* 668:    */   }
/* 669:    */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.compiler.UnparseVisitor
 * JD-Core Version:    0.7.0.1
 */