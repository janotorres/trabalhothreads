/*   1:    */ package jomp.compiler;
/*   2:    */ 
/*   3:    */ import java.io.PrintStream;
/*   4:    */ 
/*   5:    */ public class SymbolTable
/*   6:    */ {
/*   7:    */   Symbol wp;
/*   8:    */   private Symbol currentSymbol;
/*   9:    */   
/*  10:    */   public SymbolTable()
/*  11:    */   {
/*  12: 26 */     this.currentSymbol = new Symbol();
/*  13: 27 */     this.currentSymbol.isNewScope = true;
/*  14:    */   }
/*  15:    */   
/*  16:    */   public Symbol addSymbol(String paramString)
/*  17:    */   {
/*  18: 36 */     Symbol localSymbol = new Symbol();
/*  19: 37 */     localSymbol.prev = this.currentSymbol;
/*  20: 38 */     this.currentSymbol = localSymbol;
/*  21: 39 */     this.currentSymbol.name = paramString;
/*  22: 40 */     return this.currentSymbol;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public Symbol findSymbol(String paramString)
/*  26:    */   {
/*  27: 50 */     Symbol localSymbol = this.currentSymbol;
/*  28: 51 */     while (localSymbol != null)
/*  29:    */     {
/*  30: 52 */       if ((!localSymbol.isNewScope) && (localSymbol.name.compareTo(paramString) == 0)) {
/*  31: 53 */         return localSymbol;
/*  32:    */       }
/*  33: 55 */       localSymbol = localSymbol.prev;
/*  34:    */     }
/*  35: 57 */     return null;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void getInit()
/*  39:    */   {
/*  40: 65 */     this.wp = new Symbol();
/*  41: 66 */     this.wp.prev = this.currentSymbol;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public Symbol getNext()
/*  45:    */   {
/*  46: 75 */     while (this.wp.prev != null)
/*  47:    */     {
/*  48: 76 */       this.wp = this.wp.prev;
/*  49: 77 */       if (!this.wp.isNewScope) {
/*  50: 78 */         return this.wp;
/*  51:    */       }
/*  52:    */     }
/*  53: 81 */     return null;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void addScope()
/*  57:    */   {
/*  58: 86 */     Symbol localSymbol = new Symbol();
/*  59: 87 */     localSymbol.prev = this.currentSymbol;
/*  60: 88 */     this.currentSymbol = localSymbol;
/*  61: 89 */     this.currentSymbol.isNewScope = true;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void killScope()
/*  65:    */   {
/*  66:    */     try
/*  67:    */     {
/*  68: 95 */       while (this.currentSymbol.isNewScope != true) {
/*  69: 96 */         this.currentSymbol = this.currentSymbol.prev;
/*  70:    */       }
/*  71: 98 */       this.currentSymbol = this.currentSymbol.prev;
/*  72:    */     }
/*  73:    */     catch (NullPointerException localNullPointerException)
/*  74:    */     {
/*  75:100 */       System.err.println("SymbolTable stack underflow!");
/*  76:101 */       return;
/*  77:    */     }
/*  78:    */   }
/*  79:    */   
/*  80:    */   public void dumpTable()
/*  81:    */   {
/*  82:109 */     Symbol localSymbol = this.currentSymbol;
/*  83:110 */     System.err.println("----------------------------------------");
/*  84:111 */     while (localSymbol != null)
/*  85:    */     {
/*  86:112 */       if (localSymbol.isNewScope) {
/*  87:113 */         System.err.println("NEW SCOPE");
/*  88:    */       } else {
/*  89:115 */         System.err.println(localSymbol.sig + " " + localSymbol.name);
/*  90:    */       }
/*  91:117 */       localSymbol = localSymbol.prev;
/*  92:    */     }
/*  93:119 */     System.err.println("----------------------------------------");
/*  94:    */   }
/*  95:    */   
/*  96:    */   public static class Symbol
/*  97:    */   {
/*  98:127 */     private boolean isNewScope = false;
/*  99:    */     private Symbol prev;
/* 100:132 */     public String name = null;
/* 101:134 */     public String sig = null;
/* 102:136 */     public boolean isInitialized = false;
/* 103:    */   }
/* 104:    */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.compiler.SymbolTable
 * JD-Core Version:    0.7.0.1
 */