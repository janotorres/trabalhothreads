/*   1:    */ package jomp.compiler;
/*   2:    */ 
/*   3:    */ import java.io.PrintStream;
/*   4:    */ import java.util.LinkedList;
/*   5:    */ import java.util.ListIterator;
/*   6:    */ 
/*   7:    */ public class VarTable
/*   8:    */   extends LinkedList
/*   9:    */ {
/*  10:    */   private ListIterator gIter;
/*  11:    */   private int gKind;
/*  12:    */   
/*  13:    */   int search(String paramString)
/*  14:    */   {
/*  15: 21 */     ListIterator localListIterator = listIterator(0);
/*  16: 24 */     while (localListIterator.hasNext())
/*  17:    */     {
/*  18: 25 */       VarItem localVarItem = (VarItem)localListIterator.next();
/*  19: 26 */       if (paramString.equals(localVarItem.name) == true) {
/*  20: 27 */         return localListIterator.nextIndex() - 1;
/*  21:    */       }
/*  22:    */     }
/*  23: 29 */     return -1;
/*  24:    */   }
/*  25:    */   
/*  26:    */   private void addItem(VarItem paramVarItem)
/*  27:    */   {
/*  28: 41 */     int i = search(paramVarItem.name);
/*  29: 42 */     if (i != -1)
/*  30:    */     {
/*  31: 43 */       VarItem localVarItem1 = (VarItem)get(i);
/*  32: 44 */       if ((localVarItem1.kind | paramVarItem.kind) == 6)
/*  33:    */       {
/*  34: 45 */         localVarItem1.kind = 6;
/*  35: 46 */         return;
/*  36:    */       }
/*  37: 47 */       if (localVarItem1.kind == paramVarItem.kind)
/*  38:    */       {
/*  39: 48 */         System.err.println("Why do you declare the same variable twice in the same clause??");
/*  40: 49 */         if ((localVarItem1.kind == 8) && (localVarItem1.red != paramVarItem.red)) {
/*  41: 50 */           System.err.println("Cannot use the same variable " + localVarItem1.name + " for different reductions");
/*  42:    */         }
/*  43: 51 */         return;
/*  44:    */       }
/*  45: 53 */       System.err.println("Warning - Variable " + localVarItem1.name + " appeared in more then one clause!!!");
/*  46: 54 */       return;
/*  47:    */     }
/*  48: 58 */     VarItem localVarItem2 = new VarItem();
/*  49: 59 */     localVarItem2.name = paramVarItem.name;
/*  50: 60 */     localVarItem2.type = paramVarItem.type;
/*  51: 61 */     localVarItem2.kind = paramVarItem.kind;
/*  52: 62 */     localVarItem2.red = paramVarItem.red;
/*  53: 63 */     add(localVarItem2);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void addNameList(ASTVarNameList paramASTVarNameList, int paramInt1, int paramInt2, SymbolTable paramSymbolTable)
/*  57:    */   {
/*  58: 80 */     for (int j = 0; j < paramASTVarNameList.jjtGetNumChildren(); j++)
/*  59:    */     {
/*  60: 81 */       int i = 0;
/*  61:    */       String str1;
/*  62:    */       String str2;
/*  63: 83 */       if (((SimpleNode)paramASTVarNameList.jjtGetChild(j)).jjtGetNumChildren() == 2)
/*  64:    */       {
/*  65: 84 */         str1 = ((SimpleNode)paramASTVarNameList.jjtGetChild(j).jjtGetChild(1)).getFirstToken().toString();
/*  66: 85 */         str2 = "";
/*  67: 86 */         Token localToken1 = ((SimpleNode)paramASTVarNameList.jjtGetChild(j).jjtGetChild(0)).getFirstToken();
/*  68: 87 */         Token localToken2 = ((SimpleNode)paramASTVarNameList.jjtGetChild(j).jjtGetChild(0)).getLastToken();
/*  69: 88 */         while (localToken1 != localToken2)
/*  70:    */         {
/*  71: 89 */           str2 = str2.concat(localToken1.toString());
/*  72: 90 */           localToken1 = localToken1.next;
/*  73:    */         }
/*  74: 92 */         str2 = str2.concat(localToken1.toString());
/*  75: 93 */         i |= 0x1;
/*  76:    */       }
/*  77:    */       else
/*  78:    */       {
/*  79: 96 */         str1 = ((SimpleNode)paramASTVarNameList.jjtGetChild(j).jjtGetChild(0).jjtGetChild(0)).getFirstToken().toString();
/*  80: 97 */         SymbolTable.Symbol localSymbol = paramSymbolTable.findSymbol(str1);
/*  81: 98 */         if (localSymbol == null)
/*  82:    */         {
/*  83: 99 */           System.err.println("Warning: no local variable " + str1);
/*  84:100 */           return;
/*  85:    */         }
/*  86:102 */         if (localSymbol.isInitialized) {
/*  87:103 */           i |= 0x1;
/*  88:    */         }
/*  89:104 */         str2 = localSymbol.sig;
/*  90:    */       }
/*  91:106 */       VarItem localVarItem = new VarItem();
/*  92:107 */       localVarItem.type = str2;
/*  93:108 */       localVarItem.name = str1;
/*  94:109 */       localVarItem.red = paramInt2;
/*  95:110 */       localVarItem.kind = paramInt1;
/*  96:111 */       localVarItem.flag = i;
/*  97:112 */       add(localVarItem);
/*  98:    */     }
/*  99:    */   }
/* 100:    */   
/* 101:    */   public void addShared(SymbolTable paramSymbolTable)
/* 102:    */   {
/* 103:126 */     paramSymbolTable.getInit();
/* 104:    */     SymbolTable.Symbol localSymbol;
/* 105:127 */     while ((localSymbol = paramSymbolTable.getNext()) != null)
/* 106:    */     {
/* 107:    */       int j;
/* 108:128 */       if (localSymbol.isInitialized) {
/* 109:129 */         j = 1;
/* 110:    */       } else {
/* 111:131 */         j = 0;
/* 112:    */       }
/* 113:132 */       VarItem localVarItem = new VarItem();
/* 114:133 */       localVarItem.type = localSymbol.sig;
/* 115:134 */       localVarItem.name = localSymbol.name;
/* 116:135 */       localVarItem.red = 0;
/* 117:136 */       localVarItem.kind = 16;
/* 118:137 */       localVarItem.flag = j;
/* 119:    */       
/* 120:139 */       int i = search(localVarItem.name);
/* 121:141 */       if (i == -1) {
/* 122:142 */         add(localVarItem);
/* 123:    */       }
/* 124:    */     }
/* 125:    */   }
/* 126:    */   
/* 127:    */   public void getInit(int paramInt)
/* 128:    */   {
/* 129:151 */     this.gKind = paramInt;
/* 130:152 */     this.gIter = listIterator(0);
/* 131:    */   }
/* 132:    */   
/* 133:    */   public VarItem getNext()
/* 134:    */   {
/* 135:163 */     while (this.gIter.hasNext())
/* 136:    */     {
/* 137:164 */       VarItem localVarItem = (VarItem)this.gIter.next();
/* 138:165 */       if ((localVarItem.kind & this.gKind) != 0) {
/* 139:166 */         return localVarItem;
/* 140:    */       }
/* 141:    */     }
/* 142:168 */     return null;
/* 143:    */   }
/* 144:    */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.compiler.VarTable
 * JD-Core Version:    0.7.0.1
 */