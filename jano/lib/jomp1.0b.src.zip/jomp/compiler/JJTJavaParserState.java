/*   1:    */ package jomp.compiler;
/*   2:    */ 
/*   3:    */ import java.util.Stack;
/*   4:    */ import java.util.Vector;
/*   5:    */ 
/*   6:    */ class JJTJavaParserState
/*   7:    */ {
/*   8:    */   private Stack nodes;
/*   9:    */   private Stack marks;
/*  10:    */   private int sp;
/*  11:    */   private int mk;
/*  12:    */   private boolean node_created;
/*  13:    */   
/*  14:    */   JJTJavaParserState()
/*  15:    */   {
/*  16: 14 */     this.nodes = new Stack();
/*  17: 15 */     this.marks = new Stack();
/*  18: 16 */     this.sp = 0;
/*  19: 17 */     this.mk = 0;
/*  20:    */   }
/*  21:    */   
/*  22:    */   boolean nodeCreated()
/*  23:    */   {
/*  24: 24 */     return this.node_created;
/*  25:    */   }
/*  26:    */   
/*  27:    */   void reset()
/*  28:    */   {
/*  29: 30 */     this.nodes.removeAllElements();
/*  30: 31 */     this.marks.removeAllElements();
/*  31: 32 */     this.sp = 0;
/*  32: 33 */     this.mk = 0;
/*  33:    */   }
/*  34:    */   
/*  35:    */   Node rootNode()
/*  36:    */   {
/*  37: 39 */     return (Node)this.nodes.elementAt(0);
/*  38:    */   }
/*  39:    */   
/*  40:    */   void pushNode(Node paramNode)
/*  41:    */   {
/*  42: 44 */     this.nodes.push(paramNode);
/*  43: 45 */     this.sp += 1;
/*  44:    */   }
/*  45:    */   
/*  46:    */   Node popNode()
/*  47:    */   {
/*  48: 51 */     if (--this.sp < this.mk) {
/*  49: 52 */       this.mk = ((Integer)this.marks.pop()).intValue();
/*  50:    */     }
/*  51: 54 */     return (Node)this.nodes.pop();
/*  52:    */   }
/*  53:    */   
/*  54:    */   Node peekNode()
/*  55:    */   {
/*  56: 59 */     return (Node)this.nodes.peek();
/*  57:    */   }
/*  58:    */   
/*  59:    */   int nodeArity()
/*  60:    */   {
/*  61: 65 */     return this.sp - this.mk;
/*  62:    */   }
/*  63:    */   
/*  64:    */   void clearNodeScope(Node paramNode)
/*  65:    */   {
/*  66: 70 */     while (this.sp > this.mk) {
/*  67: 71 */       popNode();
/*  68:    */     }
/*  69: 73 */     this.mk = ((Integer)this.marks.pop()).intValue();
/*  70:    */   }
/*  71:    */   
/*  72:    */   void openNodeScope(Node paramNode)
/*  73:    */   {
/*  74: 78 */     this.marks.push(new Integer(this.mk));
/*  75: 79 */     this.mk = this.sp;
/*  76: 80 */     paramNode.jjtOpen();
/*  77:    */   }
/*  78:    */   
/*  79:    */   void closeNodeScope(Node paramNode, int paramInt)
/*  80:    */   {
/*  81: 89 */     this.mk = ((Integer)this.marks.pop()).intValue();
/*  82: 90 */     while (paramInt-- > 0)
/*  83:    */     {
/*  84: 91 */       Node localNode = popNode();
/*  85: 92 */       localNode.jjtSetParent(paramNode);
/*  86: 93 */       paramNode.jjtAddChild(localNode, paramInt);
/*  87:    */     }
/*  88: 95 */     paramNode.jjtClose();
/*  89: 96 */     pushNode(paramNode);
/*  90: 97 */     this.node_created = true;
/*  91:    */   }
/*  92:    */   
/*  93:    */   void closeNodeScope(Node paramNode, boolean paramBoolean)
/*  94:    */   {
/*  95:107 */     if (paramBoolean)
/*  96:    */     {
/*  97:108 */       int i = nodeArity();
/*  98:109 */       this.mk = ((Integer)this.marks.pop()).intValue();
/*  99:110 */       while (i-- > 0)
/* 100:    */       {
/* 101:111 */         Node localNode = popNode();
/* 102:112 */         localNode.jjtSetParent(paramNode);
/* 103:113 */         paramNode.jjtAddChild(localNode, i);
/* 104:    */       }
/* 105:115 */       paramNode.jjtClose();
/* 106:116 */       pushNode(paramNode);
/* 107:117 */       this.node_created = true;
/* 108:    */     }
/* 109:    */     else
/* 110:    */     {
/* 111:119 */       this.mk = ((Integer)this.marks.pop()).intValue();
/* 112:120 */       this.node_created = false;
/* 113:    */     }
/* 114:    */   }
/* 115:    */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.compiler.JJTJavaParserState
 * JD-Core Version:    0.7.0.1
 */