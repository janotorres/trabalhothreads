/*  1:   */ package jomp.compiler;
/*  2:   */ 
/*  3:   */ import java.io.PrintStream;
/*  4:   */ 
/*  5:   */ public class ReductionType
/*  6:   */ {
/*  7:   */   public static final int PLUS = 0;
/*  8:   */   public static final int MULT = 1;
/*  9:   */   public static final int MINUS = 2;
/* 10:   */   public static final int AND = 3;
/* 11:   */   public static final int OR = 4;
/* 12:   */   public static final int BOR = 5;
/* 13:   */   public static final int BXOR = 6;
/* 14:   */   public static final int BAND = 7;
/* 15:   */   public static final int COUNT = 8;
/* 16:   */   
/* 17:   */   public static int getTypeByToken(int paramInt)
/* 18:   */   {
/* 19:28 */     switch (paramInt)
/* 20:   */     {
/* 21:   */     case 118: 
/* 22:29 */       return 0;
/* 23:   */     case 120: 
/* 24:30 */       return 1;
/* 25:   */     case 119: 
/* 26:31 */       return 0;
/* 27:   */     case 115: 
/* 28:32 */       return 3;
/* 29:   */     case 114: 
/* 30:33 */       return 4;
/* 31:   */     case 123: 
/* 32:34 */       return 5;
/* 33:   */     case 124: 
/* 34:35 */       return 6;
/* 35:   */     case 122: 
/* 36:36 */       return 7;
/* 37:   */     }
/* 38:37 */     System.err.println("Unsupported reduction operation");
/* 39:   */     
/* 40:39 */     return -1;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public static String reducerName(int paramInt, String paramString)
/* 44:   */   {
/* 45:49 */     switch (paramInt)
/* 46:   */     {
/* 47:   */     case 0: 
/* 48:50 */       return "jomp.runtime.OMP.doPlusReduce(__omp_me, " + paramString + ")";
/* 49:   */     case 1: 
/* 50:51 */       return "jomp.runtime.OMP.doMultReduce(__omp_me, " + paramString + ")";
/* 51:   */     case 3: 
/* 52:52 */       return "jomp.runtime.OMP.doAndReduce(__omp_me, " + paramString + ")";
/* 53:   */     case 4: 
/* 54:53 */       return "jomp.runtime.OMP.doOrReduce(__omp_me, " + paramString + ")";
/* 55:   */     case 5: 
/* 56:54 */       return "jomp.runtime.OMP.doBitOrReduce(__omp_me, " + paramString + ")";
/* 57:   */     case 6: 
/* 58:55 */       return "jomp.runtime.OMP.doBitXorReduce(__omp_me, " + paramString + ")";
/* 59:   */     case 7: 
/* 60:56 */       return "jomp.runtime.OMP.doBitAndReduce(__omp_me, " + paramString + ")";
/* 61:   */     }
/* 62:57 */     System.err.println("Unsupported reduction operation");
/* 63:   */     
/* 64:59 */     return "";
/* 65:   */   }
/* 66:   */   
/* 67:   */   public static String opName(int paramInt)
/* 68:   */   {
/* 69:68 */     switch (paramInt)
/* 70:   */     {
/* 71:   */     case 0: 
/* 72:69 */       return "+";
/* 73:   */     case 1: 
/* 74:70 */       return "*";
/* 75:   */     case 3: 
/* 76:71 */       return "&&";
/* 77:   */     case 4: 
/* 78:72 */       return "||";
/* 79:   */     case 5: 
/* 80:73 */       return "|";
/* 81:   */     case 6: 
/* 82:74 */       return "^";
/* 83:   */     case 7: 
/* 84:75 */       return "&";
/* 85:   */     }
/* 86:77 */     System.err.println("Unsupported reduction operation");
/* 87:   */     
/* 88:79 */     return "";
/* 89:   */   }
/* 90:   */   
/* 91:   */   public static String opDefault(int paramInt)
/* 92:   */   {
/* 93:88 */     switch (paramInt)
/* 94:   */     {
/* 95:   */     case 0: 
/* 96:89 */       return "0";
/* 97:   */     case 1: 
/* 98:90 */       return "1";
/* 99:   */     case 3: 
/* :0:91 */       return "true";
/* :1:   */     case 4: 
/* :2:92 */       return "false";
/* :3:   */     case 5: 
/* :4:93 */       return "0";
/* :5:   */     case 6: 
/* :6:94 */       return "0";
/* :7:   */     case 7: 
/* :8:95 */       return "~0";
/* :9:   */     }
/* ;0:97 */     System.err.println("Unsupported reduction operation");
/* ;1:   */     
/* ;2:99 */     return "";
/* ;3:   */   }
/* ;4:   */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.compiler.ReductionType
 * JD-Core Version:    0.7.0.1
 */