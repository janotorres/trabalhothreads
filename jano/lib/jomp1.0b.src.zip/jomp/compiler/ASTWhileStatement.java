/*  1:   */ package jomp.compiler;
/*  2:   */ 
/*  3:   */ public class ASTWhileStatement
/*  4:   */   extends SimpleNode
/*  5:   */ {
/*  6:   */   public ASTWhileStatement(int paramInt)
/*  7:   */   {
/*  8: 7 */     super(paramInt);
/*  9:   */   }
/* 10:   */   
/* 11:   */   public ASTWhileStatement(JavaParser paramJavaParser, int paramInt)
/* 12:   */   {
/* 13:11 */     super(paramJavaParser, paramInt);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public Object jjtAccept(JavaParserVisitor paramJavaParserVisitor, Object paramObject)
/* 17:   */   {
/* 18:17 */     return paramJavaParserVisitor.visit(this, paramObject);
/* 19:   */   }
/* 20:   */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.compiler.ASTWhileStatement
 * JD-Core Version:    0.7.0.1
 */