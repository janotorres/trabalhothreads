/*   1:    */ package jomp.compiler;
/*   2:    */ 
/*   3:    */ import java.io.FileInputStream;
/*   4:    */ import java.io.FileNotFoundException;
/*   5:    */ import java.io.FileWriter;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.InputStream;
/*   8:    */ import java.io.PrintStream;
/*   9:    */ import java.io.PrintWriter;
/*  10:    */ 
/*  11:    */ public class Jomp
/*  12:    */ {
/*  13:    */   public static final String version = "1.0.beta";
/*  14:    */   
/*  15:    */   public static class Options
/*  16:    */   {
/*  17:  9 */     public static int schedMode = 50;
/*  18: 10 */     public static boolean noCompile = true;
/*  19: 11 */     public static boolean keepJava = false;
/*  20: 12 */     public static boolean sequential = false;
/*  21: 13 */     public static StringStack classes = new StringStack();
/*  22: 14 */     public static int numProcs = 8;
/*  23: 15 */     public static boolean verbose = false;
/*  24: 16 */     public static int messageLevel = 12;
/*  25: 17 */     public static boolean debugLoops = false;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public static void message(int paramInt, String paramString)
/*  29:    */   {
/*  30: 31 */     if (paramInt <= Options.messageLevel) {
/*  31: 32 */       System.err.println(paramString);
/*  32:    */     }
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static void main(String[] paramArrayOfString)
/*  36:    */   {
/*  37: 37 */     message(4, "Jomp Version 1.0.beta.");
/*  38:    */     
/*  39: 39 */     int i = 0;
/*  40: 41 */     if (paramArrayOfString.length == 0)
/*  41:    */     {
/*  42: 42 */       message(2, "Usage: jomp [-lsv] [-p <procs>] [-o <outfile>] [-d <schedule>] <classes>");
/*  43: 43 */       return;
/*  44:    */     }
/*  45: 47 */     for (int j = 0; j < paramArrayOfString.length; j++) {
/*  46: 48 */       if (paramArrayOfString[j].charAt(0) == '-')
/*  47:    */       {
/*  48: 49 */         for (int k = 1; k < paramArrayOfString[j].length(); k++)
/*  49:    */         {
/*  50: 50 */           switch (i)
/*  51:    */           {
/*  52:    */           case 1: 
/*  53: 51 */             System.err.println("Warning: missing argument to command line option -o"); break;
/*  54:    */           case 2: 
/*  55: 52 */             System.err.println("Warning: missing argument to command line option -p"); break;
/*  56:    */           case 3: 
/*  57: 53 */             System.err.println("Warning: missing argument to command line option -p");
/*  58:    */           }
/*  59: 55 */           i = 0;
/*  60: 57 */           switch (paramArrayOfString[j].charAt(k))
/*  61:    */           {
/*  62:    */           case 'd': 
/*  63: 58 */             i = 3; break;
/*  64:    */           case 'j': 
/*  65: 59 */             Options.noCompile = true; break;
/*  66:    */           case 'k': 
/*  67: 60 */             Options.keepJava = true; break;
/*  68:    */           case 'l': 
/*  69: 61 */             Options.debugLoops = true; break;
/*  70:    */           case 'o': 
/*  71: 62 */             i = 1; break;
/*  72:    */           case 'p': 
/*  73: 63 */             i = 2; break;
/*  74:    */           case 's': 
/*  75: 64 */             Options.sequential = true; break;
/*  76:    */           case 'v': 
/*  77: 65 */             Options.verbose = true; break;
/*  78:    */           case 'e': 
/*  79:    */           case 'f': 
/*  80:    */           case 'g': 
/*  81:    */           case 'h': 
/*  82:    */           case 'i': 
/*  83:    */           case 'm': 
/*  84:    */           case 'n': 
/*  85:    */           case 'q': 
/*  86:    */           case 'r': 
/*  87:    */           case 't': 
/*  88:    */           case 'u': 
/*  89:    */           default: 
/*  90: 66 */             System.err.println("Warning: meaningless compiler flag -" + paramArrayOfString[j].charAt(k));
/*  91:    */           }
/*  92:    */         }
/*  93:    */       }
/*  94:    */       else
/*  95:    */       {
/*  96: 70 */         switch (i)
/*  97:    */         {
/*  98:    */         case 0: 
/*  99: 71 */           Options.classes.Push(paramArrayOfString[j]); break;
/* 100:    */         case 1: 
/* 101: 72 */           System.err.println("Not currently supported."); break;
/* 102:    */         case 2: 
/* 103:    */           try
/* 104:    */           {
/* 105: 74 */             Options.numProcs = Integer.parseInt(paramArrayOfString[j]);
/* 106:    */           }
/* 107:    */           catch (NumberFormatException localNumberFormatException)
/* 108:    */           {
/* 109: 76 */             System.err.println("Number of processors must be an integer!");
/* 110:    */           }
/* 111:    */         case 3: 
/* 112: 79 */           if (paramArrayOfString[j].compareTo("static") == 0) {
/* 113: 80 */             Options.schedMode = 50;
/* 114: 81 */           } else if (paramArrayOfString[j].compareTo("dynamic") == 0) {
/* 115: 82 */             Options.schedMode = 79;
/* 116: 83 */           } else if (paramArrayOfString[j].compareTo("guided") == 0) {
/* 117: 84 */             Options.schedMode = 80;
/* 118: 85 */           } else if (paramArrayOfString[j].compareTo("runtime") == 0) {
/* 119: 86 */             Options.schedMode = 81;
/* 120:    */           } else {
/* 121: 88 */             System.err.println("Unknown scheduling option " + paramArrayOfString[j] + " - ignored.");
/* 122:    */           }
/* 123:    */           break;
/* 124:    */         }
/* 125: 92 */         i = 0;
/* 126:    */       }
/* 127:    */     }
/* 128: 96 */     for (String str = Options.classes.Pop(); str != null; str = Options.classes.Pop())
/* 129:    */     {
/* 130: 97 */       System.err.println("Compiling class " + str + "....");
/* 131:    */       try
/* 132:    */       {
/* 133:    */         Object localObject1;
/* 134:100 */         if (Options.sequential)
/* 135:    */         {
/* 136:101 */           Runtime.getRuntime().exec("cp " + str + ".jomp " + str + ".java");
/* 137:    */         }
/* 138:    */         else
/* 139:    */         {
/* 140:103 */           localObject1 = new FileInputStream(str + ".jomp");
/* 141:    */           
/* 142:105 */           JavaParser localJavaParser = new JavaParser((InputStream)localObject1);
/* 143:    */           
/* 144:107 */           ASTCompilationUnit localASTCompilationUnit = localJavaParser.CompilationUnit();
/* 145:108 */           PrintWriter localPrintWriter = new PrintWriter(new FileWriter(str + ".java"));
/* 146:    */           Object localObject2;
/* 147:110 */           if (Options.sequential) {
/* 148:111 */             localObject2 = new UnparseVisitor(localPrintWriter);
/* 149:    */           } else {
/* 150:113 */             localObject2 = new OMPVisitor(localPrintWriter);
/* 151:    */           }
/* 152:115 */           localASTCompilationUnit.jjtAccept((JavaParserVisitor)localObject2, null);
/* 153:116 */           localPrintWriter.close();
/* 154:    */         }
/* 155:119 */         if (!Options.noCompile) {
/* 156:121 */           localObject1 = Runtime.getRuntime().exec("javac " + str + ".java");
/* 157:    */         }
/* 158:    */       }
/* 159:    */       catch (FileNotFoundException localFileNotFoundException)
/* 160:    */       {
/* 161:132 */         System.err.println("Cannot find file " + str + ".jomp.");
/* 162:133 */         localFileNotFoundException.printStackTrace();
/* 163:    */       }
/* 164:    */       catch (IOException localIOException)
/* 165:    */       {
/* 166:135 */         System.err.println("Problem executing something.");
/* 167:    */       }
/* 168:    */       catch (ParseException localParseException)
/* 169:    */       {
/* 170:137 */         System.err.println("Parsing error.");
/* 171:138 */         System.err.println(localParseException.getMessage());
/* 172:139 */         localParseException.printStackTrace();
/* 173:    */       }
/* 174:    */     }
/* 175:    */   }
/* 176:    */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.compiler.Jomp
 * JD-Core Version:    0.7.0.1
 */