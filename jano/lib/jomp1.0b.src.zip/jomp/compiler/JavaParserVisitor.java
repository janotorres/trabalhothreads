package jomp.compiler;

public abstract interface JavaParserVisitor
{
  public abstract Object visit(SimpleNode paramSimpleNode, Object paramObject);
  
  public abstract Object visit(ASTCompilationUnit paramASTCompilationUnit, Object paramObject);
  
  public abstract Object visit(ASTPackageDeclaration paramASTPackageDeclaration, Object paramObject);
  
  public abstract Object visit(ASTImportDeclaration paramASTImportDeclaration, Object paramObject);
  
  public abstract Object visit(ASTTypeDeclaration paramASTTypeDeclaration, Object paramObject);
  
  public abstract Object visit(ASTClassDeclaration paramASTClassDeclaration, Object paramObject);
  
  public abstract Object visit(ASTUnmodifiedClassDeclaration paramASTUnmodifiedClassDeclaration, Object paramObject);
  
  public abstract Object visit(ASTClassBody paramASTClassBody, Object paramObject);
  
  public abstract Object visit(ASTNestedClassDeclaration paramASTNestedClassDeclaration, Object paramObject);
  
  public abstract Object visit(ASTClassBodyDeclaration paramASTClassBodyDeclaration, Object paramObject);
  
  public abstract Object visit(ASTMethodDeclarationLookahead paramASTMethodDeclarationLookahead, Object paramObject);
  
  public abstract Object visit(ASTInterfaceDeclaration paramASTInterfaceDeclaration, Object paramObject);
  
  public abstract Object visit(ASTNestedInterfaceDeclaration paramASTNestedInterfaceDeclaration, Object paramObject);
  
  public abstract Object visit(ASTUnmodifiedInterfaceDeclaration paramASTUnmodifiedInterfaceDeclaration, Object paramObject);
  
  public abstract Object visit(ASTInterfaceMemberDeclaration paramASTInterfaceMemberDeclaration, Object paramObject);
  
  public abstract Object visit(ASTFieldDeclaration paramASTFieldDeclaration, Object paramObject);
  
  public abstract Object visit(ASTVariableDeclarator paramASTVariableDeclarator, Object paramObject);
  
  public abstract Object visit(ASTVariableDeclaratorId paramASTVariableDeclaratorId, Object paramObject);
  
  public abstract Object visit(ASTVariableInitializer paramASTVariableInitializer, Object paramObject);
  
  public abstract Object visit(ASTArrayInitializer paramASTArrayInitializer, Object paramObject);
  
  public abstract Object visit(ASTMethodDeclaration paramASTMethodDeclaration, Object paramObject);
  
  public abstract Object visit(ASTMethodDeclarator paramASTMethodDeclarator, Object paramObject);
  
  public abstract Object visit(ASTFormalParameters paramASTFormalParameters, Object paramObject);
  
  public abstract Object visit(ASTFormalParameter paramASTFormalParameter, Object paramObject);
  
  public abstract Object visit(ASTConstructorDeclaration paramASTConstructorDeclaration, Object paramObject);
  
  public abstract Object visit(ASTExplicitConstructorInvocation paramASTExplicitConstructorInvocation, Object paramObject);
  
  public abstract Object visit(ASTInitializer paramASTInitializer, Object paramObject);
  
  public abstract Object visit(ASTType paramASTType, Object paramObject);
  
  public abstract Object visit(ASTPrimitiveType paramASTPrimitiveType, Object paramObject);
  
  public abstract Object visit(ASTResultType paramASTResultType, Object paramObject);
  
  public abstract Object visit(ASTName paramASTName, Object paramObject);
  
  public abstract Object visit(ASTNameList paramASTNameList, Object paramObject);
  
  public abstract Object visit(ASTExpression paramASTExpression, Object paramObject);
  
  public abstract Object visit(ASTAssignmentOperator paramASTAssignmentOperator, Object paramObject);
  
  public abstract Object visit(ASTConditionalExpression paramASTConditionalExpression, Object paramObject);
  
  public abstract Object visit(ASTConditionalOrExpression paramASTConditionalOrExpression, Object paramObject);
  
  public abstract Object visit(ASTConditionalAndExpression paramASTConditionalAndExpression, Object paramObject);
  
  public abstract Object visit(ASTInclusiveOrExpression paramASTInclusiveOrExpression, Object paramObject);
  
  public abstract Object visit(ASTExclusiveOrExpression paramASTExclusiveOrExpression, Object paramObject);
  
  public abstract Object visit(ASTAndExpression paramASTAndExpression, Object paramObject);
  
  public abstract Object visit(ASTEqualityExpression paramASTEqualityExpression, Object paramObject);
  
  public abstract Object visit(ASTInstanceOfExpression paramASTInstanceOfExpression, Object paramObject);
  
  public abstract Object visit(ASTRelationalExpression paramASTRelationalExpression, Object paramObject);
  
  public abstract Object visit(ASTShiftExpression paramASTShiftExpression, Object paramObject);
  
  public abstract Object visit(ASTAdditiveExpression paramASTAdditiveExpression, Object paramObject);
  
  public abstract Object visit(ASTMultiplicativeExpression paramASTMultiplicativeExpression, Object paramObject);
  
  public abstract Object visit(ASTUnaryExpression paramASTUnaryExpression, Object paramObject);
  
  public abstract Object visit(ASTPreIncrementExpression paramASTPreIncrementExpression, Object paramObject);
  
  public abstract Object visit(ASTPreDecrementExpression paramASTPreDecrementExpression, Object paramObject);
  
  public abstract Object visit(ASTUnaryExpressionNotPlusMinus paramASTUnaryExpressionNotPlusMinus, Object paramObject);
  
  public abstract Object visit(ASTCastLookahead paramASTCastLookahead, Object paramObject);
  
  public abstract Object visit(ASTPostfixExpression paramASTPostfixExpression, Object paramObject);
  
  public abstract Object visit(ASTCastExpression paramASTCastExpression, Object paramObject);
  
  public abstract Object visit(ASTPrimaryExpression paramASTPrimaryExpression, Object paramObject);
  
  public abstract Object visit(ASTPrimaryPrefix paramASTPrimaryPrefix, Object paramObject);
  
  public abstract Object visit(ASTPrimarySuffix paramASTPrimarySuffix, Object paramObject);
  
  public abstract Object visit(ASTLiteral paramASTLiteral, Object paramObject);
  
  public abstract Object visit(ASTBooleanLiteral paramASTBooleanLiteral, Object paramObject);
  
  public abstract Object visit(ASTNullLiteral paramASTNullLiteral, Object paramObject);
  
  public abstract Object visit(ASTArguments paramASTArguments, Object paramObject);
  
  public abstract Object visit(ASTArgumentList paramASTArgumentList, Object paramObject);
  
  public abstract Object visit(ASTAllocationExpression paramASTAllocationExpression, Object paramObject);
  
  public abstract Object visit(ASTArrayDimsAndInits paramASTArrayDimsAndInits, Object paramObject);
  
  public abstract Object visit(ASTStatement paramASTStatement, Object paramObject);
  
  public abstract Object visit(ASTLabeledStatement paramASTLabeledStatement, Object paramObject);
  
  public abstract Object visit(ASTBlock paramASTBlock, Object paramObject);
  
  public abstract Object visit(ASTBlockStatement paramASTBlockStatement, Object paramObject);
  
  public abstract Object visit(ASTLocalVariableDeclaration paramASTLocalVariableDeclaration, Object paramObject);
  
  public abstract Object visit(ASTEmptyStatement paramASTEmptyStatement, Object paramObject);
  
  public abstract Object visit(ASTStatementExpression paramASTStatementExpression, Object paramObject);
  
  public abstract Object visit(ASTSwitchStatement paramASTSwitchStatement, Object paramObject);
  
  public abstract Object visit(ASTSwitchLabel paramASTSwitchLabel, Object paramObject);
  
  public abstract Object visit(ASTIfStatement paramASTIfStatement, Object paramObject);
  
  public abstract Object visit(ASTWhileStatement paramASTWhileStatement, Object paramObject);
  
  public abstract Object visit(ASTDoStatement paramASTDoStatement, Object paramObject);
  
  public abstract Object visit(ASTForStatement paramASTForStatement, Object paramObject);
  
  public abstract Object visit(ASTForInit paramASTForInit, Object paramObject);
  
  public abstract Object visit(ASTStatementExpressionList paramASTStatementExpressionList, Object paramObject);
  
  public abstract Object visit(ASTForUpdate paramASTForUpdate, Object paramObject);
  
  public abstract Object visit(ASTBreakStatement paramASTBreakStatement, Object paramObject);
  
  public abstract Object visit(ASTContinueStatement paramASTContinueStatement, Object paramObject);
  
  public abstract Object visit(ASTReturnStatement paramASTReturnStatement, Object paramObject);
  
  public abstract Object visit(ASTThrowStatement paramASTThrowStatement, Object paramObject);
  
  public abstract Object visit(ASTSynchronizedStatement paramASTSynchronizedStatement, Object paramObject);
  
  public abstract Object visit(ASTTryStatement paramASTTryStatement, Object paramObject);
  
  public abstract Object visit(ASTOMPDirective paramASTOMPDirective, Object paramObject);
  
  public abstract Object visit(ASTOMPParallelDirective paramASTOMPParallelDirective, Object paramObject);
  
  public abstract Object visit(ASTOMPMasterDirective paramASTOMPMasterDirective, Object paramObject);
  
  public abstract Object visit(ASTOMPOrderedDirective paramASTOMPOrderedDirective, Object paramObject);
  
  public abstract Object visit(ASTOMPBarrierDirective paramASTOMPBarrierDirective, Object paramObject);
  
  public abstract Object visit(ASTOMPSingleDirective paramASTOMPSingleDirective, Object paramObject);
  
  public abstract Object visit(ASTOMPForDirective paramASTOMPForDirective, Object paramObject);
  
  public abstract Object visit(ASTOMPForStatement paramASTOMPForStatement, Object paramObject);
  
  public abstract Object visit(ASTOMPSimpleRelation paramASTOMPSimpleRelation, Object paramObject);
  
  public abstract Object visit(ASTOMPSimpleUpdate paramASTOMPSimpleUpdate, Object paramObject);
  
  public abstract Object visit(ASTOMPLongUpdate paramASTOMPLongUpdate, Object paramObject);
  
  public abstract Object visit(ASTOMPSectionsDirective paramASTOMPSectionsDirective, Object paramObject);
  
  public abstract Object visit(ASTOMPSectionsBlock paramASTOMPSectionsBlock, Object paramObject);
  
  public abstract Object visit(ASTOMPSectionDirective paramASTOMPSectionDirective, Object paramObject);
  
  public abstract Object visit(ASTOMPCriticalDirective paramASTOMPCriticalDirective, Object paramObject);
  
  public abstract Object visit(ASTOMPOnlyDirective paramASTOMPOnlyDirective, Object paramObject);
  
  public abstract Object visit(ASTOMPClauseList paramASTOMPClauseList, Object paramObject);
  
  public abstract Object visit(ASTOMPClause paramASTOMPClause, Object paramObject);
  
  public abstract Object visit(ASTOMPPrivateClause paramASTOMPPrivateClause, Object paramObject);
  
  public abstract Object visit(ASTOMPFirstPrivateClause paramASTOMPFirstPrivateClause, Object paramObject);
  
  public abstract Object visit(ASTOMPLastPrivateClause paramASTOMPLastPrivateClause, Object paramObject);
  
  public abstract Object visit(ASTOMPSharedClause paramASTOMPSharedClause, Object paramObject);
  
  public abstract Object visit(ASTOMPDefaultClause paramASTOMPDefaultClause, Object paramObject);
  
  public abstract Object visit(ASTOMPNowaitClause paramASTOMPNowaitClause, Object paramObject);
  
  public abstract Object visit(ASTOMPIfClause paramASTOMPIfClause, Object paramObject);
  
  public abstract Object visit(ASTOMPScheduleClause paramASTOMPScheduleClause, Object paramObject);
  
  public abstract Object visit(ASTOMPOrderedClause paramASTOMPOrderedClause, Object paramObject);
  
  public abstract Object visit(ASTOMPReductionClause paramASTOMPReductionClause, Object paramObject);
  
  public abstract Object visit(ASTOMPReductionOp paramASTOMPReductionOp, Object paramObject);
  
  public abstract Object visit(ASTVarNameList paramASTVarNameList, Object paramObject);
  
  public abstract Object visit(ASTVarName paramASTVarName, Object paramObject);
  
  public abstract Object visit(ASTIdentifier paramASTIdentifier, Object paramObject);
}


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.compiler.JavaParserVisitor
 * JD-Core Version:    0.7.0.1
 */