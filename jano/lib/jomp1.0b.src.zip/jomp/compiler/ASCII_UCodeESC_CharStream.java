/*   1:    */ 
/*   2:    */ 
/*   3:    */ java.io.IOException
/*   4:    */ java.io.InputStream
/*   5:    */ java.io.InputStreamReader
/*   6:    */ java.io.Reader
/*   7:    */ 
/*   8:    */ ASCII_UCodeESC_CharStream
/*   9:    */ 
/*  10:    */   staticFlag = 
/*  11:    */   
/*  12:    */   hexval
/*  13:    */     
/*  14:    */   
/*  15: 13 */      (
/*  16:    */     
/*  17:    */     '0': 
/*  18: 16 */       0
/*  19:    */     '1': 
/*  20: 18 */       1
/*  21:    */     '2': 
/*  22: 20 */       2
/*  23:    */     '3': 
/*  24: 22 */       3
/*  25:    */     '4': 
/*  26: 24 */       4
/*  27:    */     '5': 
/*  28: 26 */       5
/*  29:    */     '6': 
/*  30: 28 */       6
/*  31:    */     '7': 
/*  32: 30 */       7
/*  33:    */     '8': 
/*  34: 32 */       8
/*  35:    */     '9': 
/*  36: 34 */       9
/*  37:    */     'A': 
/*  38:    */     'a': 
/*  39: 38 */       10
/*  40:    */     'B': 
/*  41:    */     'b': 
/*  42: 41 */       11
/*  43:    */     'C': 
/*  44:    */     'c': 
/*  45: 44 */       12
/*  46:    */     'D': 
/*  47:    */     'd': 
/*  48: 47 */       13
/*  49:    */     'E': 
/*  50:    */     'e': 
/*  51: 50 */       14
/*  52:    */     'F': 
/*  53:    */     'f': 
/*  54: 53 */       15
/*  55:    */     
/*  56: 56 */     ()
/*  57:    */   
/*  58:    */   
/*  59: 59 */   bufpos = -1
/*  60:    */   bufsize
/*  61:    */   available
/*  62:    */   tokenBegin
/*  63:    */   []bufline
/*  64:    */   []bufcolumn
/*  65: 66 */   column = 0
/*  66: 67 */   line = 1
/*  67:    */   inputStream
/*  68: 71 */   prevCharIsCR = 
/*  69: 72 */   prevCharIsLF = 
/*  70:    */   []nextCharBuf
/*  71:    */   []buffer
/*  72: 76 */   maxNextCharInd = 0
/*  73: 77 */   nextCharInd = -1
/*  74: 78 */   inBuf = 0
/*  75:    */   
/*  76:    */   ExpandBuff
/*  77:    */   
/*  78: 82 */     [] = bufsize + 2048];
/*  79: 83 */     int[] arrayOfInt1 = new int[this.bufsize + 2048];
/*  80: 84 */     int[] arrayOfInt2 = new int[this.bufsize + 2048];
/*  81:    */     try
/*  82:    */     {
/*  83: 88 */       if (paramBoolean)
/*  84:    */       {
/*  85: 90 */         System.arraycopy(this.buffer, this.tokenBegin, arrayOfChar, 0, this.bufsize - this.tokenBegin);
/*  86: 91 */         System.arraycopy(this.buffer, 0, arrayOfChar, this.bufsize - this.tokenBegin, this.bufpos);
/*  87:    */         
/*  88: 93 */         this.buffer = arrayOfChar;
/*  89:    */         
/*  90: 95 */         System.arraycopy(this.bufline, this.tokenBegin, arrayOfInt1, 0, this.bufsize - this.tokenBegin);
/*  91: 96 */         System.arraycopy(this.bufline, 0, arrayOfInt1, this.bufsize - this.tokenBegin, this.bufpos);
/*  92: 97 */         this.bufline = arrayOfInt1;
/*  93:    */         
/*  94: 99 */         System.arraycopy(this.bufcolumn, this.tokenBegin, arrayOfInt2, 0, this.bufsize - this.tokenBegin);
/*  95:100 */         System.arraycopy(this.bufcolumn, 0, arrayOfInt2, this.bufsize - this.tokenBegin, this.bufpos);
/*  96:101 */         this.bufcolumn = arrayOfInt2;
/*  97:    */         
/*  98:103 */         this.bufpos += this.bufsize - this.tokenBegin;
/*  99:    */       }
/* 100:    */       else
/* 101:    */       {
/* 102:107 */         System.arraycopy(this.buffer, this.tokenBegin, arrayOfChar, 0, this.bufsize - this.tokenBegin);
/* 103:108 */         this.buffer = arrayOfChar;
/* 104:    */         
/* 105:110 */         System.arraycopy(this.bufline, this.tokenBegin, arrayOfInt1, 0, this.bufsize - this.tokenBegin);
/* 106:111 */         this.bufline = arrayOfInt1;
/* 107:    */         
/* 108:113 */         System.arraycopy(this.bufcolumn, this.tokenBegin, arrayOfInt2, 0, this.bufsize - this.tokenBegin);
/* 109:114 */         this.bufcolumn = arrayOfInt2;
/* 110:    */         
/* 111:116 */         this.bufpos -= this.tokenBegin;
/* 112:    */       }
/* 113:    */     }
/* 114:    */     catch (Throwable localThrowable)
/* 115:    */     {
/* 116:121 */       throw new Error(localThrowable.getMessage());
/* 117:    */     }
/* 118:124 */     this.available = (this.bufsize += 2048);
/* 119:125 */     this.tokenBegin = 0;
/* 120:    */   }
/* 121:    */   
/* 122:    */   private final void FillBuff()
/* 123:    */     throws IOException
/* 124:    */   {
/* 125:131 */     if (this.maxNextCharInd == 4096) {
/* 126:132 */       this.maxNextCharInd = (this.nextCharInd = 0);
/* 127:    */     }
/* 128:    */     try
/* 129:    */     {
/* 130:    */       int i;
/* 131:135 */       if ((i = this.inputStream.read(this.nextCharBuf, this.maxNextCharInd, 4096 - this.maxNextCharInd)) == -1)
/* 132:    */       {
/* 133:138 */         this.inputStream.close();
/* 134:139 */         throw new IOException();
/* 135:    */       }
/* 136:142 */       this.maxNextCharInd += i;
/* 137:143 */       return;
/* 138:    */     }
/* 139:    */     catch (IOException localIOException)
/* 140:    */     {
/* 141:146 */       if (this.bufpos != 0)
/* 142:    */       {
/* 143:148 */         this.bufpos -= 1;
/* 144:149 */         backup(0);
/* 145:    */       }
/* 146:    */       else
/* 147:    */       {
/* 148:153 */         this.bufline[this.bufpos] = this.line;
/* 149:154 */         this.bufcolumn[this.bufpos] = this.column;
/* 150:    */       }
/* 151:156 */       throw localIOException;
/* 152:    */     }
/* 153:    */   }
/* 154:    */   
/* 155:    */   private final char ReadByte()
/* 156:    */     throws IOException
/* 157:    */   {
/* 158:162 */     if (++this.nextCharInd >= this.maxNextCharInd) {
/* 159:163 */       FillBuff();
/* 160:    */     }
/* 161:165 */     return this.nextCharBuf[this.nextCharInd];
/* 162:    */   }
/* 163:    */   
/* 164:    */   public final char BeginToken()
/* 165:    */     throws IOException
/* 166:    */   {
/* 167:170 */     if (this.inBuf > 0)
/* 168:    */     {
/* 169:172 */       this.inBuf -= 1;
/* 170:173 */       return this.buffer[(this.tokenBegin = ++this.bufpos)];
/* 171:    */     }
/* 172:177 */     this.tokenBegin = 0;
/* 173:178 */     this.bufpos = -1;
/* 174:    */     
/* 175:180 */     return readChar();
/* 176:    */   }
/* 177:    */   
/* 178:    */   private final void AdjustBuffSize()
/* 179:    */   {
/* 180:185 */     if (this.available == this.bufsize)
/* 181:    */     {
/* 182:187 */       if (this.tokenBegin > 2048)
/* 183:    */       {
/* 184:189 */         this.bufpos = 0;
/* 185:190 */         this.available = this.tokenBegin;
/* 186:    */       }
/* 187:    */       else
/* 188:    */       {
/* 189:193 */         ExpandBuff(false);
/* 190:    */       }
/* 191:    */     }
/* 192:195 */     else if (this.available > this.tokenBegin) {
/* 193:196 */       this.available = this.bufsize;
/* 194:197 */     } else if (this.tokenBegin - this.available < 2048) {
/* 195:198 */       ExpandBuff(true);
/* 196:    */     } else {
/* 197:200 */       this.available = this.tokenBegin;
/* 198:    */     }
/* 199:    */   }
/* 200:    */   
/* 201:    */   private final void UpdateLineColumn(char paramChar)
/* 202:    */   {
/* 203:205 */     this.column += 1;
/* 204:207 */     if (this.prevCharIsLF)
/* 205:    */     {
/* 206:209 */       this.prevCharIsLF = false;
/* 207:210 */       this.line += (this.column = 1);
/* 208:    */     }
/* 209:212 */     else if (this.prevCharIsCR)
/* 210:    */     {
/* 211:214 */       this.prevCharIsCR = false;
/* 212:215 */       if (paramChar == '\n') {
/* 213:217 */         this.prevCharIsLF = true;
/* 214:    */       } else {
/* 215:220 */         this.line += (this.column = 1);
/* 216:    */       }
/* 217:    */     }
/* 218:223 */     switch (paramChar)
/* 219:    */     {
/* 220:    */     case '\r': 
/* 221:226 */       this.prevCharIsCR = true;
/* 222:227 */       break;
/* 223:    */     case '\n': 
/* 224:229 */       this.prevCharIsLF = true;
/* 225:230 */       break;
/* 226:    */     case '\t': 
/* 227:232 */       this.column -= 1;
/* 228:233 */       this.column += 8 - (this.column & 0x7);
/* 229:234 */       break;
/* 230:    */     }
/* 231:239 */     this.bufline[this.bufpos] = this.line;
/* 232:240 */     this.bufcolumn[this.bufpos] = this.column;
/* 233:    */   }
/* 234:    */   
/* 235:    */   public final char readChar()
/* 236:    */     throws IOException
/* 237:    */   {
/* 238:245 */     if (this.inBuf > 0)
/* 239:    */     {
/* 240:247 */       this.inBuf -= 1;
/* 241:248 */       return this.buffer[(++this.bufpos)];
/* 242:    */     }
/* 243:253 */     if (++this.bufpos == this.available) {
/* 244:254 */       AdjustBuffSize();
/* 245:    */     }
/* 246:    */     char c;
/* 247:256 */     if ((this.buffer[this.bufpos] = c = (char)(0xFF & ReadByte())) == '\\')
/* 248:    */     {
/* 249:258 */       UpdateLineColumn(c);
/* 250:    */       
/* 251:260 */       int i = 1;
/* 252:    */       for (;;)
/* 253:    */       {
/* 254:264 */         if (++this.bufpos == this.available) {
/* 255:265 */           AdjustBuffSize();
/* 256:    */         }
/* 257:    */         try
/* 258:    */         {
/* 259:269 */           if ((this.buffer[this.bufpos] = c = (char)(0xFF & ReadByte())) != '\\')
/* 260:    */           {
/* 261:271 */             UpdateLineColumn(c);
/* 262:273 */             if ((c == 'u') && ((i & 0x1) == 1))
/* 263:    */             {
/* 264:275 */               if (--this.bufpos >= 0) {
/* 265:    */                 break;
/* 266:    */               }
/* 267:276 */               this.bufpos = (this.bufsize - 1); break;
/* 268:    */             }
/* 269:281 */             backup(i);
/* 270:282 */             return '\\';
/* 271:    */           }
/* 272:    */         }
/* 273:    */         catch (IOException localIOException1)
/* 274:    */         {
/* 275:287 */           if (i > 1) {
/* 276:288 */             backup(i);
/* 277:    */           }
/* 278:290 */           return '\\';
/* 279:    */         }
/* 280:293 */         UpdateLineColumn(c);
/* 281:294 */         i++;
/* 282:    */       }
/* 283:    */       try
/* 284:    */       {
/* 285:300 */         while ((c = (char)(0xFF & ReadByte())) == 'u') {
/* 286:301 */           this.column += 1;
/* 287:    */         }
/* 288:303 */         char tmp332_331 = ((char)(hexval(c) << 12 | hexval((char)(0xFF & ReadByte())) << 8 | hexval((char)(0xFF & ReadByte())) << 4 | hexval((char)(0xFF & ReadByte()))));c = tmp332_331;this.buffer[this.bufpos] = tmp332_331;
/* 289:    */         
/* 290:    */ 
/* 291:    */ 
/* 292:    */ 
/* 293:308 */         this.column += 4;
/* 294:    */       }
/* 295:    */       catch (IOException localIOException2)
/* 296:    */       {
/* 297:312 */         throw new Error("Invalid escape character at line " + this.line + " column " + this.column + ".");
/* 298:    */       }
/* 299:316 */       if (i == 1) {
/* 300:317 */         return c;
/* 301:    */       }
/* 302:320 */       backup(i - 1);
/* 303:321 */       return '\\';
/* 304:    */     }
/* 305:326 */     UpdateLineColumn(c);
/* 306:327 */     return c;
/* 307:    */   }
/* 308:    */   
/* 309:    */   /**
/* 310:    */    * @deprecated
/* 311:    */    */
/* 312:    */   public final int getColumn()
/* 313:    */   {
/* 314:337 */     return this.bufcolumn[this.bufpos];
/* 315:    */   }
/* 316:    */   
/* 317:    */   /**
/* 318:    */    * @deprecated
/* 319:    */    */
/* 320:    */   public final int getLine()
/* 321:    */   {
/* 322:346 */     return this.bufline[this.bufpos];
/* 323:    */   }
/* 324:    */   
/* 325:    */   public final int getEndColumn()
/* 326:    */   {
/* 327:350 */     return this.bufcolumn[this.bufpos];
/* 328:    */   }
/* 329:    */   
/* 330:    */   public final int getEndLine()
/* 331:    */   {
/* 332:354 */     return this.bufline[this.bufpos];
/* 333:    */   }
/* 334:    */   
/* 335:    */   public final int getBeginColumn()
/* 336:    */   {
/* 337:358 */     return this.bufcolumn[this.tokenBegin];
/* 338:    */   }
/* 339:    */   
/* 340:    */   public final int getBeginLine()
/* 341:    */   {
/* 342:362 */     return this.bufline[this.tokenBegin];
/* 343:    */   }
/* 344:    */   
/* 345:    */   public final void backup(int paramInt)
/* 346:    */   {
/* 347:367 */     this.inBuf += paramInt;
/* 348:368 */     if (this.bufpos -= paramInt < 0) {
/* 349:369 */       this.bufpos += this.bufsize;
/* 350:    */     }
/* 351:    */   }
/* 352:    */   
/* 353:    */   public ASCII_UCodeESC_CharStream(Reader paramReader, int paramInt1, int paramInt2, int paramInt3)
/* 354:    */   {
/* 355:375 */     this.inputStream = paramReader;
/* 356:376 */     this.line = paramInt1;
/* 357:377 */     this.column = (paramInt2 - 1);
/* 358:    */     
/* 359:379 */     this.available = (this.bufsize = paramInt3);
/* 360:380 */     this.buffer = new char[paramInt3];
/* 361:381 */     this.bufline = new int[paramInt3];
/* 362:382 */     this.bufcolumn = new int[paramInt3];
/* 363:383 */     this.nextCharBuf = new char[4096];
/* 364:    */   }
/* 365:    */   
/* 366:    */   public ASCII_UCodeESC_CharStream(Reader paramReader, int paramInt1, int paramInt2)
/* 367:    */   {
/* 368:389 */     this(paramReader, paramInt1, paramInt2, 4096);
/* 369:    */   }
/* 370:    */   
/* 371:    */   public void ReInit(Reader paramReader, int paramInt1, int paramInt2, int paramInt3)
/* 372:    */   {
/* 373:394 */     this.inputStream = paramReader;
/* 374:395 */     this.line = paramInt1;
/* 375:396 */     this.column = (paramInt2 - 1);
/* 376:398 */     if ((this.buffer == null) || (paramInt3 != this.buffer.length))
/* 377:    */     {
/* 378:400 */       this.available = (this.bufsize = paramInt3);
/* 379:401 */       this.buffer = new char[paramInt3];
/* 380:402 */       this.bufline = new int[paramInt3];
/* 381:403 */       this.bufcolumn = new int[paramInt3];
/* 382:404 */       this.nextCharBuf = new char[4096];
/* 383:    */     }
/* 384:406 */     this.prevCharIsLF = (this.prevCharIsCR = 0);
/* 385:407 */     this.tokenBegin = (this.inBuf = this.maxNextCharInd = 0);
/* 386:408 */     this.nextCharInd = (this.bufpos = -1);
/* 387:    */   }
/* 388:    */   
/* 389:    */   public void ReInit(Reader paramReader, int paramInt1, int paramInt2)
/* 390:    */   {
/* 391:414 */     ReInit(paramReader, paramInt1, paramInt2, 4096);
/* 392:    */   }
/* 393:    */   
/* 394:    */   public ASCII_UCodeESC_CharStream(InputStream paramInputStream, int paramInt1, int paramInt2, int paramInt3)
/* 395:    */   {
/* 396:419 */     this(new InputStreamReader(paramInputStream), paramInt1, paramInt2, 4096);
/* 397:    */   }
/* 398:    */   
/* 399:    */   public ASCII_UCodeESC_CharStream(InputStream paramInputStream, int paramInt1, int paramInt2)
/* 400:    */   {
/* 401:425 */     this(paramInputStream, paramInt1, paramInt2, 4096);
/* 402:    */   }
/* 403:    */   
/* 404:    */   public void ReInit(InputStream paramInputStream, int paramInt1, int paramInt2, int paramInt3)
/* 405:    */   {
/* 406:431 */     ReInit(new InputStreamReader(paramInputStream), paramInt1, paramInt2, 4096);
/* 407:    */   }
/* 408:    */   
/* 409:    */   public void ReInit(InputStream paramInputStream, int paramInt1, int paramInt2)
/* 410:    */   {
/* 411:436 */     ReInit(paramInputStream, paramInt1, paramInt2, 4096);
/* 412:    */   }
/* 413:    */   
/* 414:    */   public final String GetImage()
/* 415:    */   {
/* 416:441 */     if (this.bufpos >= this.tokenBegin) {
/* 417:442 */       return new String(this.buffer, this.tokenBegin, this.bufpos - this.tokenBegin + 1);
/* 418:    */     }
/* 419:444 */     return new String(this.buffer, this.tokenBegin, this.bufsize - this.tokenBegin) + new String(this.buffer, 0, this.bufpos + 1);
/* 420:    */   }
/* 421:    */   
/* 422:    */   public final char[] GetSuffix(int paramInt)
/* 423:    */   {
/* 424:450 */     char[] arrayOfChar = new char[paramInt];
/* 425:452 */     if (this.bufpos + 1 >= paramInt)
/* 426:    */     {
/* 427:453 */       System.arraycopy(this.buffer, this.bufpos - paramInt + 1, arrayOfChar, 0, paramInt);
/* 428:    */     }
/* 429:    */     else
/* 430:    */     {
/* 431:456 */       System.arraycopy(this.buffer, this.bufsize - (paramInt - this.bufpos - 1), arrayOfChar, 0, paramInt - this.bufpos - 1);
/* 432:    */       
/* 433:458 */       System.arraycopy(this.buffer, 0, arrayOfChar, paramInt - this.bufpos - 1, this.bufpos + 1);
/* 434:    */     }
/* 435:461 */     return arrayOfChar;
/* 436:    */   }
/* 437:    */   
/* 438:    */   public void Done()
/* 439:    */   {
/* 440:466 */     this.nextCharBuf = null;
/* 441:467 */     this.buffer = null;
/* 442:468 */     this.bufline = null;
/* 443:469 */     this.bufcolumn = null;
/* 444:    */   }
/* 445:    */   
/* 446:    */   public void adjustBeginLineColumn(int paramInt1, int paramInt2)
/* 447:    */   {
/* 448:477 */     int i = this.tokenBegin;
/* 449:    */     int j;
/* 450:480 */     if (this.bufpos >= this.tokenBegin) {
/* 451:482 */       j = this.bufpos - this.tokenBegin + this.inBuf + 1;
/* 452:    */     } else {
/* 453:486 */       j = this.bufsize - this.tokenBegin + this.bufpos + 1 + this.inBuf;
/* 454:    */     }
/* 455:489 */     int k = 0;int m = 0;int n = 0;
/* 456:490 */     int i1 = 0;int i2 = 0;
/* 457:493 */     while ((k < j) && (this.bufline[(m = i % this.bufsize)] == this.bufline[(n = ++i % this.bufsize)]))
/* 458:    */     {
/* 459:495 */       this.bufline[m] = paramInt1;
/* 460:496 */       i1 = i2 + this.bufcolumn[n] - this.bufcolumn[m];
/* 461:497 */       this.bufcolumn[m] = (paramInt2 + i2);
/* 462:498 */       i2 = i1;
/* 463:499 */       k++;
/* 464:    */     }
/* 465:502 */     if (k < j)
/* 466:    */     {
/* 467:504 */       this.bufline[m] = (paramInt1++);
/* 468:505 */       this.bufcolumn[m] = (paramInt2 + i2);
/* 469:507 */       while (k++ < j) {
/* 470:509 */         if (this.bufline[(m = i % this.bufsize)] != this.bufline[(++i % this.bufsize)]) {
/* 471:510 */           this.bufline[m] = (paramInt1++);
/* 472:    */         } else {
/* 473:512 */           this.bufline[m] = paramInt1;
/* 474:    */         }
/* 475:    */       }
/* 476:    */     }
/* 477:516 */     this.line = this.bufline[m];
/* 478:517 */     this.column = this.bufcolumn[m];
/* 479:    */   }
/* 480:    */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.compiler.ASCII_UCodeESC_CharStream
 * JD-Core Version:    0.7.0.1
 */