/*   1:    */ package jomp.compiler;
/*   2:    */ 
/*   3:    */ public class ParseException
/*   4:    */   extends Exception
/*   5:    */ {
/*   6:    */   protected boolean specialConstructor;
/*   7:    */   public Token currentToken;
/*   8:    */   public int[][] expectedTokenSequences;
/*   9:    */   public String[] tokenImage;
/*  10:    */   
/*  11:    */   public ParseException(Token paramToken, int[][] paramArrayOfInt, String[] paramArrayOfString)
/*  12:    */   {
/*  13: 32 */     super("");
/*  14: 33 */     this.specialConstructor = true;
/*  15: 34 */     this.currentToken = paramToken;
/*  16: 35 */     this.expectedTokenSequences = paramArrayOfInt;
/*  17: 36 */     this.tokenImage = paramArrayOfString;
/*  18:    */   }
/*  19:    */   
/*  20:    */   public ParseException()
/*  21:    */   {
/*  22: 51 */     this.specialConstructor = false;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public ParseException(String paramString)
/*  26:    */   {
/*  27: 55 */     super(paramString);
/*  28: 56 */     this.specialConstructor = false;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public String getMessage()
/*  32:    */   {
/*  33: 98 */     if (!this.specialConstructor) {
/*  34: 99 */       return super.getMessage();
/*  35:    */     }
/*  36:101 */     String str1 = "";
/*  37:102 */     int i = 0;
/*  38:103 */     for (int j = 0; j < this.expectedTokenSequences.length; j++)
/*  39:    */     {
/*  40:104 */       if (i < this.expectedTokenSequences[j].length) {
/*  41:105 */         i = this.expectedTokenSequences[j].length;
/*  42:    */       }
/*  43:107 */       for (int k = 0; k < this.expectedTokenSequences[j].length; k++) {
/*  44:108 */         str1 = str1 + this.tokenImage[this.expectedTokenSequences[j][k]] + " ";
/*  45:    */       }
/*  46:110 */       if (this.expectedTokenSequences[j][(this.expectedTokenSequences[j].length - 1)] != 0) {
/*  47:111 */         str1 = str1 + "...";
/*  48:    */       }
/*  49:113 */       str1 = str1 + this.eol + "    ";
/*  50:    */     }
/*  51:115 */     String str2 = "Encountered \"";
/*  52:116 */     Token localToken = this.currentToken.next;
/*  53:117 */     for (int m = 0; m < i; m++)
/*  54:    */     {
/*  55:118 */       if (m != 0) {
/*  56:118 */         str2 = str2 + " ";
/*  57:    */       }
/*  58:119 */       if (localToken.kind == 0)
/*  59:    */       {
/*  60:120 */         str2 = str2 + this.tokenImage[0];
/*  61:121 */         break;
/*  62:    */       }
/*  63:123 */       str2 = str2 + add_escapes(localToken.image);
/*  64:124 */       localToken = localToken.next;
/*  65:    */     }
/*  66:126 */     str2 = str2 + "\" at line " + this.currentToken.next.beginLine + ", column " + this.currentToken.next.beginColumn + "." + this.eol;
/*  67:127 */     if (this.expectedTokenSequences.length == 1) {
/*  68:128 */       str2 = str2 + "Was expecting:" + this.eol + "    ";
/*  69:    */     } else {
/*  70:130 */       str2 = str2 + "Was expecting one of:" + this.eol + "    ";
/*  71:    */     }
/*  72:132 */     str2 = str2 + str1;
/*  73:133 */     return str2;
/*  74:    */   }
/*  75:    */   
/*  76:139 */   protected String eol = System.getProperty("line.separator", "\n");
/*  77:    */   
/*  78:    */   protected String add_escapes(String paramString)
/*  79:    */   {
/*  80:147 */     StringBuffer localStringBuffer = new StringBuffer();
/*  81:149 */     for (int i = 0; i < paramString.length(); i++) {
/*  82:150 */       switch (paramString.charAt(i))
/*  83:    */       {
/*  84:    */       case '\000': 
/*  85:    */         break;
/*  86:    */       case '\b': 
/*  87:155 */         localStringBuffer.append("\\b");
/*  88:156 */         break;
/*  89:    */       case '\t': 
/*  90:158 */         localStringBuffer.append("\\t");
/*  91:159 */         break;
/*  92:    */       case '\n': 
/*  93:161 */         localStringBuffer.append("\\n");
/*  94:162 */         break;
/*  95:    */       case '\f': 
/*  96:164 */         localStringBuffer.append("\\f");
/*  97:165 */         break;
/*  98:    */       case '\r': 
/*  99:167 */         localStringBuffer.append("\\r");
/* 100:168 */         break;
/* 101:    */       case '"': 
/* 102:170 */         localStringBuffer.append("\\\"");
/* 103:171 */         break;
/* 104:    */       case '\'': 
/* 105:173 */         localStringBuffer.append("\\'");
/* 106:174 */         break;
/* 107:    */       case '\\': 
/* 108:176 */         localStringBuffer.append("\\\\");
/* 109:177 */         break;
/* 110:    */       default: 
/* 111:    */         char c;
/* 112:179 */         if (((c = paramString.charAt(i)) < ' ') || (c > '~'))
/* 113:    */         {
/* 114:180 */           String str = "0000" + Integer.toString(c, 16);
/* 115:181 */           localStringBuffer.append("\\u" + str.substring(str.length() - 4, str.length()));
/* 116:    */         }
/* 117:    */         else
/* 118:    */         {
/* 119:183 */           localStringBuffer.append(c);
/* 120:    */         }
/* 121:    */         break;
/* 122:    */       }
/* 123:    */     }
/* 124:188 */     return localStringBuffer.toString();
/* 125:    */   }
/* 126:    */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.compiler.ParseException
 * JD-Core Version:    0.7.0.1
 */