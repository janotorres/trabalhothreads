/*    1:     */ package jomp.compiler;
/*    2:     */ 
/*    3:     */ import java.io.IOException;
/*    4:     */ 
/*    5:     */ public class JavaParserTokenManager
/*    6:     */   implements JavaParserConstants
/*    7:     */ {
/*    8:     */   private final int jjStopStringLiteralDfa_0(int paramInt, long paramLong1, long paramLong2, long paramLong3)
/*    9:     */   {
/*   10:   8 */     switch (paramInt)
/*   11:     */     {
/*   12:     */     case 0: 
/*   13:  11 */       if (((paramLong1 & 0x140) != 0L) || ((paramLong2 & 0x10) != 0L) || ((paramLong3 & 0x10) != 0L)) {
/*   14:  12 */         return 2;
/*   15:     */       }
/*   16:  13 */       if ((paramLong2 & 0x0) != 0L) {
/*   17:  14 */         return 8;
/*   18:     */       }
/*   19:  15 */       if (((paramLong1 & 0xFFFFE000) != 0L) || ((paramLong2 & 0x7FFEF) != 0L))
/*   20:     */       {
/*   21:  17 */         this.jjmatchedKind = 91;
/*   22:  18 */         return 32;
/*   23:     */       }
/*   24:  20 */       return -1;
/*   25:     */     case 1: 
/*   26:  22 */       if ((paramLong1 & 0x100) != 0L) {
/*   27:  23 */         return 0;
/*   28:     */       }
/*   29:  24 */       if (((paramLong1 & 0xFCFFE000) != 0L) || ((paramLong2 & 0x7FFEF) != 0L))
/*   30:     */       {
/*   31:  26 */         if (this.jjmatchedPos != 1)
/*   32:     */         {
/*   33:  28 */           this.jjmatchedKind = 91;
/*   34:  29 */           this.jjmatchedPos = 1;
/*   35:     */         }
/*   36:  31 */         return 32;
/*   37:     */       }
/*   38:  33 */       if ((paramLong1 & 0x3000000) != 0L) {
/*   39:  34 */         return 32;
/*   40:     */       }
/*   41:  35 */       return -1;
/*   42:     */     case 2: 
/*   43:  37 */       if ((paramLong1 & 0x0) != 0L) {
/*   44:  38 */         return 32;
/*   45:     */       }
/*   46:  39 */       if (((paramLong1 & 0xFEFFE000) != 0L) || ((paramLong2 & 0x7FFEF) != 0L))
/*   47:     */       {
/*   48:  41 */         if (this.jjmatchedPos != 2)
/*   49:     */         {
/*   50:  43 */           this.jjmatchedKind = 91;
/*   51:  44 */           this.jjmatchedPos = 2;
/*   52:     */         }
/*   53:  46 */         return 32;
/*   54:     */       }
/*   55:  48 */       return -1;
/*   56:     */     case 3: 
/*   57:  50 */       if (((paramLong1 & 0xFAF4E000) != 0L) || ((paramLong2 & 0x7DFCF) != 0L))
/*   58:     */       {
/*   59:  52 */         this.jjmatchedKind = 91;
/*   60:  53 */         this.jjmatchedPos = 3;
/*   61:  54 */         return 32;
/*   62:     */       }
/*   63:  56 */       if (((paramLong1 & 0x40B0000) != 0L) || ((paramLong2 & 0x2020) != 0L)) {
/*   64:  57 */         return 32;
/*   65:     */       }
/*   66:  58 */       return -1;
/*   67:     */     case 4: 
/*   68:  60 */       if (((paramLong1 & 0xAC06000) != 0L) || ((paramLong2 & 0x7DFCF) != 0L))
/*   69:     */       {
/*   70:  62 */         if (this.jjmatchedPos != 4)
/*   71:     */         {
/*   72:  64 */           this.jjmatchedKind = 91;
/*   73:  65 */           this.jjmatchedPos = 4;
/*   74:     */         }
/*   75:  67 */         return 32;
/*   76:     */       }
/*   77:  69 */       if ((paramLong1 & 0xF0348000) != 0L) {
/*   78:  70 */         return 32;
/*   79:     */       }
/*   80:  71 */       return -1;
/*   81:     */     case 5: 
/*   82:  73 */       if (((paramLong1 & 0x48C06000) != 0L) || ((paramLong2 & 0x6DD87) != 0L))
/*   83:     */       {
/*   84:  75 */         this.jjmatchedKind = 91;
/*   85:  76 */         this.jjmatchedPos = 5;
/*   86:  77 */         return 32;
/*   87:     */       }
/*   88:  79 */       if (((paramLong1 & 0x2000000) != 0L) || ((paramLong2 & 0x10248) != 0L)) {
/*   89:  80 */         return 32;
/*   90:     */       }
/*   91:  81 */       return -1;
/*   92:     */     case 6: 
/*   93:  83 */       if (((paramLong1 & 0x402000) != 0L) || ((paramLong2 & 0x45007) != 0L))
/*   94:     */       {
/*   95:  85 */         if (this.jjmatchedPos != 6)
/*   96:     */         {
/*   97:  87 */           this.jjmatchedKind = 91;
/*   98:  88 */           this.jjmatchedPos = 6;
/*   99:     */         }
/*  100:  90 */         return 32;
/*  101:     */       }
/*  102:  92 */       if (((paramLong1 & 0x48804000) != 0L) || ((paramLong2 & 0x28D80) != 0L)) {
/*  103:  93 */         return 32;
/*  104:     */       }
/*  105:  94 */       return -1;
/*  106:     */     case 7: 
/*  107:  96 */       if (((paramLong1 & 0x0) != 0L) || ((paramLong2 & 0x40003) != 0L))
/*  108:     */       {
/*  109:  98 */         this.jjmatchedKind = 91;
/*  110:  99 */         this.jjmatchedPos = 7;
/*  111: 100 */         return 32;
/*  112:     */       }
/*  113: 102 */       if (((paramLong1 & 0x402000) != 0L) || ((paramLong2 & 0x5804) != 0L)) {
/*  114: 103 */         return 32;
/*  115:     */       }
/*  116: 104 */       return -1;
/*  117:     */     case 8: 
/*  118: 106 */       if (((paramLong1 & 0x0) != 0L) || ((paramLong2 & 0x3) != 0L))
/*  119:     */       {
/*  120: 108 */         this.jjmatchedKind = 91;
/*  121: 109 */         this.jjmatchedPos = 8;
/*  122: 110 */         return 32;
/*  123:     */       }
/*  124: 112 */       if (((paramLong1 & 0x0) != 0L) || ((paramLong2 & 0x40000) != 0L)) {
/*  125: 113 */         return 32;
/*  126:     */       }
/*  127: 114 */       return -1;
/*  128:     */     case 9: 
/*  129: 116 */       if (((paramLong1 & 0x0) != 0L) || ((paramLong2 & 0x3) != 0L))
/*  130:     */       {
/*  131: 118 */         this.jjmatchedKind = 91;
/*  132: 119 */         this.jjmatchedPos = 9;
/*  133: 120 */         return 32;
/*  134:     */       }
/*  135: 122 */       if ((paramLong1 & 0x0) != 0L) {
/*  136: 123 */         return 32;
/*  137:     */       }
/*  138: 124 */       return -1;
/*  139:     */     case 10: 
/*  140: 126 */       if (((paramLong1 & 0x0) != 0L) || ((paramLong2 & 1L) != 0L))
/*  141:     */       {
/*  142: 128 */         this.jjmatchedKind = 91;
/*  143: 129 */         this.jjmatchedPos = 10;
/*  144: 130 */         return 32;
/*  145:     */       }
/*  146: 132 */       if ((paramLong2 & 0x2) != 0L) {
/*  147: 133 */         return 32;
/*  148:     */       }
/*  149: 134 */       return -1;
/*  150:     */     }
/*  151: 136 */     return -1;
/*  152:     */   }
/*  153:     */   
/*  154:     */   private final int jjStartNfa_0(int paramInt, long paramLong1, long paramLong2, long paramLong3)
/*  155:     */   {
/*  156: 141 */     return jjMoveNfa_0(jjStopStringLiteralDfa_0(paramInt, paramLong1, paramLong2, paramLong3), paramInt + 1);
/*  157:     */   }
/*  158:     */   
/*  159:     */   private final int jjStopAtPos(int paramInt1, int paramInt2)
/*  160:     */   {
/*  161: 145 */     this.jjmatchedKind = paramInt2;
/*  162: 146 */     this.jjmatchedPos = paramInt1;
/*  163: 147 */     return paramInt1 + 1;
/*  164:     */   }
/*  165:     */   
/*  166:     */   private final int jjStartNfaWithStates_0(int paramInt1, int paramInt2, int paramInt3)
/*  167:     */   {
/*  168: 151 */     this.jjmatchedKind = paramInt2;
/*  169: 152 */     this.jjmatchedPos = paramInt1;
/*  170:     */     try
/*  171:     */     {
/*  172: 153 */       this.curChar = this.input_stream.readChar();
/*  173:     */     }
/*  174:     */     catch (IOException localIOException)
/*  175:     */     {
/*  176: 154 */       return paramInt1 + 1;
/*  177:     */     }
/*  178: 155 */     return jjMoveNfa_0(paramInt3, paramInt1 + 1);
/*  179:     */   }
/*  180:     */   
/*  181:     */   private final int jjMoveStringLiteralDfa0_0()
/*  182:     */   {
/*  183: 159 */     switch (this.curChar)
/*  184:     */     {
/*  185:     */     case '\t': 
/*  186: 162 */       return jjStopAtPos(0, 2);
/*  187:     */     case '\n': 
/*  188: 164 */       return jjStopAtPos(0, 3);
/*  189:     */     case '\f': 
/*  190: 166 */       return jjStopAtPos(0, 5);
/*  191:     */     case '\r': 
/*  192: 168 */       return jjStopAtPos(0, 4);
/*  193:     */     case ' ': 
/*  194: 170 */       return jjStopAtPos(0, 1);
/*  195:     */     case '!': 
/*  196: 172 */       this.jjmatchedKind = 106;
/*  197: 173 */       return jjMoveStringLiteralDfa1_0(0L, 562949953421312L, 0L);
/*  198:     */     case '%': 
/*  199: 175 */       this.jjmatchedKind = 125;
/*  200: 176 */       return jjMoveStringLiteralDfa1_0(0L, 0L, 256L);
/*  201:     */     case '&': 
/*  202: 178 */       this.jjmatchedKind = 122;
/*  203: 179 */       return jjMoveStringLiteralDfa1_0(0L, 2251799813685248L, 32L);
/*  204:     */     case '(': 
/*  205: 181 */       return jjStopAtPos(0, 94);
/*  206:     */     case ')': 
/*  207: 183 */       return jjStopAtPos(0, 95);
/*  208:     */     case '*': 
/*  209: 185 */       this.jjmatchedKind = 120;
/*  210: 186 */       return jjMoveStringLiteralDfa1_0(0L, 0L, 8L);
/*  211:     */     case '+': 
/*  212: 188 */       this.jjmatchedKind = 118;
/*  213: 189 */       return jjMoveStringLiteralDfa1_0(0L, 4503599627370496L, 2L);
/*  214:     */     case ',': 
/*  215: 191 */       return jjStopAtPos(0, 101);
/*  216:     */     case '-': 
/*  217: 193 */       this.jjmatchedKind = 119;
/*  218: 194 */       return jjMoveStringLiteralDfa1_0(0L, 9007199254740992L, 4L);
/*  219:     */     case '.': 
/*  220: 196 */       return jjStartNfaWithStates_0(0, 102, 8);
/*  221:     */     case '/': 
/*  222: 198 */       this.jjmatchedKind = 121;
/*  223: 199 */       return jjMoveStringLiteralDfa1_0(320L, 16L, 16L);
/*  224:     */     case ':': 
/*  225: 201 */       return jjStopAtPos(0, 109);
/*  226:     */     case ';': 
/*  227: 203 */       return jjStopAtPos(0, 100);
/*  228:     */     case '<': 
/*  229: 205 */       this.jjmatchedKind = 105;
/*  230: 206 */       return jjMoveStringLiteralDfa1_0(0L, 4611826755915743232L, 512L);
/*  231:     */     case '=': 
/*  232: 208 */       this.jjmatchedKind = 103;
/*  233: 209 */       return jjMoveStringLiteralDfa1_0(0L, 70368744177664L, 0L);
/*  234:     */     case '>': 
/*  235: 211 */       this.jjmatchedKind = 104;
/*  236: 212 */       return jjMoveStringLiteralDfa1_0(0L, -9223090561878065152L, 3073L);
/*  237:     */     case '?': 
/*  238: 214 */       return jjStopAtPos(0, 108);
/*  239:     */     case '[': 
/*  240: 216 */       return jjStopAtPos(0, 98);
/*  241:     */     case ']': 
/*  242: 218 */       return jjStopAtPos(0, 99);
/*  243:     */     case '^': 
/*  244: 220 */       this.jjmatchedKind = 124;
/*  245: 221 */       return jjMoveStringLiteralDfa1_0(0L, 0L, 128L);
/*  246:     */     case 'a': 
/*  247: 223 */       return jjMoveStringLiteralDfa1_0(8192L, 0L, 0L);
/*  248:     */     case 'b': 
/*  249: 225 */       return jjMoveStringLiteralDfa1_0(114688L, 256L, 0L);
/*  250:     */     case 'c': 
/*  251: 227 */       return jjMoveStringLiteralDfa1_0(8257536L, 4096L, 0L);
/*  252:     */     case 'd': 
/*  253: 229 */       return jjMoveStringLiteralDfa1_0(58720256L, 32768L, 0L);
/*  254:     */     case 'e': 
/*  255: 231 */       return jjMoveStringLiteralDfa1_0(201326592L, 0L, 0L);
/*  256:     */     case 'f': 
/*  257: 233 */       return jjMoveStringLiteralDfa1_0(8321499136L, 1L, 0L);
/*  258:     */     case 'g': 
/*  259: 235 */       return jjMoveStringLiteralDfa1_0(8589934592L, 65536L, 0L);
/*  260:     */     case 'i': 
/*  261: 237 */       return jjMoveStringLiteralDfa1_0(1082331758592L, 0L, 0L);
/*  262:     */     case 'l': 
/*  263: 239 */       return jjMoveStringLiteralDfa1_0(1099511627776L, 2L, 0L);
/*  264:     */     case 'm': 
/*  265: 241 */       return jjMoveStringLiteralDfa1_0(0L, 8L, 0L);
/*  266:     */     case 'n': 
/*  267: 243 */       return jjMoveStringLiteralDfa1_0(15393162788864L, 96L, 0L);
/*  268:     */     case 'o': 
/*  269: 245 */       return jjMoveStringLiteralDfa1_0(0L, 8320L, 0L);
/*  270:     */     case 'p': 
/*  271: 247 */       return jjMoveStringLiteralDfa1_0(263882790666240L, 4L, 0L);
/*  272:     */     case 'r': 
/*  273: 249 */       return jjMoveStringLiteralDfa1_0(281474976710656L, 393216L, 0L);
/*  274:     */     case 's': 
/*  275: 251 */       return jjMoveStringLiteralDfa1_0(-9205920588298715136L, 19968L, 0L);
/*  276:     */     case 't': 
/*  277: 253 */       return jjMoveStringLiteralDfa1_0(1134907106097364992L, 0L, 0L);
/*  278:     */     case 'v': 
/*  279: 255 */       return jjMoveStringLiteralDfa1_0(3458764513820540928L, 0L, 0L);
/*  280:     */     case 'w': 
/*  281: 257 */       return jjMoveStringLiteralDfa1_0(4611686018427387904L, 0L, 0L);
/*  282:     */     case '{': 
/*  283: 259 */       return jjStopAtPos(0, 96);
/*  284:     */     case '|': 
/*  285: 261 */       this.jjmatchedKind = 123;
/*  286: 262 */       return jjMoveStringLiteralDfa1_0(0L, 1125899906842624L, 64L);
/*  287:     */     case '}': 
/*  288: 264 */       return jjStopAtPos(0, 97);
/*  289:     */     case '~': 
/*  290: 266 */       return jjStopAtPos(0, 107);
/*  291:     */     }
/*  292: 268 */     return jjMoveNfa_0(3, 0);
/*  293:     */   }
/*  294:     */   
/*  295:     */   private final int jjMoveStringLiteralDfa1_0(long paramLong1, long paramLong2, long paramLong3)
/*  296:     */   {
/*  297:     */     try
/*  298:     */     {
/*  299: 273 */       this.curChar = this.input_stream.readChar();
/*  300:     */     }
/*  301:     */     catch (IOException localIOException)
/*  302:     */     {
/*  303: 275 */       jjStopStringLiteralDfa_0(0, paramLong1, paramLong2, paramLong3);
/*  304: 276 */       return 1;
/*  305:     */     }
/*  306: 278 */     switch (this.curChar)
/*  307:     */     {
/*  308:     */     case '&': 
/*  309: 281 */       if ((paramLong2 & 0x0) != 0L) {
/*  310: 282 */         return jjStopAtPos(1, 115);
/*  311:     */       }
/*  312:     */       break;
/*  313:     */     case '*': 
/*  314: 285 */       if ((paramLong1 & 0x100) != 0L) {
/*  315: 286 */         return jjStartNfaWithStates_0(1, 8, 0);
/*  316:     */       }
/*  317:     */       break;
/*  318:     */     case '+': 
/*  319: 289 */       if ((paramLong2 & 0x0) != 0L) {
/*  320: 290 */         return jjStopAtPos(1, 116);
/*  321:     */       }
/*  322:     */       break;
/*  323:     */     case '-': 
/*  324: 293 */       if ((paramLong2 & 0x0) != 0L) {
/*  325: 294 */         return jjStopAtPos(1, 117);
/*  326:     */       }
/*  327:     */       break;
/*  328:     */     case '/': 
/*  329: 297 */       if ((paramLong1 & 0x40) != 0L)
/*  330:     */       {
/*  331: 299 */         this.jjmatchedKind = 6;
/*  332: 300 */         this.jjmatchedPos = 1;
/*  333:     */       }
/*  334: 302 */       return jjMoveStringLiteralDfa2_0(paramLong1, 0L, paramLong2, 16L, paramLong3, 0L);
/*  335:     */     case '<': 
/*  336: 304 */       if ((paramLong2 & 0x0) != 0L)
/*  337:     */       {
/*  338: 306 */         this.jjmatchedKind = 126;
/*  339: 307 */         this.jjmatchedPos = 1;
/*  340:     */       }
/*  341: 309 */       return jjMoveStringLiteralDfa2_0(paramLong1, 0L, paramLong2, 0L, paramLong3, 512L);
/*  342:     */     case '=': 
/*  343: 311 */       if ((paramLong2 & 0x0) != 0L) {
/*  344: 312 */         return jjStopAtPos(1, 110);
/*  345:     */       }
/*  346: 313 */       if ((paramLong2 & 0x0) != 0L) {
/*  347: 314 */         return jjStopAtPos(1, 111);
/*  348:     */       }
/*  349: 315 */       if ((paramLong2 & 0x0) != 0L) {
/*  350: 316 */         return jjStopAtPos(1, 112);
/*  351:     */       }
/*  352: 317 */       if ((paramLong2 & 0x0) != 0L) {
/*  353: 318 */         return jjStopAtPos(1, 113);
/*  354:     */       }
/*  355: 319 */       if ((paramLong3 & 0x2) != 0L) {
/*  356: 320 */         return jjStopAtPos(1, 129);
/*  357:     */       }
/*  358: 321 */       if ((paramLong3 & 0x4) != 0L) {
/*  359: 322 */         return jjStopAtPos(1, 130);
/*  360:     */       }
/*  361: 323 */       if ((paramLong3 & 0x8) != 0L) {
/*  362: 324 */         return jjStopAtPos(1, 131);
/*  363:     */       }
/*  364: 325 */       if ((paramLong3 & 0x10) != 0L) {
/*  365: 326 */         return jjStopAtPos(1, 132);
/*  366:     */       }
/*  367: 327 */       if ((paramLong3 & 0x20) != 0L) {
/*  368: 328 */         return jjStopAtPos(1, 133);
/*  369:     */       }
/*  370: 329 */       if ((paramLong3 & 0x40) != 0L) {
/*  371: 330 */         return jjStopAtPos(1, 134);
/*  372:     */       }
/*  373: 331 */       if ((paramLong3 & 0x80) != 0L) {
/*  374: 332 */         return jjStopAtPos(1, 135);
/*  375:     */       }
/*  376: 333 */       if ((paramLong3 & 0x100) != 0L) {
/*  377: 334 */         return jjStopAtPos(1, 136);
/*  378:     */       }
/*  379:     */       break;
/*  380:     */     case '>': 
/*  381: 337 */       if ((paramLong2 & 0x0) != 0L)
/*  382:     */       {
/*  383: 339 */         this.jjmatchedKind = 127;
/*  384: 340 */         this.jjmatchedPos = 1;
/*  385:     */       }
/*  386: 342 */       return jjMoveStringLiteralDfa2_0(paramLong1, 0L, paramLong2, 0L, paramLong3, 3073L);
/*  387:     */     case 'a': 
/*  388: 344 */       return jjMoveStringLiteralDfa2_0(paramLong1, 19791478128640L, paramLong2, 270L, paramLong3, 0L);
/*  389:     */     case 'b': 
/*  390: 346 */       return jjMoveStringLiteralDfa2_0(paramLong1, 8192L, paramLong2, 0L, paramLong3, 0L);
/*  391:     */     case 'c': 
/*  392: 348 */       return jjMoveStringLiteralDfa2_0(paramLong1, 0L, paramLong2, 16384L, paramLong3, 0L);
/*  393:     */     case 'e': 
/*  394: 350 */       return jjMoveStringLiteralDfa2_0(paramLong1, 285873031610368L, paramLong2, 265216L, paramLong3, 0L);
/*  395:     */     case 'f': 
/*  396: 352 */       if ((paramLong1 & 0x0) != 0L) {
/*  397: 353 */         return jjStartNfaWithStates_0(1, 34, 32);
/*  398:     */       }
/*  399:     */       break;
/*  400:     */     case 'h': 
/*  401: 356 */       return jjMoveStringLiteralDfa2_0(paramLong1, -4485022278907068416L, paramLong2, 0L, paramLong3, 0L);
/*  402:     */     case 'i': 
/*  403: 358 */       return jjMoveStringLiteralDfa2_0(paramLong1, 1610612736L, paramLong2, 513L, paramLong3, 0L);
/*  404:     */     case 'l': 
/*  405: 360 */       return jjMoveStringLiteralDfa2_0(paramLong1, 2215641088L, paramLong2, 0L, paramLong3, 0L);
/*  406:     */     case 'm': 
/*  407: 362 */       return jjMoveStringLiteralDfa2_0(paramLong1, 103079215104L, paramLong2, 0L, paramLong3, 0L);
/*  408:     */     case 'n': 
/*  409: 364 */       return jjMoveStringLiteralDfa2_0(paramLong1, 962072674304L, paramLong2, 8192L, paramLong3, 0L);
/*  410:     */     case 'o': 
/*  411: 366 */       if ((paramLong1 & 0x1000000) != 0L)
/*  412:     */       {
/*  413: 368 */         this.jjmatchedKind = 24;
/*  414: 369 */         this.jjmatchedPos = 1;
/*  415:     */       }
/*  416: 371 */       return jjMoveStringLiteralDfa2_0(paramLong1, 3458765626256932864L, paramLong2, 96L, paramLong3, 0L);
/*  417:     */     case 'r': 
/*  418: 373 */       return jjMoveStringLiteralDfa2_0(paramLong1, 1008911869647290368L, paramLong2, 4224L, paramLong3, 0L);
/*  419:     */     case 't': 
/*  420: 375 */       return jjMoveStringLiteralDfa2_0(paramLong1, 1125899906842624L, paramLong2, 0L, paramLong3, 0L);
/*  421:     */     case 'u': 
/*  422: 377 */       return jjMoveStringLiteralDfa2_0(paramLong1, 2401333395062784L, paramLong2, 196608L, paramLong3, 0L);
/*  423:     */     case 'w': 
/*  424: 379 */       return jjMoveStringLiteralDfa2_0(paramLong1, 4503599627370496L, paramLong2, 0L, paramLong3, 0L);
/*  425:     */     case 'x': 
/*  426: 381 */       return jjMoveStringLiteralDfa2_0(paramLong1, 134217728L, paramLong2, 0L, paramLong3, 0L);
/*  427:     */     case 'y': 
/*  428: 383 */       return jjMoveStringLiteralDfa2_0(paramLong1, 9007199254806528L, paramLong2, 32768L, paramLong3, 0L);
/*  429:     */     case '|': 
/*  430: 385 */       if ((paramLong2 & 0x0) != 0L) {
/*  431: 386 */         return jjStopAtPos(1, 114);
/*  432:     */       }
/*  433:     */       break;
/*  434:     */     }
/*  435: 391 */     return jjStartNfa_0(0, paramLong1, paramLong2, paramLong3);
/*  436:     */   }
/*  437:     */   
/*  438:     */   private final int jjMoveStringLiteralDfa2_0(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6)
/*  439:     */   {
/*  440: 395 */     if ((paramLong2 &= paramLong1 | paramLong4 &= paramLong3 | paramLong6 &= paramLong5) == 0L) {
/*  441: 396 */       return jjStartNfa_0(0, paramLong1, paramLong3, paramLong5);
/*  442:     */     }
/*  443:     */     try
/*  444:     */     {
/*  445: 397 */       this.curChar = this.input_stream.readChar();
/*  446:     */     }
/*  447:     */     catch (IOException localIOException)
/*  448:     */     {
/*  449: 399 */       jjStopStringLiteralDfa_0(1, paramLong2, paramLong4, paramLong6);
/*  450: 400 */       return 2;
/*  451:     */     }
/*  452: 402 */     switch (this.curChar)
/*  453:     */     {
/*  454:     */     case '=': 
/*  455: 405 */       if ((paramLong6 & 0x200) != 0L) {
/*  456: 406 */         return jjStopAtPos(2, 137);
/*  457:     */       }
/*  458: 407 */       if ((paramLong6 & 0x400) != 0L) {
/*  459: 408 */         return jjStopAtPos(2, 138);
/*  460:     */       }
/*  461:     */       break;
/*  462:     */     case '>': 
/*  463: 411 */       if ((paramLong6 & 1L) != 0L)
/*  464:     */       {
/*  465: 413 */         this.jjmatchedKind = 128;
/*  466: 414 */         this.jjmatchedPos = 2;
/*  467:     */       }
/*  468: 416 */       return jjMoveStringLiteralDfa3_0(paramLong2, 0L, paramLong4, 0L, paramLong6, 2048L);
/*  469:     */     case 'a': 
/*  470: 418 */       return jjMoveStringLiteralDfa3_0(paramLong2, -9078130948870504448L, paramLong4, 0L, paramLong6, 0L);
/*  471:     */     case 'b': 
/*  472: 420 */       return jjMoveStringLiteralDfa3_0(paramLong2, 140737488355328L, paramLong4, 0L, paramLong6, 0L);
/*  473:     */     case 'c': 
/*  474: 422 */       return jjMoveStringLiteralDfa3_0(paramLong2, 17592186044416L, paramLong4, 3072L, paramLong6, 0L);
/*  475:     */     case 'd': 
/*  476: 424 */       return jjMoveStringLiteralDfa3_0(paramLong2, 0L, paramLong4, 262272L, paramLong6, 0L);
/*  477:     */     case 'e': 
/*  478: 426 */       return jjMoveStringLiteralDfa3_0(paramLong2, 32768L, paramLong4, 0L, paramLong6, 0L);
/*  479:     */     case 'f': 
/*  480: 428 */       return jjMoveStringLiteralDfa3_0(paramLong2, 8388608L, paramLong4, 0L, paramLong6, 0L);
/*  481:     */     case 'h': 
/*  482: 430 */       return jjMoveStringLiteralDfa3_0(paramLong2, 0L, paramLong4, 16384L, paramLong6, 0L);
/*  483:     */     case 'i': 
/*  484: 432 */       return jjMoveStringLiteralDfa3_0(paramLong2, 5787160705543176192L, paramLong4, 69632L, paramLong6, 0L);
/*  485:     */     case 'l': 
/*  486: 434 */       return jjMoveStringLiteralDfa3_0(paramLong2, 2305851805575151616L, paramLong4, 8192L, paramLong6, 0L);
/*  487:     */     case 'n': 
/*  488: 436 */       return jjMoveStringLiteralDfa3_0(paramLong2, 9008300383272960L, paramLong4, 164384L, paramLong6, 0L);
/*  489:     */     case 'o': 
/*  490: 438 */       return jjMoveStringLiteralDfa3_0(paramLong2, 633320845099008L, paramLong4, 16L, paramLong6, 0L);
/*  491:     */     case 'p': 
/*  492: 440 */       return jjMoveStringLiteralDfa3_0(paramLong2, 2251902892900352L, paramLong4, 0L, paramLong6, 0L);
/*  493:     */     case 'r': 
/*  494: 442 */       if ((paramLong2 & 0x0) != 0L) {
/*  495: 443 */         return jjStartNfaWithStates_0(2, 32, 32);
/*  496:     */       }
/*  497: 444 */       return jjMoveStringLiteralDfa3_0(paramLong2, 108086391056891904L, paramLong4, 261L, paramLong6, 0L);
/*  498:     */     case 's': 
/*  499: 446 */       return jjMoveStringLiteralDfa3_0(paramLong2, 137506201600L, paramLong4, 10L, paramLong6, 0L);
/*  500:     */     case 't': 
/*  501: 448 */       if ((paramLong2 & 0x0) != 0L)
/*  502:     */       {
/*  503: 450 */         this.jjmatchedKind = 38;
/*  504: 451 */         this.jjmatchedPos = 2;
/*  505:     */       }
/*  506: 453 */       return jjMoveStringLiteralDfa3_0(paramLong2, 284232480260096L, paramLong4, 0L, paramLong6, 0L);
/*  507:     */     case 'u': 
/*  508: 455 */       return jjMoveStringLiteralDfa3_0(paramLong2, 288230376185266176L, paramLong4, 0L, paramLong6, 0L);
/*  509:     */     case 'w': 
/*  510: 457 */       if ((paramLong2 & 0x0) != 0L) {
/*  511: 458 */         return jjStartNfaWithStates_0(2, 42, 32);
/*  512:     */       }
/*  513: 459 */       return jjMoveStringLiteralDfa3_0(paramLong2, 0L, paramLong4, 64L, paramLong6, 0L);
/*  514:     */     case 'y': 
/*  515: 461 */       if ((paramLong2 & 0x0) != 0L) {
/*  516: 462 */         return jjStartNfaWithStates_0(2, 59, 32);
/*  517:     */       }
/*  518:     */       break;
/*  519:     */     }
/*  520: 467 */     return jjStartNfa_0(1, paramLong2, paramLong4, paramLong6);
/*  521:     */   }
/*  522:     */   
/*  523:     */   private final int jjMoveStringLiteralDfa3_0(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6)
/*  524:     */   {
/*  525: 471 */     if ((paramLong2 &= paramLong1 | paramLong4 &= paramLong3 | paramLong6 &= paramLong5) == 0L) {
/*  526: 472 */       return jjStartNfa_0(1, paramLong1, paramLong3, paramLong5);
/*  527:     */     }
/*  528:     */     try
/*  529:     */     {
/*  530: 473 */       this.curChar = this.input_stream.readChar();
/*  531:     */     }
/*  532:     */     catch (IOException localIOException)
/*  533:     */     {
/*  534: 475 */       jjStopStringLiteralDfa_0(2, paramLong2, paramLong4, paramLong6);
/*  535: 476 */       return 3;
/*  536:     */     }
/*  537: 478 */     switch (this.curChar)
/*  538:     */     {
/*  539:     */     case '=': 
/*  540: 481 */       if ((paramLong6 & 0x800) != 0L) {
/*  541: 482 */         return jjStopAtPos(3, 139);
/*  542:     */       }
/*  543:     */       break;
/*  544:     */     case 'a': 
/*  545: 485 */       return jjMoveStringLiteralDfa4_0(paramLong2, 2305843012980211712L, paramLong4, 32836L, paramLong6, 0L);
/*  546:     */     case 'b': 
/*  547: 487 */       return jjMoveStringLiteralDfa4_0(paramLong2, 33554432L, paramLong4, 0L, paramLong6, 0L);
/*  548:     */     case 'c': 
/*  549: 489 */       return jjMoveStringLiteralDfa4_0(paramLong2, 9007199255003136L, paramLong4, 0L, paramLong6, 0L);
/*  550:     */     case 'd': 
/*  551: 491 */       if ((paramLong2 & 0x0) != 0L) {
/*  552: 492 */         return jjStartNfaWithStates_0(3, 60, 32);
/*  553:     */       }
/*  554: 493 */       return jjMoveStringLiteralDfa4_0(paramLong2, 0L, paramLong4, 65536L, paramLong6, 0L);
/*  555:     */     case 'e': 
/*  556: 495 */       if ((paramLong2 & 0x10000) != 0L) {
/*  557: 496 */         return jjStartNfaWithStates_0(3, 16, 32);
/*  558:     */       }
/*  559: 497 */       if ((paramLong2 & 0x20000) != 0L) {
/*  560: 498 */         return jjStartNfaWithStates_0(3, 17, 32);
/*  561:     */       }
/*  562: 499 */       if ((paramLong2 & 0x4000000) != 0L) {
/*  563: 500 */         return jjStartNfaWithStates_0(3, 26, 32);
/*  564:     */       }
/*  565: 501 */       if ((paramLong2 & 0x0) != 0L) {
/*  566: 502 */         return jjStartNfaWithStates_0(3, 58, 32);
/*  567:     */       }
/*  568: 503 */       if ((paramLong4 & 0x20) != 0L) {
/*  569: 504 */         return jjStartNfaWithStates_0(3, 69, 32);
/*  570:     */       }
/*  571: 505 */       return jjMoveStringLiteralDfa4_0(paramLong2, 2252349703716864L, paramLong4, 16512L, paramLong6, 0L);
/*  572:     */     case 'g': 
/*  573: 507 */       if ((paramLong2 & 0x0) != 0L) {
/*  574: 508 */         return jjStartNfaWithStates_0(3, 40, 32);
/*  575:     */       }
/*  576: 509 */       return jjMoveStringLiteralDfa4_0(paramLong2, 0L, paramLong4, 512L, paramLong6, 0L);
/*  577:     */     case 'i': 
/*  578: 511 */       return jjMoveStringLiteralDfa4_0(paramLong2, 2199023255552L, paramLong4, 0L, paramLong6, 0L);
/*  579:     */     case 'k': 
/*  580: 513 */       return jjMoveStringLiteralDfa4_0(paramLong2, 17592186044416L, paramLong4, 0L, paramLong6, 0L);
/*  581:     */     case 'l': 
/*  582: 515 */       if ((paramLong2 & 0x0) != 0L) {
/*  583: 516 */         return jjStartNfaWithStates_0(3, 43, 32);
/*  584:     */       }
/*  585: 517 */       return jjMoveStringLiteralDfa4_0(paramLong2, 4611826790275497984L, paramLong4, 0L, paramLong6, 0L);
/*  586:     */     case 'm': 
/*  587: 519 */       return jjMoveStringLiteralDfa4_0(paramLong2, 0L, paramLong4, 16L, paramLong6, 0L);
/*  588:     */     case 'n': 
/*  589: 521 */       return jjMoveStringLiteralDfa4_0(paramLong2, 144115188075855872L, paramLong4, 0L, paramLong6, 0L);
/*  590:     */     case 'o': 
/*  591: 523 */       if ((paramLong2 & 0x0) != 0L) {
/*  592: 524 */         return jjStartNfaWithStates_0(3, 33, 32);
/*  593:     */       }
/*  594: 525 */       return jjMoveStringLiteralDfa4_0(paramLong2, 108086459776368640L, paramLong4, 0L, paramLong6, 0L);
/*  595:     */     case 'r': 
/*  596: 527 */       if ((paramLong2 & 0x80000) != 0L) {
/*  597: 528 */         return jjStartNfaWithStates_0(3, 19, 32);
/*  598:     */       }
/*  599: 529 */       return jjMoveStringLiteralDfa4_0(paramLong2, -9222809086901354496L, paramLong4, 256L, paramLong6, 0L);
/*  600:     */     case 's': 
/*  601: 531 */       if ((paramLong2 & 0x0) != 0L) {
/*  602: 532 */         return jjStartNfaWithStates_0(3, 54, 32);
/*  603:     */       }
/*  604: 533 */       return jjMoveStringLiteralDfa4_0(paramLong2, 271581184L, paramLong4, 1L, paramLong6, 0L);
/*  605:     */     case 't': 
/*  606: 535 */       return jjMoveStringLiteralDfa4_0(paramLong2, 5700005721546752L, paramLong4, 138250L, paramLong6, 0L);
/*  607:     */     case 'u': 
/*  608: 537 */       return jjMoveStringLiteralDfa4_0(paramLong2, 281474976710656L, paramLong4, 262144L, paramLong6, 0L);
/*  609:     */     case 'v': 
/*  610: 539 */       return jjMoveStringLiteralDfa4_0(paramLong2, 35184372088832L, paramLong4, 0L, paramLong6, 0L);
/*  611:     */     case 'y': 
/*  612: 541 */       if ((paramLong4 & 0x2000) != 0L) {
/*  613: 542 */         return jjStartNfaWithStates_0(3, 77, 32);
/*  614:     */       }
/*  615:     */       break;
/*  616:     */     }
/*  617: 547 */     return jjStartNfa_0(2, paramLong2, paramLong4, paramLong6);
/*  618:     */   }
/*  619:     */   
/*  620:     */   private final int jjMoveStringLiteralDfa4_0(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6)
/*  621:     */   {
/*  622: 551 */     if ((paramLong2 &= paramLong1 | paramLong4 &= paramLong3 | paramLong6 &= paramLong5) == 0L) {
/*  623: 552 */       return jjStartNfa_0(2, paramLong1, paramLong3, paramLong5);
/*  624:     */     }
/*  625:     */     try
/*  626:     */     {
/*  627: 553 */       this.curChar = this.input_stream.readChar();
/*  628:     */     }
/*  629:     */     catch (IOException localIOException)
/*  630:     */     {
/*  631: 555 */       jjStopStringLiteralDfa_0(3, paramLong2, paramLong4, 0L);
/*  632: 556 */       return 4;
/*  633:     */     }
/*  634: 558 */     switch (this.curChar)
/*  635:     */     {
/*  636:     */     case 'a': 
/*  637: 561 */       return jjMoveStringLiteralDfa5_0(paramLong2, 52913997086720L, paramLong4, 0L);
/*  638:     */     case 'c': 
/*  639: 563 */       return jjMoveStringLiteralDfa5_0(paramLong2, 4503599627370496L, paramLong4, 262144L);
/*  640:     */     case 'd': 
/*  641: 565 */       return jjMoveStringLiteralDfa5_0(paramLong2, 0L, paramLong4, 16384L);
/*  642:     */     case 'e': 
/*  643: 567 */       if ((paramLong2 & 0x10000000) != 0L) {
/*  644: 568 */         return jjStartNfaWithStates_0(4, 28, 32);
/*  645:     */       }
/*  646: 569 */       if ((paramLong2 & 0x0) != 0L) {
/*  647: 570 */         return jjStartNfaWithStates_0(4, 62, 32);
/*  648:     */       }
/*  649: 571 */       return jjMoveStringLiteralDfa5_0(paramLong2, -9223301633750843392L, paramLong4, 65544L);
/*  650:     */     case 'h': 
/*  651: 573 */       if ((paramLong2 & 0x40000) != 0L) {
/*  652: 574 */         return jjStartNfaWithStates_0(4, 18, 32);
/*  653:     */       }
/*  654: 575 */       return jjMoveStringLiteralDfa5_0(paramLong2, 9007199254740992L, paramLong4, 0L);
/*  655:     */     case 'i': 
/*  656: 577 */       return jjMoveStringLiteralDfa5_0(paramLong2, 1266637399392256L, paramLong4, 138560L);
/*  657:     */     case 'k': 
/*  658: 579 */       if ((paramLong2 & 0x8000) != 0L) {
/*  659: 580 */         return jjStartNfaWithStates_0(4, 15, 32);
/*  660:     */       }
/*  661:     */       break;
/*  662:     */     case 'l': 
/*  663: 583 */       if ((paramLong2 & 0x20000000) != 0L)
/*  664:     */       {
/*  665: 585 */         this.jjmatchedKind = 29;
/*  666: 586 */         this.jjmatchedPos = 4;
/*  667:     */       }
/*  668: 588 */       return jjMoveStringLiteralDfa5_0(paramLong2, 1107296256L, paramLong4, 516L);
/*  669:     */     case 'm': 
/*  670: 590 */       return jjMoveStringLiteralDfa5_0(paramLong2, 0L, paramLong4, 32768L);
/*  671:     */     case 'n': 
/*  672: 592 */       return jjMoveStringLiteralDfa5_0(paramLong2, 134217728L, paramLong4, 0L);
/*  673:     */     case 'p': 
/*  674: 594 */       if ((paramLong4 & 0x10) != 0L) {
/*  675: 595 */         return jjStopAtPos(4, 68);
/*  676:     */       }
/*  677: 596 */       return jjMoveStringLiteralDfa5_0(paramLong2, 0L, paramLong4, 2L);
/*  678:     */     case 'r': 
/*  679: 598 */       if ((paramLong2 & 0x0) != 0L) {
/*  680: 599 */         return jjStartNfaWithStates_0(4, 51, 32);
/*  681:     */       }
/*  682: 600 */       return jjMoveStringLiteralDfa5_0(paramLong2, 282093452009472L, paramLong4, 128L);
/*  683:     */     case 's': 
/*  684: 602 */       if ((paramLong2 & 0x100000) != 0L) {
/*  685: 603 */         return jjStartNfaWithStates_0(4, 20, 32);
/*  686:     */       }
/*  687: 604 */       return jjMoveStringLiteralDfa5_0(paramLong2, 144115188075855872L, paramLong4, 0L);
/*  688:     */     case 't': 
/*  689: 606 */       if ((paramLong2 & 0x200000) != 0L) {
/*  690: 607 */         return jjStartNfaWithStates_0(4, 21, 32);
/*  691:     */       }
/*  692: 608 */       if ((paramLong2 & 0x80000000) != 0L) {
/*  693: 609 */         return jjStartNfaWithStates_0(4, 31, 32);
/*  694:     */       }
/*  695: 610 */       if ((paramLong2 & 0x0) != 0L) {
/*  696: 611 */         return jjStartNfaWithStates_0(4, 49, 32);
/*  697:     */       }
/*  698: 612 */       return jjMoveStringLiteralDfa5_0(paramLong2, 2305843009213693952L, paramLong4, 1L);
/*  699:     */     case 'u': 
/*  700: 614 */       return jjMoveStringLiteralDfa5_0(paramLong2, 8388608L, paramLong4, 0L);
/*  701:     */     case 'v': 
/*  702: 616 */       return jjMoveStringLiteralDfa5_0(paramLong2, 2199023255552L, paramLong4, 0L);
/*  703:     */     case 'w': 
/*  704: 618 */       if ((paramLong2 & 0x0) != 0L)
/*  705:     */       {
/*  706: 620 */         this.jjmatchedKind = 55;
/*  707: 621 */         this.jjmatchedPos = 4;
/*  708:     */       }
/*  709: 623 */       return jjMoveStringLiteralDfa5_0(paramLong2, 72057594037927936L, paramLong4, 0L);
/*  710:     */     }
/*  711: 627 */     return jjStartNfa_0(3, paramLong2, paramLong4, 0L);
/*  712:     */   }
/*  713:     */   
/*  714:     */   private final int jjMoveStringLiteralDfa5_0(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
/*  715:     */   {
/*  716: 631 */     if ((paramLong2 &= paramLong1 | paramLong4 &= paramLong3) == 0L) {
/*  717: 632 */       return jjStartNfa_0(3, paramLong1, paramLong3, 0L);
/*  718:     */     }
/*  719:     */     try
/*  720:     */     {
/*  721: 633 */       this.curChar = this.input_stream.readChar();
/*  722:     */     }
/*  723:     */     catch (IOException localIOException)
/*  724:     */     {
/*  725: 635 */       jjStopStringLiteralDfa_0(4, paramLong2, paramLong4, 0L);
/*  726: 636 */       return 5;
/*  727:     */     }
/*  728: 638 */     switch (this.curChar)
/*  729:     */     {
/*  730:     */     case 'a': 
/*  731: 641 */       return jjMoveStringLiteralDfa6_0(paramLong2, 24576L, paramLong4, 0L);
/*  732:     */     case 'c': 
/*  733: 643 */       if ((paramLong2 & 0x0) != 0L) {
/*  734: 644 */         return jjStartNfaWithStates_0(5, 47, 32);
/*  735:     */       }
/*  736: 645 */       if ((paramLong2 & 0x0) != 0L) {
/*  737: 646 */         return jjStartNfaWithStates_0(5, 50, 32);
/*  738:     */       }
/*  739: 647 */       return jjMoveStringLiteralDfa6_0(paramLong2, 70368744177664L, paramLong4, 4096L);
/*  740:     */     case 'd': 
/*  741: 649 */       if ((paramLong2 & 0x0) != 0L) {
/*  742: 650 */         return jjStartNfaWithStates_0(5, 63, 32);
/*  743:     */       }
/*  744: 651 */       if ((paramLong4 & 0x10000) != 0L) {
/*  745: 652 */         return jjStartNfaWithStates_0(5, 80, 32);
/*  746:     */       }
/*  747: 653 */       return jjMoveStringLiteralDfa6_0(paramLong2, 134217728L, paramLong4, 0L);
/*  748:     */     case 'e': 
/*  749: 655 */       if ((paramLong2 & 0x2000000) != 0L) {
/*  750: 656 */         return jjStartNfaWithStates_0(5, 25, 32);
/*  751:     */       }
/*  752: 657 */       if ((paramLong2 & 0x0) != 0L) {
/*  753: 658 */         return jjStartNfaWithStates_0(5, 41, 32);
/*  754:     */       }
/*  755: 659 */       if ((paramLong4 & 0x200) != 0L) {
/*  756: 660 */         return jjStartNfaWithStates_0(5, 73, 32);
/*  757:     */       }
/*  758: 661 */       return jjMoveStringLiteralDfa6_0(paramLong2, 0L, paramLong4, 384L);
/*  759:     */     case 'f': 
/*  760: 663 */       return jjMoveStringLiteralDfa6_0(paramLong2, 549755813888L, paramLong4, 0L);
/*  761:     */     case 'g': 
/*  762: 665 */       return jjMoveStringLiteralDfa6_0(paramLong2, 17592186044416L, paramLong4, 0L);
/*  763:     */     case 'h': 
/*  764: 667 */       if ((paramLong2 & 0x0) != 0L) {
/*  765: 668 */         return jjStartNfaWithStates_0(5, 52, 32);
/*  766:     */       }
/*  767:     */       break;
/*  768:     */     case 'i': 
/*  769: 671 */       return jjMoveStringLiteralDfa6_0(paramLong2, 2449958197289549824L, paramLong4, 32768L);
/*  770:     */     case 'l': 
/*  771: 673 */       return jjMoveStringLiteralDfa6_0(paramLong2, 1082130432L, paramLong4, 4L);
/*  772:     */     case 'm': 
/*  773: 675 */       return jjMoveStringLiteralDfa6_0(paramLong2, 34359738368L, paramLong4, 131072L);
/*  774:     */     case 'n': 
/*  775: 677 */       if ((paramLong2 & 0x0) != 0L) {
/*  776: 678 */         return jjStartNfaWithStates_0(5, 48, 32);
/*  777:     */       }
/*  778: 679 */       return jjMoveStringLiteralDfa6_0(paramLong2, 137443147776L, paramLong4, 0L);
/*  779:     */     case 'o': 
/*  780: 681 */       return jjMoveStringLiteralDfa6_0(paramLong2, 0L, paramLong4, 3072L);
/*  781:     */     case 'p': 
/*  782: 683 */       return jjMoveStringLiteralDfa6_0(paramLong2, 0L, paramLong4, 1L);
/*  783:     */     case 'r': 
/*  784: 685 */       if ((paramLong4 & 0x8) != 0L) {
/*  785: 686 */         return jjStartNfaWithStates_0(5, 67, 32);
/*  786:     */       }
/*  787: 687 */       return jjMoveStringLiteralDfa6_0(paramLong2, 9007199254740992L, paramLong4, 2L);
/*  788:     */     case 's': 
/*  789: 689 */       if ((paramLong2 & 0x0) != 0L) {
/*  790: 690 */         return jjStartNfaWithStates_0(5, 56, 32);
/*  791:     */       }
/*  792:     */       break;
/*  793:     */     case 't': 
/*  794: 693 */       if ((paramLong2 & 0x0) != 0L) {
/*  795: 694 */         return jjStartNfaWithStates_0(5, 36, 32);
/*  796:     */       }
/*  797: 695 */       if ((paramLong4 & 0x40) != 0L) {
/*  798: 696 */         return jjStartNfaWithStates_0(5, 70, 32);
/*  799:     */       }
/*  800: 697 */       return jjMoveStringLiteralDfa6_0(paramLong2, 35184372088832L, paramLong4, 262144L);
/*  801:     */     case 'u': 
/*  802: 699 */       return jjMoveStringLiteralDfa6_0(paramLong2, 0L, paramLong4, 16384L);
/*  803:     */     }
/*  804: 703 */     return jjStartNfa_0(4, paramLong2, paramLong4, 0L);
/*  805:     */   }
/*  806:     */   
/*  807:     */   private final int jjMoveStringLiteralDfa6_0(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
/*  808:     */   {
/*  809: 707 */     if ((paramLong2 &= paramLong1 | paramLong4 &= paramLong3) == 0L) {
/*  810: 708 */       return jjStartNfa_0(4, paramLong1, paramLong3, 0L);
/*  811:     */     }
/*  812:     */     try
/*  813:     */     {
/*  814: 709 */       this.curChar = this.input_stream.readChar();
/*  815:     */     }
/*  816:     */     catch (IOException localIOException)
/*  817:     */     {
/*  818: 711 */       jjStopStringLiteralDfa_0(5, paramLong2, paramLong4, 0L);
/*  819: 712 */       return 6;
/*  820:     */     }
/*  821: 714 */     switch (this.curChar)
/*  822:     */     {
/*  823:     */     case 'a': 
/*  824: 717 */       return jjMoveStringLiteralDfa7_0(paramLong2, 549755813888L, paramLong4, 4096L);
/*  825:     */     case 'c': 
/*  826: 719 */       if ((paramLong4 & 0x8000) != 0L) {
/*  827: 720 */         return jjStartNfaWithStates_0(6, 79, 32);
/*  828:     */       }
/*  829: 721 */       return jjMoveStringLiteralDfa7_0(paramLong2, 137438961664L, paramLong4, 0L);
/*  830:     */     case 'd': 
/*  831: 723 */       if ((paramLong4 & 0x80) != 0L) {
/*  832: 724 */         return jjStartNfaWithStates_0(6, 71, 32);
/*  833:     */       }
/*  834:     */       break;
/*  835:     */     case 'e': 
/*  836: 727 */       if ((paramLong2 & 0x0) != 0L) {
/*  837: 728 */         return jjStartNfaWithStates_0(6, 44, 32);
/*  838:     */       }
/*  839: 729 */       if ((paramLong2 & 0x0) != 0L) {
/*  840: 730 */         return jjStartNfaWithStates_0(6, 45, 32);
/*  841:     */       }
/*  842: 731 */       if ((paramLong4 & 0x20000) != 0L) {
/*  843: 732 */         return jjStartNfaWithStates_0(6, 81, 32);
/*  844:     */       }
/*  845: 733 */       return jjMoveStringLiteralDfa7_0(paramLong2, 144115222435594240L, paramLong4, 4L);
/*  846:     */     case 'i': 
/*  847: 735 */       return jjMoveStringLiteralDfa7_0(paramLong2, 0L, paramLong4, 262146L);
/*  848:     */     case 'l': 
/*  849: 737 */       return jjMoveStringLiteralDfa7_0(paramLong2, 2305843009213693952L, paramLong4, 16384L);
/*  850:     */     case 'n': 
/*  851: 739 */       if ((paramLong2 & 0x4000) != 0L) {
/*  852: 740 */         return jjStartNfaWithStates_0(6, 14, 32);
/*  853:     */       }
/*  854: 741 */       if ((paramLong4 & 0x400) != 0L)
/*  855:     */       {
/*  856: 743 */         this.jjmatchedKind = 74;
/*  857: 744 */         this.jjmatchedPos = 6;
/*  858:     */       }
/*  859: 746 */       return jjMoveStringLiteralDfa7_0(paramLong2, 0L, paramLong4, 2048L);
/*  860:     */     case 'o': 
/*  861: 748 */       return jjMoveStringLiteralDfa7_0(paramLong2, 9007199254740992L, paramLong4, 0L);
/*  862:     */     case 'r': 
/*  863: 750 */       if ((paramLong4 & 0x100) != 0L) {
/*  864: 751 */         return jjStartNfaWithStates_0(6, 72, 32);
/*  865:     */       }
/*  866: 752 */       return jjMoveStringLiteralDfa7_0(paramLong2, 0L, paramLong4, 1L);
/*  867:     */     case 's': 
/*  868: 754 */       if ((paramLong2 & 0x8000000) != 0L) {
/*  869: 755 */         return jjStartNfaWithStates_0(6, 27, 32);
/*  870:     */       }
/*  871:     */       break;
/*  872:     */     case 't': 
/*  873: 758 */       if ((paramLong2 & 0x800000) != 0L) {
/*  874: 759 */         return jjStartNfaWithStates_0(6, 23, 32);
/*  875:     */       }
/*  876: 760 */       return jjMoveStringLiteralDfa7_0(paramLong2, 70368744177664L, paramLong4, 0L);
/*  877:     */     case 'u': 
/*  878: 762 */       return jjMoveStringLiteralDfa7_0(paramLong2, 4194304L, paramLong4, 0L);
/*  879:     */     case 'y': 
/*  880: 764 */       if ((paramLong2 & 0x40000000) != 0L) {
/*  881: 765 */         return jjStartNfaWithStates_0(6, 30, 32);
/*  882:     */       }
/*  883:     */       break;
/*  884:     */     }
/*  885: 770 */     return jjStartNfa_0(5, paramLong2, paramLong4, 0L);
/*  886:     */   }
/*  887:     */   
/*  888:     */   private final int jjMoveStringLiteralDfa7_0(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
/*  889:     */   {
/*  890: 774 */     if ((paramLong2 &= paramLong1 | paramLong4 &= paramLong3) == 0L) {
/*  891: 775 */       return jjStartNfa_0(5, paramLong1, paramLong3, 0L);
/*  892:     */     }
/*  893:     */     try
/*  894:     */     {
/*  895: 776 */       this.curChar = this.input_stream.readChar();
/*  896:     */     }
/*  897:     */     catch (IOException localIOException)
/*  898:     */     {
/*  899: 778 */       jjStopStringLiteralDfa_0(6, paramLong2, paramLong4, 0L);
/*  900: 779 */       return 7;
/*  901:     */     }
/*  902: 781 */     switch (this.curChar)
/*  903:     */     {
/*  904:     */     case 'c': 
/*  905: 784 */       return jjMoveStringLiteralDfa8_0(paramLong2, 549755813888L, paramLong4, 0L);
/*  906:     */     case 'e': 
/*  907: 786 */       if ((paramLong2 & 0x400000) != 0L) {
/*  908: 787 */         return jjStartNfaWithStates_0(7, 22, 32);
/*  909:     */       }
/*  910: 788 */       if ((paramLong2 & 0x0) != 0L) {
/*  911: 789 */         return jjStartNfaWithStates_0(7, 61, 32);
/*  912:     */       }
/*  913: 790 */       if ((paramLong4 & 0x4000) != 0L) {
/*  914: 791 */         return jjStartNfaWithStates_0(7, 78, 32);
/*  915:     */       }
/*  916: 792 */       return jjMoveStringLiteralDfa8_0(paramLong2, 70506183131136L, paramLong4, 0L);
/*  917:     */     case 'i': 
/*  918: 794 */       return jjMoveStringLiteralDfa8_0(paramLong2, 0L, paramLong4, 1L);
/*  919:     */     case 'l': 
/*  920: 796 */       if ((paramLong4 & 0x4) != 0L) {
/*  921: 797 */         return jjStartNfaWithStates_0(7, 66, 32);
/*  922:     */       }
/*  923: 798 */       if ((paramLong4 & 0x1000) != 0L) {
/*  924: 799 */         return jjStartNfaWithStates_0(7, 76, 32);
/*  925:     */       }
/*  926:     */       break;
/*  927:     */     case 'n': 
/*  928: 802 */       return jjMoveStringLiteralDfa8_0(paramLong2, 153122421690335232L, paramLong4, 0L);
/*  929:     */     case 'o': 
/*  930: 804 */       return jjMoveStringLiteralDfa8_0(paramLong2, 0L, paramLong4, 262144L);
/*  931:     */     case 's': 
/*  932: 806 */       if ((paramLong4 & 0x800) != 0L) {
/*  933: 807 */         return jjStartNfaWithStates_0(7, 75, 32);
/*  934:     */       }
/*  935:     */       break;
/*  936:     */     case 't': 
/*  937: 810 */       if ((paramLong2 & 0x2000) != 0L) {
/*  938: 811 */         return jjStartNfaWithStates_0(7, 13, 32);
/*  939:     */       }
/*  940:     */       break;
/*  941:     */     case 'v': 
/*  942: 814 */       return jjMoveStringLiteralDfa8_0(paramLong2, 0L, paramLong4, 2L);
/*  943:     */     }
/*  944: 818 */     return jjStartNfa_0(6, paramLong2, paramLong4, 0L);
/*  945:     */   }
/*  946:     */   
/*  947:     */   private final int jjMoveStringLiteralDfa8_0(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
/*  948:     */   {
/*  949: 822 */     if ((paramLong2 &= paramLong1 | paramLong4 &= paramLong3) == 0L) {
/*  950: 823 */       return jjStartNfa_0(6, paramLong1, paramLong3, 0L);
/*  951:     */     }
/*  952:     */     try
/*  953:     */     {
/*  954: 824 */       this.curChar = this.input_stream.readChar();
/*  955:     */     }
/*  956:     */     catch (IOException localIOException)
/*  957:     */     {
/*  958: 826 */       jjStopStringLiteralDfa_0(7, paramLong2, paramLong4, 0L);
/*  959: 827 */       return 8;
/*  960:     */     }
/*  961: 829 */     switch (this.curChar)
/*  962:     */     {
/*  963:     */     case 'a': 
/*  964: 832 */       return jjMoveStringLiteralDfa9_0(paramLong2, 0L, paramLong4, 2L);
/*  965:     */     case 'd': 
/*  966: 834 */       if ((paramLong2 & 0x0) != 0L) {
/*  967: 835 */         return jjStartNfaWithStates_0(8, 46, 32);
/*  968:     */       }
/*  969:     */       break;
/*  970:     */     case 'e': 
/*  971: 838 */       if ((paramLong2 & 0x0) != 0L) {
/*  972: 839 */         return jjStartNfaWithStates_0(8, 39, 32);
/*  973:     */       }
/*  974:     */       break;
/*  975:     */     case 'i': 
/*  976: 842 */       return jjMoveStringLiteralDfa9_0(paramLong2, 9007199254740992L, paramLong4, 0L);
/*  977:     */     case 'n': 
/*  978: 844 */       if ((paramLong4 & 0x40000) != 0L) {
/*  979: 845 */         return jjStartNfaWithStates_0(8, 82, 32);
/*  980:     */       }
/*  981:     */       break;
/*  982:     */     case 'o': 
/*  983: 848 */       return jjMoveStringLiteralDfa9_0(paramLong2, 137438953472L, paramLong4, 0L);
/*  984:     */     case 't': 
/*  985: 850 */       if ((paramLong2 & 0x0) != 0L) {
/*  986: 851 */         return jjStartNfaWithStates_0(8, 57, 32);
/*  987:     */       }
/*  988: 852 */       return jjMoveStringLiteralDfa9_0(paramLong2, 34359738368L, paramLong4, 0L);
/*  989:     */     case 'v': 
/*  990: 854 */       return jjMoveStringLiteralDfa9_0(paramLong2, 0L, paramLong4, 1L);
/*  991:     */     }
/*  992: 858 */     return jjStartNfa_0(7, paramLong2, paramLong4, 0L);
/*  993:     */   }
/*  994:     */   
/*  995:     */   private final int jjMoveStringLiteralDfa9_0(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
/*  996:     */   {
/*  997: 862 */     if ((paramLong2 &= paramLong1 | paramLong4 &= paramLong3) == 0L) {
/*  998: 863 */       return jjStartNfa_0(7, paramLong1, paramLong3, 0L);
/*  999:     */     }
/* 1000:     */     try
/* 1001:     */     {
/* 1002: 864 */       this.curChar = this.input_stream.readChar();
/* 1003:     */     }
/* 1004:     */     catch (IOException localIOException)
/* 1005:     */     {
/* 1006: 866 */       jjStopStringLiteralDfa_0(8, paramLong2, paramLong4, 0L);
/* 1007: 867 */       return 9;
/* 1008:     */     }
/* 1009: 869 */     switch (this.curChar)
/* 1010:     */     {
/* 1011:     */     case 'a': 
/* 1012: 872 */       return jjMoveStringLiteralDfa10_0(paramLong2, 0L, paramLong4, 1L);
/* 1013:     */     case 'f': 
/* 1014: 874 */       if ((paramLong2 & 0x0) != 0L) {
/* 1015: 875 */         return jjStartNfaWithStates_0(9, 37, 32);
/* 1016:     */       }
/* 1017:     */       break;
/* 1018:     */     case 's': 
/* 1019: 878 */       if ((paramLong2 & 0x0) != 0L) {
/* 1020: 879 */         return jjStartNfaWithStates_0(9, 35, 32);
/* 1021:     */       }
/* 1022:     */       break;
/* 1023:     */     case 't': 
/* 1024: 882 */       return jjMoveStringLiteralDfa10_0(paramLong2, 0L, paramLong4, 2L);
/* 1025:     */     case 'z': 
/* 1026: 884 */       return jjMoveStringLiteralDfa10_0(paramLong2, 9007199254740992L, paramLong4, 0L);
/* 1027:     */     }
/* 1028: 888 */     return jjStartNfa_0(8, paramLong2, paramLong4, 0L);
/* 1029:     */   }
/* 1030:     */   
/* 1031:     */   private final int jjMoveStringLiteralDfa10_0(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
/* 1032:     */   {
/* 1033: 892 */     if ((paramLong2 &= paramLong1 | paramLong4 &= paramLong3) == 0L) {
/* 1034: 893 */       return jjStartNfa_0(8, paramLong1, paramLong3, 0L);
/* 1035:     */     }
/* 1036:     */     try
/* 1037:     */     {
/* 1038: 894 */       this.curChar = this.input_stream.readChar();
/* 1039:     */     }
/* 1040:     */     catch (IOException localIOException)
/* 1041:     */     {
/* 1042: 896 */       jjStopStringLiteralDfa_0(9, paramLong2, paramLong4, 0L);
/* 1043: 897 */       return 10;
/* 1044:     */     }
/* 1045: 899 */     switch (this.curChar)
/* 1046:     */     {
/* 1047:     */     case 'e': 
/* 1048: 902 */       if ((paramLong4 & 0x2) != 0L) {
/* 1049: 903 */         return jjStartNfaWithStates_0(10, 65, 32);
/* 1050:     */       }
/* 1051: 904 */       return jjMoveStringLiteralDfa11_0(paramLong2, 9007199254740992L, paramLong4, 0L);
/* 1052:     */     case 't': 
/* 1053: 906 */       return jjMoveStringLiteralDfa11_0(paramLong2, 0L, paramLong4, 1L);
/* 1054:     */     }
/* 1055: 910 */     return jjStartNfa_0(9, paramLong2, paramLong4, 0L);
/* 1056:     */   }
/* 1057:     */   
/* 1058:     */   private final int jjMoveStringLiteralDfa11_0(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
/* 1059:     */   {
/* 1060: 914 */     if ((paramLong2 &= paramLong1 | paramLong4 &= paramLong3) == 0L) {
/* 1061: 915 */       return jjStartNfa_0(9, paramLong1, paramLong3, 0L);
/* 1062:     */     }
/* 1063:     */     try
/* 1064:     */     {
/* 1065: 916 */       this.curChar = this.input_stream.readChar();
/* 1066:     */     }
/* 1067:     */     catch (IOException localIOException)
/* 1068:     */     {
/* 1069: 918 */       jjStopStringLiteralDfa_0(10, paramLong2, paramLong4, 0L);
/* 1070: 919 */       return 11;
/* 1071:     */     }
/* 1072: 921 */     switch (this.curChar)
/* 1073:     */     {
/* 1074:     */     case 'd': 
/* 1075: 924 */       if ((paramLong2 & 0x0) != 0L) {
/* 1076: 925 */         return jjStartNfaWithStates_0(11, 53, 32);
/* 1077:     */       }
/* 1078:     */       break;
/* 1079:     */     case 'e': 
/* 1080: 928 */       if ((paramLong4 & 1L) != 0L) {
/* 1081: 929 */         return jjStartNfaWithStates_0(11, 64, 32);
/* 1082:     */       }
/* 1083:     */       break;
/* 1084:     */     }
/* 1085: 934 */     return jjStartNfa_0(10, paramLong2, paramLong4, 0L);
/* 1086:     */   }
/* 1087:     */   
/* 1088:     */   private final void jjCheckNAdd(int paramInt)
/* 1089:     */   {
/* 1090: 938 */     if (this.jjrounds[paramInt] != this.jjround)
/* 1091:     */     {
/* 1092: 940 */       this.jjstateSet[(this.jjnewStateCnt++)] = paramInt;
/* 1093: 941 */       this.jjrounds[paramInt] = this.jjround;
/* 1094:     */     }
/* 1095:     */   }
/* 1096:     */   
/* 1097:     */   private final void jjAddStates(int paramInt1, int paramInt2)
/* 1098:     */   {
/* 1099:     */     do
/* 1100:     */     {
/* 1101: 947 */       this.jjstateSet[(this.jjnewStateCnt++)] = jjnextStates[paramInt1];
/* 1102: 948 */     } while (paramInt1++ != paramInt2);
/* 1103:     */   }
/* 1104:     */   
/* 1105:     */   private final void jjCheckNAddTwoStates(int paramInt1, int paramInt2)
/* 1106:     */   {
/* 1107: 952 */     jjCheckNAdd(paramInt1);
/* 1108: 953 */     jjCheckNAdd(paramInt2);
/* 1109:     */   }
/* 1110:     */   
/* 1111:     */   private final void jjCheckNAddStates(int paramInt1, int paramInt2)
/* 1112:     */   {
/* 1113:     */     do
/* 1114:     */     {
/* 1115: 958 */       jjCheckNAdd(jjnextStates[paramInt1]);
/* 1116: 959 */     } while (paramInt1++ != paramInt2);
/* 1117:     */   }
/* 1118:     */   
/* 1119:     */   private final void jjCheckNAddStates(int paramInt)
/* 1120:     */   {
/* 1121: 963 */     jjCheckNAdd(jjnextStates[paramInt]);
/* 1122: 964 */     jjCheckNAdd(jjnextStates[(paramInt + 1)]);
/* 1123:     */   }
/* 1124:     */   
/* 1125: 966 */   static final long[] jjbitVec0 = { -2L, -1L, -1L, -1L };
/* 1126: 969 */   static final long[] jjbitVec2 = { 0L, 0L, -1L, -1L };
/* 1127: 972 */   static final long[] jjbitVec3 = { 2301339413881290750L, -16384L, 4294967295L, 432345564227567616L };
/* 1128: 975 */   static final long[] jjbitVec4 = { 0L, 0L, 0L, -36028797027352577L };
/* 1129: 978 */   static final long[] jjbitVec5 = { 0L, -1L, -1L, -1L };
/* 1130: 981 */   static final long[] jjbitVec6 = { -1L, -1L, 65535L, 0L };
/* 1131: 984 */   static final long[] jjbitVec7 = { -1L, -1L, 0L, 0L };
/* 1132: 987 */   static final long[] jjbitVec8 = { 70368744177663L, 0L, 0L, 0L };
/* 1133:     */   
/* 1134:     */   private final int jjMoveNfa_0(int paramInt1, int paramInt2)
/* 1135:     */   {
/* 1136: 993 */     int i = 0;
/* 1137: 994 */     this.jjnewStateCnt = 52;
/* 1138: 995 */     int j = 1;
/* 1139: 996 */     this.jjstateSet[0] = paramInt1;
/* 1140: 997 */     int k = 2147483647;
/* 1141:     */     for (;;)
/* 1142:     */     {
/* 1143:1000 */       if (++this.jjround == 2147483647) {
/* 1144:1001 */         ReInitRounds();
/* 1145:     */       }
/* 1146:     */       long l1;
/* 1147:1002 */       if (this.curChar < '@')
/* 1148:     */       {
/* 1149:1004 */         l1 = 1L << this.curChar;
/* 1150:     */         do
/* 1151:     */         {
/* 1152:1007 */           switch (this.jjstateSet[(--j)])
/* 1153:     */           {
/* 1154:     */           case 3: 
/* 1155:1010 */             if ((0x0 & l1) != 0L)
/* 1156:     */             {
/* 1157:1011 */               jjCheckNAddStates(0, 6);
/* 1158:     */             }
/* 1159:1012 */             else if (this.curChar == '$')
/* 1160:     */             {
/* 1161:1014 */               if (k > 91) {
/* 1162:1015 */                 k = 91;
/* 1163:     */               }
/* 1164:1016 */               jjCheckNAdd(32);
/* 1165:     */             }
/* 1166:1018 */             else if (this.curChar == '"')
/* 1167:     */             {
/* 1168:1019 */               jjCheckNAddStates(7, 9);
/* 1169:     */             }
/* 1170:1020 */             else if (this.curChar == '\'')
/* 1171:     */             {
/* 1172:1021 */               jjAddStates(10, 11);
/* 1173:     */             }
/* 1174:1022 */             else if (this.curChar == '.')
/* 1175:     */             {
/* 1176:1023 */               jjCheckNAdd(8);
/* 1177:     */             }
/* 1178:1024 */             else if (this.curChar == '/')
/* 1179:     */             {
/* 1180:1025 */               this.jjstateSet[(this.jjnewStateCnt++)] = 2;
/* 1181:     */             }
/* 1182:1026 */             if ((0x0 & l1) != 0L)
/* 1183:     */             {
/* 1184:1028 */               if (k > 83) {
/* 1185:1029 */                 k = 83;
/* 1186:     */               }
/* 1187:1030 */               jjCheckNAddTwoStates(5, 6);
/* 1188:     */             }
/* 1189:1032 */             else if (this.curChar == '0')
/* 1190:     */             {
/* 1191:1034 */               if (k > 83) {
/* 1192:1035 */                 k = 83;
/* 1193:     */               }
/* 1194:1036 */               jjCheckNAddStates(12, 14);
/* 1195:     */             }
/* 1196:     */             break;
/* 1197:     */           case 0: 
/* 1198:1040 */             if (this.curChar == '*') {
/* 1199:1041 */               this.jjstateSet[(this.jjnewStateCnt++)] = 1;
/* 1200:     */             }
/* 1201:     */             break;
/* 1202:     */           case 1: 
/* 1203:1044 */             if (((0xFFFFFFFF & l1) != 0L) && (k > 7)) {
/* 1204:1045 */               k = 7;
/* 1205:     */             }
/* 1206:     */             break;
/* 1207:     */           case 2: 
/* 1208:1048 */             if (this.curChar == '*') {
/* 1209:1049 */               this.jjstateSet[(this.jjnewStateCnt++)] = 0;
/* 1210:     */             }
/* 1211:     */             break;
/* 1212:     */           case 4: 
/* 1213:1052 */             if ((0x0 & l1) != 0L)
/* 1214:     */             {
/* 1215:1054 */               if (k > 83) {
/* 1216:1055 */                 k = 83;
/* 1217:     */               }
/* 1218:1056 */               jjCheckNAddTwoStates(5, 6);
/* 1219:     */             }
/* 1220:1057 */             break;
/* 1221:     */           case 5: 
/* 1222:1059 */             if ((0x0 & l1) != 0L)
/* 1223:     */             {
/* 1224:1061 */               if (k > 83) {
/* 1225:1062 */                 k = 83;
/* 1226:     */               }
/* 1227:1063 */               jjCheckNAddTwoStates(5, 6);
/* 1228:     */             }
/* 1229:1064 */             break;
/* 1230:     */           case 7: 
/* 1231:1066 */             if (this.curChar == '.') {
/* 1232:1067 */               jjCheckNAdd(8);
/* 1233:     */             }
/* 1234:     */             break;
/* 1235:     */           case 8: 
/* 1236:1070 */             if ((0x0 & l1) != 0L)
/* 1237:     */             {
/* 1238:1072 */               if (k > 87) {
/* 1239:1073 */                 k = 87;
/* 1240:     */               }
/* 1241:1074 */               jjCheckNAddStates(15, 17);
/* 1242:     */             }
/* 1243:1075 */             break;
/* 1244:     */           case 10: 
/* 1245:1077 */             if ((0x0 & l1) != 0L) {
/* 1246:1078 */               jjCheckNAdd(11);
/* 1247:     */             }
/* 1248:     */             break;
/* 1249:     */           case 11: 
/* 1250:1081 */             if ((0x0 & l1) != 0L)
/* 1251:     */             {
/* 1252:1083 */               if (k > 87) {
/* 1253:1084 */                 k = 87;
/* 1254:     */               }
/* 1255:1085 */               jjCheckNAddTwoStates(11, 12);
/* 1256:     */             }
/* 1257:1086 */             break;
/* 1258:     */           case 13: 
/* 1259:1088 */             if (this.curChar == '\'') {
/* 1260:1089 */               jjAddStates(10, 11);
/* 1261:     */             }
/* 1262:     */             break;
/* 1263:     */           case 14: 
/* 1264:1092 */             if ((0xFFFFDBFF & l1) != 0L) {
/* 1265:1093 */               jjCheckNAdd(15);
/* 1266:     */             }
/* 1267:     */             break;
/* 1268:     */           case 15: 
/* 1269:1096 */             if ((this.curChar == '\'') && (k > 89)) {
/* 1270:1097 */               k = 89;
/* 1271:     */             }
/* 1272:     */             break;
/* 1273:     */           case 17: 
/* 1274:1100 */             if ((0x0 & l1) != 0L) {
/* 1275:1101 */               jjCheckNAdd(15);
/* 1276:     */             }
/* 1277:     */             break;
/* 1278:     */           case 18: 
/* 1279:1104 */             if ((0x0 & l1) != 0L) {
/* 1280:1105 */               jjCheckNAddTwoStates(19, 15);
/* 1281:     */             }
/* 1282:     */             break;
/* 1283:     */           case 19: 
/* 1284:1108 */             if ((0x0 & l1) != 0L) {
/* 1285:1109 */               jjCheckNAdd(15);
/* 1286:     */             }
/* 1287:     */             break;
/* 1288:     */           case 20: 
/* 1289:1112 */             if ((0x0 & l1) != 0L) {
/* 1290:1113 */               this.jjstateSet[(this.jjnewStateCnt++)] = 21;
/* 1291:     */             }
/* 1292:     */             break;
/* 1293:     */           case 21: 
/* 1294:1116 */             if ((0x0 & l1) != 0L) {
/* 1295:1117 */               jjCheckNAdd(19);
/* 1296:     */             }
/* 1297:     */             break;
/* 1298:     */           case 22: 
/* 1299:1120 */             if (this.curChar == '"') {
/* 1300:1121 */               jjCheckNAddStates(7, 9);
/* 1301:     */             }
/* 1302:     */             break;
/* 1303:     */           case 23: 
/* 1304:1124 */             if ((0xFFFFDBFF & l1) != 0L) {
/* 1305:1125 */               jjCheckNAddStates(7, 9);
/* 1306:     */             }
/* 1307:     */             break;
/* 1308:     */           case 25: 
/* 1309:1128 */             if ((0x0 & l1) != 0L) {
/* 1310:1129 */               jjCheckNAddStates(7, 9);
/* 1311:     */             }
/* 1312:     */             break;
/* 1313:     */           case 26: 
/* 1314:1132 */             if ((this.curChar == '"') && (k > 90)) {
/* 1315:1133 */               k = 90;
/* 1316:     */             }
/* 1317:     */             break;
/* 1318:     */           case 27: 
/* 1319:1136 */             if ((0x0 & l1) != 0L) {
/* 1320:1137 */               jjCheckNAddStates(18, 21);
/* 1321:     */             }
/* 1322:     */             break;
/* 1323:     */           case 28: 
/* 1324:1140 */             if ((0x0 & l1) != 0L) {
/* 1325:1141 */               jjCheckNAddStates(7, 9);
/* 1326:     */             }
/* 1327:     */             break;
/* 1328:     */           case 29: 
/* 1329:1144 */             if ((0x0 & l1) != 0L) {
/* 1330:1145 */               this.jjstateSet[(this.jjnewStateCnt++)] = 30;
/* 1331:     */             }
/* 1332:     */             break;
/* 1333:     */           case 30: 
/* 1334:1148 */             if ((0x0 & l1) != 0L) {
/* 1335:1149 */               jjCheckNAdd(28);
/* 1336:     */             }
/* 1337:     */             break;
/* 1338:     */           case 31: 
/* 1339:1152 */             if (this.curChar == '$')
/* 1340:     */             {
/* 1341:1154 */               if (k > 91) {
/* 1342:1155 */                 k = 91;
/* 1343:     */               }
/* 1344:1156 */               jjCheckNAdd(32);
/* 1345:     */             }
/* 1346:1157 */             break;
/* 1347:     */           case 32: 
/* 1348:1159 */             if ((0x0 & l1) != 0L)
/* 1349:     */             {
/* 1350:1161 */               if (k > 91) {
/* 1351:1162 */                 k = 91;
/* 1352:     */               }
/* 1353:1163 */               jjCheckNAdd(32);
/* 1354:     */             }
/* 1355:1164 */             break;
/* 1356:     */           case 33: 
/* 1357:1166 */             if ((0x0 & l1) != 0L) {
/* 1358:1167 */               jjCheckNAddStates(0, 6);
/* 1359:     */             }
/* 1360:     */             break;
/* 1361:     */           case 34: 
/* 1362:1170 */             if ((0x0 & l1) != 0L) {
/* 1363:1171 */               jjCheckNAddTwoStates(34, 35);
/* 1364:     */             }
/* 1365:     */             break;
/* 1366:     */           case 35: 
/* 1367:1174 */             if (this.curChar == '.')
/* 1368:     */             {
/* 1369:1176 */               if (k > 87) {
/* 1370:1177 */                 k = 87;
/* 1371:     */               }
/* 1372:1178 */               jjCheckNAddStates(22, 24);
/* 1373:     */             }
/* 1374:1179 */             break;
/* 1375:     */           case 36: 
/* 1376:1181 */             if ((0x0 & l1) != 0L)
/* 1377:     */             {
/* 1378:1183 */               if (k > 87) {
/* 1379:1184 */                 k = 87;
/* 1380:     */               }
/* 1381:1185 */               jjCheckNAddStates(22, 24);
/* 1382:     */             }
/* 1383:1186 */             break;
/* 1384:     */           case 38: 
/* 1385:1188 */             if ((0x0 & l1) != 0L) {
/* 1386:1189 */               jjCheckNAdd(39);
/* 1387:     */             }
/* 1388:     */             break;
/* 1389:     */           case 39: 
/* 1390:1192 */             if ((0x0 & l1) != 0L)
/* 1391:     */             {
/* 1392:1194 */               if (k > 87) {
/* 1393:1195 */                 k = 87;
/* 1394:     */               }
/* 1395:1196 */               jjCheckNAddTwoStates(39, 12);
/* 1396:     */             }
/* 1397:1197 */             break;
/* 1398:     */           case 40: 
/* 1399:1199 */             if ((0x0 & l1) != 0L) {
/* 1400:1200 */               jjCheckNAddTwoStates(40, 41);
/* 1401:     */             }
/* 1402:     */             break;
/* 1403:     */           case 42: 
/* 1404:1203 */             if ((0x0 & l1) != 0L) {
/* 1405:1204 */               jjCheckNAdd(43);
/* 1406:     */             }
/* 1407:     */             break;
/* 1408:     */           case 43: 
/* 1409:1207 */             if ((0x0 & l1) != 0L)
/* 1410:     */             {
/* 1411:1209 */               if (k > 87) {
/* 1412:1210 */                 k = 87;
/* 1413:     */               }
/* 1414:1211 */               jjCheckNAddTwoStates(43, 12);
/* 1415:     */             }
/* 1416:1212 */             break;
/* 1417:     */           case 44: 
/* 1418:1214 */             if ((0x0 & l1) != 0L) {
/* 1419:1215 */               jjCheckNAddStates(25, 27);
/* 1420:     */             }
/* 1421:     */             break;
/* 1422:     */           case 46: 
/* 1423:1218 */             if ((0x0 & l1) != 0L) {
/* 1424:1219 */               jjCheckNAdd(47);
/* 1425:     */             }
/* 1426:     */             break;
/* 1427:     */           case 47: 
/* 1428:1222 */             if ((0x0 & l1) != 0L) {
/* 1429:1223 */               jjCheckNAddTwoStates(47, 12);
/* 1430:     */             }
/* 1431:     */             break;
/* 1432:     */           case 48: 
/* 1433:1226 */             if (this.curChar == '0')
/* 1434:     */             {
/* 1435:1228 */               if (k > 83) {
/* 1436:1229 */                 k = 83;
/* 1437:     */               }
/* 1438:1230 */               jjCheckNAddStates(12, 14);
/* 1439:     */             }
/* 1440:1231 */             break;
/* 1441:     */           case 50: 
/* 1442:1233 */             if ((0x0 & l1) != 0L)
/* 1443:     */             {
/* 1444:1235 */               if (k > 83) {
/* 1445:1236 */                 k = 83;
/* 1446:     */               }
/* 1447:1237 */               jjCheckNAddTwoStates(50, 6);
/* 1448:     */             }
/* 1449:1238 */             break;
/* 1450:     */           case 51: 
/* 1451:1240 */             if ((0x0 & l1) != 0L)
/* 1452:     */             {
/* 1453:1242 */               if (k > 83) {
/* 1454:1243 */                 k = 83;
/* 1455:     */               }
/* 1456:1244 */               jjCheckNAddTwoStates(51, 6);
/* 1457:     */             }
/* 1458:     */             break;
/* 1459:     */           }
/* 1460:1248 */         } while (j != i);
/* 1461:     */       }
/* 1462:1250 */       else if (this.curChar < '')
/* 1463:     */       {
/* 1464:1252 */         l1 = 1L << (this.curChar & 0x3F);
/* 1465:     */         do
/* 1466:     */         {
/* 1467:1255 */           switch (this.jjstateSet[(--j)])
/* 1468:     */           {
/* 1469:     */           case 3: 
/* 1470:     */           case 32: 
/* 1471:1259 */             if ((0x87FFFFFE & l1) != 0L)
/* 1472:     */             {
/* 1473:1261 */               if (k > 91) {
/* 1474:1262 */                 k = 91;
/* 1475:     */               }
/* 1476:1263 */               jjCheckNAdd(32);
/* 1477:     */             }
/* 1478:1264 */             break;
/* 1479:     */           case 1: 
/* 1480:1266 */             if (k > 7) {
/* 1481:1267 */               k = 7;
/* 1482:     */             }
/* 1483:     */             break;
/* 1484:     */           case 6: 
/* 1485:1270 */             if (((0x1000 & l1) != 0L) && (k > 83)) {
/* 1486:1271 */               k = 83;
/* 1487:     */             }
/* 1488:     */             break;
/* 1489:     */           case 9: 
/* 1490:1274 */             if ((0x20 & l1) != 0L) {
/* 1491:1275 */               jjAddStates(28, 29);
/* 1492:     */             }
/* 1493:     */             break;
/* 1494:     */           case 12: 
/* 1495:1278 */             if (((0x50 & l1) != 0L) && (k > 87)) {
/* 1496:1279 */               k = 87;
/* 1497:     */             }
/* 1498:     */             break;
/* 1499:     */           case 14: 
/* 1500:1282 */             if ((0xEFFFFFFF & l1) != 0L) {
/* 1501:1283 */               jjCheckNAdd(15);
/* 1502:     */             }
/* 1503:     */             break;
/* 1504:     */           case 16: 
/* 1505:1286 */             if (this.curChar == '\\') {
/* 1506:1287 */               jjAddStates(30, 32);
/* 1507:     */             }
/* 1508:     */             break;
/* 1509:     */           case 17: 
/* 1510:1290 */             if ((0x10000000 & l1) != 0L) {
/* 1511:1291 */               jjCheckNAdd(15);
/* 1512:     */             }
/* 1513:     */             break;
/* 1514:     */           case 23: 
/* 1515:1294 */             if ((0xEFFFFFFF & l1) != 0L) {
/* 1516:1295 */               jjCheckNAddStates(7, 9);
/* 1517:     */             }
/* 1518:     */             break;
/* 1519:     */           case 24: 
/* 1520:1298 */             if (this.curChar == '\\') {
/* 1521:1299 */               jjAddStates(33, 35);
/* 1522:     */             }
/* 1523:     */             break;
/* 1524:     */           case 25: 
/* 1525:1302 */             if ((0x10000000 & l1) != 0L) {
/* 1526:1303 */               jjCheckNAddStates(7, 9);
/* 1527:     */             }
/* 1528:     */             break;
/* 1529:     */           case 37: 
/* 1530:1306 */             if ((0x20 & l1) != 0L) {
/* 1531:1307 */               jjAddStates(36, 37);
/* 1532:     */             }
/* 1533:     */             break;
/* 1534:     */           case 41: 
/* 1535:1310 */             if ((0x20 & l1) != 0L) {
/* 1536:1311 */               jjAddStates(38, 39);
/* 1537:     */             }
/* 1538:     */             break;
/* 1539:     */           case 45: 
/* 1540:1314 */             if ((0x20 & l1) != 0L) {
/* 1541:1315 */               jjAddStates(40, 41);
/* 1542:     */             }
/* 1543:     */             break;
/* 1544:     */           case 49: 
/* 1545:1318 */             if ((0x1000000 & l1) != 0L) {
/* 1546:1319 */               jjCheckNAdd(50);
/* 1547:     */             }
/* 1548:     */             break;
/* 1549:     */           case 50: 
/* 1550:1322 */             if ((0x7E & l1) != 0L)
/* 1551:     */             {
/* 1552:1324 */               if (k > 83) {
/* 1553:1325 */                 k = 83;
/* 1554:     */               }
/* 1555:1326 */               jjCheckNAddTwoStates(50, 6);
/* 1556:     */             }
/* 1557:     */             break;
/* 1558:     */           }
/* 1559:1330 */         } while (j != i);
/* 1560:     */       }
/* 1561:     */       else
/* 1562:     */       {
/* 1563:1334 */         int m = this.curChar >> '\b';
/* 1564:1335 */         int n = m >> 6;
/* 1565:1336 */         long l2 = 1L << (m & 0x3F);
/* 1566:1337 */         int i1 = (this.curChar & 0xFF) >> '\006';
/* 1567:1338 */         long l3 = 1L << (this.curChar & 0x3F);
/* 1568:     */         do
/* 1569:     */         {
/* 1570:1341 */           switch (this.jjstateSet[(--j)])
/* 1571:     */           {
/* 1572:     */           case 3: 
/* 1573:     */           case 32: 
/* 1574:1345 */             if (jjCanMove_1(m, n, i1, l2, l3))
/* 1575:     */             {
/* 1576:1347 */               if (k > 91) {
/* 1577:1348 */                 k = 91;
/* 1578:     */               }
/* 1579:1349 */               jjCheckNAdd(32);
/* 1580:     */             }
/* 1581:1350 */             break;
/* 1582:     */           case 1: 
/* 1583:1352 */             if ((jjCanMove_0(m, n, i1, l2, l3)) && (k > 7)) {
/* 1584:1353 */               k = 7;
/* 1585:     */             }
/* 1586:     */             break;
/* 1587:     */           case 14: 
/* 1588:1356 */             if (jjCanMove_0(m, n, i1, l2, l3)) {
/* 1589:1357 */               this.jjstateSet[(this.jjnewStateCnt++)] = 15;
/* 1590:     */             }
/* 1591:     */             break;
/* 1592:     */           case 23: 
/* 1593:1360 */             if (jjCanMove_0(m, n, i1, l2, l3)) {
/* 1594:1361 */               jjAddStates(7, 9);
/* 1595:     */             }
/* 1596:     */             break;
/* 1597:     */           }
/* 1598:1365 */         } while (j != i);
/* 1599:     */       }
/* 1600:1367 */       if (k != 2147483647)
/* 1601:     */       {
/* 1602:1369 */         this.jjmatchedKind = k;
/* 1603:1370 */         this.jjmatchedPos = paramInt2;
/* 1604:1371 */         k = 2147483647;
/* 1605:     */       }
/* 1606:1373 */       paramInt2++;
/* 1607:1374 */       if ((j = this.jjnewStateCnt) == (i = 52 - (this.jjnewStateCnt = i))) {
/* 1608:1375 */         return paramInt2;
/* 1609:     */       }
/* 1610:     */       try
/* 1611:     */       {
/* 1612:1376 */         this.curChar = this.input_stream.readChar();
/* 1613:     */       }
/* 1614:     */       catch (IOException localIOException) {}
/* 1615:     */     }
/* 1616:1377 */     return paramInt2;
/* 1617:     */   }
/* 1618:     */   
/* 1619:     */   private final int jjMoveStringLiteralDfa0_3()
/* 1620:     */   {
/* 1621:1382 */     switch (this.curChar)
/* 1622:     */     {
/* 1623:     */     case '*': 
/* 1624:1385 */       return jjMoveStringLiteralDfa1_3(2048L);
/* 1625:     */     }
/* 1626:1387 */     return 1;
/* 1627:     */   }
/* 1628:     */   
/* 1629:     */   private final int jjMoveStringLiteralDfa1_3(long paramLong)
/* 1630:     */   {
/* 1631:     */     try
/* 1632:     */     {
/* 1633:1392 */       this.curChar = this.input_stream.readChar();
/* 1634:     */     }
/* 1635:     */     catch (IOException localIOException)
/* 1636:     */     {
/* 1637:1394 */       return 1;
/* 1638:     */     }
/* 1639:1396 */     switch (this.curChar)
/* 1640:     */     {
/* 1641:     */     case '/': 
/* 1642:1399 */       if ((paramLong & 0x800) != 0L) {
/* 1643:1400 */         return jjStopAtPos(1, 11);
/* 1644:     */       }
/* 1645:     */       break;
/* 1646:     */     default: 
/* 1647:1403 */       return 2;
/* 1648:     */     }
/* 1649:1405 */     return 2;
/* 1650:     */   }
/* 1651:     */   
/* 1652:     */   private final int jjMoveStringLiteralDfa0_1()
/* 1653:     */   {
/* 1654:1409 */     return jjMoveNfa_1(0, 0);
/* 1655:     */   }
/* 1656:     */   
/* 1657:     */   private final int jjMoveNfa_1(int paramInt1, int paramInt2)
/* 1658:     */   {
/* 1659:1414 */     int i = 0;
/* 1660:1415 */     this.jjnewStateCnt = 3;
/* 1661:1416 */     int j = 1;
/* 1662:1417 */     this.jjstateSet[0] = paramInt1;
/* 1663:1418 */     int k = 2147483647;
/* 1664:     */     for (;;)
/* 1665:     */     {
/* 1666:1421 */       if (++this.jjround == 2147483647) {
/* 1667:1422 */         ReInitRounds();
/* 1668:     */       }
/* 1669:     */       long l1;
/* 1670:1423 */       if (this.curChar < '@')
/* 1671:     */       {
/* 1672:1425 */         l1 = 1L << this.curChar;
/* 1673:     */         do
/* 1674:     */         {
/* 1675:1428 */           switch (this.jjstateSet[(--j)])
/* 1676:     */           {
/* 1677:     */           case 0: 
/* 1678:1431 */             if ((0x2400 & l1) != 0L) {
/* 1679:1433 */               if (k > 9) {
/* 1680:1434 */                 k = 9;
/* 1681:     */               }
/* 1682:     */             }
/* 1683:1436 */             if (this.curChar == '\r') {
/* 1684:1437 */               this.jjstateSet[(this.jjnewStateCnt++)] = 1;
/* 1685:     */             }
/* 1686:     */             break;
/* 1687:     */           case 1: 
/* 1688:1440 */             if ((this.curChar == '\n') && (k > 9)) {
/* 1689:1441 */               k = 9;
/* 1690:     */             }
/* 1691:     */             break;
/* 1692:     */           case 2: 
/* 1693:1444 */             if (this.curChar == '\r') {
/* 1694:1445 */               this.jjstateSet[(this.jjnewStateCnt++)] = 1;
/* 1695:     */             }
/* 1696:     */             break;
/* 1697:     */           }
/* 1698:1449 */         } while (j != i);
/* 1699:     */       }
/* 1700:1451 */       else if (this.curChar < '')
/* 1701:     */       {
/* 1702:1453 */         l1 = 1L << (this.curChar & 0x3F);
/* 1703:     */         do
/* 1704:     */         {
/* 1705:1456 */           switch (this.jjstateSet[(--j)])
/* 1706:     */           {
/* 1707:     */           }
/* 1708:1460 */         } while (j != i);
/* 1709:     */       }
/* 1710:     */       else
/* 1711:     */       {
/* 1712:1464 */         int m = this.curChar >> '\b';
/* 1713:1465 */         int n = m >> 6;
/* 1714:1466 */         long l2 = 1L << (m & 0x3F);
/* 1715:1467 */         int i1 = (this.curChar & 0xFF) >> '\006';
/* 1716:1468 */         long l3 = 1L << (this.curChar & 0x3F);
/* 1717:     */         do
/* 1718:     */         {
/* 1719:1471 */           switch (this.jjstateSet[(--j)])
/* 1720:     */           {
/* 1721:     */           }
/* 1722:1475 */         } while (j != i);
/* 1723:     */       }
/* 1724:1477 */       if (k != 2147483647)
/* 1725:     */       {
/* 1726:1479 */         this.jjmatchedKind = k;
/* 1727:1480 */         this.jjmatchedPos = paramInt2;
/* 1728:1481 */         k = 2147483647;
/* 1729:     */       }
/* 1730:1483 */       paramInt2++;
/* 1731:1484 */       if ((j = this.jjnewStateCnt) == (i = 3 - (this.jjnewStateCnt = i))) {
/* 1732:1485 */         return paramInt2;
/* 1733:     */       }
/* 1734:     */       try
/* 1735:     */       {
/* 1736:1486 */         this.curChar = this.input_stream.readChar();
/* 1737:     */       }
/* 1738:     */       catch (IOException localIOException) {}
/* 1739:     */     }
/* 1740:1487 */     return paramInt2;
/* 1741:     */   }
/* 1742:     */   
/* 1743:     */   private final int jjMoveStringLiteralDfa0_2()
/* 1744:     */   {
/* 1745:1492 */     switch (this.curChar)
/* 1746:     */     {
/* 1747:     */     case '*': 
/* 1748:1495 */       return jjMoveStringLiteralDfa1_2(1024L);
/* 1749:     */     }
/* 1750:1497 */     return 1;
/* 1751:     */   }
/* 1752:     */   
/* 1753:     */   private final int jjMoveStringLiteralDfa1_2(long paramLong)
/* 1754:     */   {
/* 1755:     */     try
/* 1756:     */     {
/* 1757:1502 */       this.curChar = this.input_stream.readChar();
/* 1758:     */     }
/* 1759:     */     catch (IOException localIOException)
/* 1760:     */     {
/* 1761:1504 */       return 1;
/* 1762:     */     }
/* 1763:1506 */     switch (this.curChar)
/* 1764:     */     {
/* 1765:     */     case '/': 
/* 1766:1509 */       if ((paramLong & 0x400) != 0L) {
/* 1767:1510 */         return jjStopAtPos(1, 10);
/* 1768:     */       }
/* 1769:     */       break;
/* 1770:     */     default: 
/* 1771:1513 */       return 2;
/* 1772:     */     }
/* 1773:1515 */     return 2;
/* 1774:     */   }
/* 1775:     */   
/* 1776:1517 */   static final int[] jjnextStates = { 34, 35, 40, 41, 44, 45, 12, 23, 24, 26, 14, 16, 49, 51, 6, 8, 9, 12, 23, 24, 28, 26, 36, 37, 12, 44, 45, 12, 10, 11, 17, 18, 20, 25, 27, 29, 38, 39, 42, 43, 46, 47 };
/* 1777:     */   
/* 1778:     */   private static final boolean jjCanMove_0(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2)
/* 1779:     */   {
/* 1780:1524 */     switch (paramInt1)
/* 1781:     */     {
/* 1782:     */     case 0: 
/* 1783:1527 */       return (jjbitVec2[paramInt3] & paramLong2) != 0L;
/* 1784:     */     }
/* 1785:1529 */     if ((jjbitVec0[paramInt2] & paramLong1) != 0L) {
/* 1786:1530 */       return true;
/* 1787:     */     }
/* 1788:1531 */     return false;
/* 1789:     */   }
/* 1790:     */   
/* 1791:     */   private static final boolean jjCanMove_1(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2)
/* 1792:     */   {
/* 1793:1536 */     switch (paramInt1)
/* 1794:     */     {
/* 1795:     */     case 0: 
/* 1796:1539 */       return (jjbitVec4[paramInt3] & paramLong2) != 0L;
/* 1797:     */     case 48: 
/* 1798:1541 */       return (jjbitVec5[paramInt3] & paramLong2) != 0L;
/* 1799:     */     case 49: 
/* 1800:1543 */       return (jjbitVec6[paramInt3] & paramLong2) != 0L;
/* 1801:     */     case 51: 
/* 1802:1545 */       return (jjbitVec7[paramInt3] & paramLong2) != 0L;
/* 1803:     */     case 61: 
/* 1804:1547 */       return (jjbitVec8[paramInt3] & paramLong2) != 0L;
/* 1805:     */     }
/* 1806:1549 */     if ((jjbitVec3[paramInt2] & paramLong1) != 0L) {
/* 1807:1550 */       return true;
/* 1808:     */     }
/* 1809:1551 */     return false;
/* 1810:     */   }
/* 1811:     */   
/* 1812:1554 */   public static final String[] jjstrLiteralImages = { "", null, null, null, null, null, null, null, null, null, null, null, null, "abstract", "boolean", "break", "byte", "case", "catch", "char", "class", "const", "continue", "default", "do", "double", "else", "extends", "false", "final", "finally", "float", "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long", "native", "new", "null", "package", "private", "protected", "public", "return", "short", "static", "super", "switch", "synchronized", "this", "throw", "throws", "transient", "true", "try", "void", "volatile", "while", "shared", "firstprivate", "lastprivate", "parallel", "master", "//omp", "none", "nowait", "ordered", "barrier", "single", "section", "sections", "critical", "only", "schedule", "dynamic", "guided", "runtime", "reduction", null, null, null, null, null, null, null, null, null, null, null, "(", ")", "{", "}", "[", "]", ";", ",", ".", "=", ">", "<", "!", "~", "?", ":", "==", "<=", ">=", "!=", "||", "&&", "++", "--", "+", "-", "*", "/", "&", "|", "^", "%", "<<", ">>", ">>>", "+=", "-=", "*=", "/=", "&=", "|=", "^=", "%=", "<<=", ">>=", ">>>=" };
/* 1813:1583 */   public static final String[] lexStateNames = { "DEFAULT", "IN_SINGLE_LINE_COMMENT", "IN_FORMAL_COMMENT", "IN_MULTI_LINE_COMMENT" };
/* 1814:1589 */   public static final int[] jjnewLexState = { -1, -1, -1, -1, -1, -1, 1, 2, 3, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
/* 1815:1597 */   static final long[] jjtoToken = { -8191L, -829423617L, 4095L };
/* 1816:1600 */   static final long[] jjtoSkip = { 3646L, 0L, 0L };
/* 1817:1603 */   static final long[] jjtoSpecial = { 3646L, 0L, 0L };
/* 1818:1606 */   static final long[] jjtoMore = { 4544L, 0L, 0L };
/* 1819:     */   private ASCII_UCodeESC_CharStream input_stream;
/* 1820:1610 */   private final int[] jjrounds = new int[52];
/* 1821:1611 */   private final int[] jjstateSet = new int[104];
/* 1822:     */   StringBuffer image;
/* 1823:     */   int jjimageLen;
/* 1824:     */   int lengthOfMatch;
/* 1825:     */   protected char curChar;
/* 1826:     */   
/* 1827:     */   public JavaParserTokenManager(ASCII_UCodeESC_CharStream paramASCII_UCodeESC_CharStream)
/* 1828:     */   {
/* 1829:1620 */     this.input_stream = paramASCII_UCodeESC_CharStream;
/* 1830:     */   }
/* 1831:     */   
/* 1832:     */   public JavaParserTokenManager(ASCII_UCodeESC_CharStream paramASCII_UCodeESC_CharStream, int paramInt)
/* 1833:     */   {
/* 1834:1624 */     this(paramASCII_UCodeESC_CharStream);
/* 1835:1625 */     SwitchTo(paramInt);
/* 1836:     */   }
/* 1837:     */   
/* 1838:     */   public void ReInit(ASCII_UCodeESC_CharStream paramASCII_UCodeESC_CharStream)
/* 1839:     */   {
/* 1840:1629 */     this.jjmatchedPos = (this.jjnewStateCnt = 0);
/* 1841:1630 */     this.curLexState = this.defaultLexState;
/* 1842:1631 */     this.input_stream = paramASCII_UCodeESC_CharStream;
/* 1843:1632 */     ReInitRounds();
/* 1844:     */   }
/* 1845:     */   
/* 1846:     */   private final void ReInitRounds()
/* 1847:     */   {
/* 1848:1637 */     this.jjround = -2147483647;
/* 1849:1638 */     for (int i = 52; i-- > 0;) {
/* 1850:1639 */       this.jjrounds[i] = -2147483648;
/* 1851:     */     }
/* 1852:     */   }
/* 1853:     */   
/* 1854:     */   public void ReInit(ASCII_UCodeESC_CharStream paramASCII_UCodeESC_CharStream, int paramInt)
/* 1855:     */   {
/* 1856:1643 */     ReInit(paramASCII_UCodeESC_CharStream);
/* 1857:1644 */     SwitchTo(paramInt);
/* 1858:     */   }
/* 1859:     */   
/* 1860:     */   public void SwitchTo(int paramInt)
/* 1861:     */   {
/* 1862:1648 */     if ((paramInt >= 4) || (paramInt < 0)) {
/* 1863:1649 */       throw new TokenMgrError("Error: Ignoring invalid lexical state : " + paramInt + ". State unchanged.", 2);
/* 1864:     */     }
/* 1865:1651 */     this.curLexState = paramInt;
/* 1866:     */   }
/* 1867:     */   
/* 1868:     */   private final Token jjFillToken()
/* 1869:     */   {
/* 1870:1656 */     Token localToken = Token.newToken(this.jjmatchedKind);
/* 1871:1657 */     localToken.kind = this.jjmatchedKind;
/* 1872:1658 */     String str = jjstrLiteralImages[this.jjmatchedKind];
/* 1873:1659 */     localToken.image = (str == null ? this.input_stream.GetImage() : str);
/* 1874:1660 */     localToken.beginLine = this.input_stream.getBeginLine();
/* 1875:1661 */     localToken.beginColumn = this.input_stream.getBeginColumn();
/* 1876:1662 */     localToken.endLine = this.input_stream.getEndLine();
/* 1877:1663 */     localToken.endColumn = this.input_stream.getEndColumn();
/* 1878:1664 */     return localToken;
/* 1879:     */   }
/* 1880:     */   
/* 1881:1667 */   int curLexState = 0;
/* 1882:1668 */   int defaultLexState = 0;
/* 1883:     */   int jjnewStateCnt;
/* 1884:     */   int jjround;
/* 1885:     */   int jjmatchedPos;
/* 1886:     */   int jjmatchedKind;
/* 1887:     */   
/* 1888:     */   public final Token getNextToken()
/* 1889:     */   {
/* 1890:1677 */     Object localObject = null;
/* 1891:     */     
/* 1892:1679 */     int i = 0;
/* 1893:     */     Token localToken;
/* 1894:     */     try
/* 1895:     */     {
/* 1896:1686 */       this.curChar = this.input_stream.BeginToken();
/* 1897:     */     }
/* 1898:     */     catch (IOException localIOException1)
/* 1899:     */     {
/* 1900:1690 */       this.jjmatchedKind = 0;
/* 1901:1691 */       localToken = jjFillToken();
/* 1902:1692 */       localToken.specialToken = localObject;
/* 1903:1693 */       return localToken;
/* 1904:     */     }
/* 1905:1695 */     this.image = null;
/* 1906:1696 */     this.jjimageLen = 0;
/* 1907:     */     for (;;)
/* 1908:     */     {
/* 1909:1700 */       switch (this.curLexState)
/* 1910:     */       {
/* 1911:     */       case 0: 
/* 1912:1703 */         this.jjmatchedKind = 2147483647;
/* 1913:1704 */         this.jjmatchedPos = 0;
/* 1914:1705 */         i = jjMoveStringLiteralDfa0_0();
/* 1915:1706 */         break;
/* 1916:     */       case 1: 
/* 1917:1708 */         this.jjmatchedKind = 2147483647;
/* 1918:1709 */         this.jjmatchedPos = 0;
/* 1919:1710 */         i = jjMoveStringLiteralDfa0_1();
/* 1920:1711 */         if ((this.jjmatchedPos == 0) && (this.jjmatchedKind > 12)) {
/* 1921:1713 */           this.jjmatchedKind = 12;
/* 1922:     */         }
/* 1923:     */         break;
/* 1924:     */       case 2: 
/* 1925:1717 */         this.jjmatchedKind = 2147483647;
/* 1926:1718 */         this.jjmatchedPos = 0;
/* 1927:1719 */         i = jjMoveStringLiteralDfa0_2();
/* 1928:1720 */         if ((this.jjmatchedPos == 0) && (this.jjmatchedKind > 12)) {
/* 1929:1722 */           this.jjmatchedKind = 12;
/* 1930:     */         }
/* 1931:     */         break;
/* 1932:     */       case 3: 
/* 1933:1726 */         this.jjmatchedKind = 2147483647;
/* 1934:1727 */         this.jjmatchedPos = 0;
/* 1935:1728 */         i = jjMoveStringLiteralDfa0_3();
/* 1936:1729 */         if ((this.jjmatchedPos == 0) && (this.jjmatchedKind > 12)) {
/* 1937:1731 */           this.jjmatchedKind = 12;
/* 1938:     */         }
/* 1939:     */         break;
/* 1940:     */       }
/* 1941:1735 */       if (this.jjmatchedKind != 2147483647)
/* 1942:     */       {
/* 1943:1737 */         if (this.jjmatchedPos + 1 < i) {
/* 1944:1738 */           this.input_stream.backup(i - this.jjmatchedPos - 1);
/* 1945:     */         }
/* 1946:1739 */         if ((jjtoToken[(this.jjmatchedKind >> 6)] & 1L << (this.jjmatchedKind & 0x3F)) != 0L)
/* 1947:     */         {
/* 1948:1741 */           localToken = jjFillToken();
/* 1949:1742 */           localToken.specialToken = localObject;
/* 1950:1743 */           if (jjnewLexState[this.jjmatchedKind] != -1) {
/* 1951:1744 */             this.curLexState = jjnewLexState[this.jjmatchedKind];
/* 1952:     */           }
/* 1953:1745 */           return localToken;
/* 1954:     */         }
/* 1955:1747 */         if ((jjtoSkip[(this.jjmatchedKind >> 6)] & 1L << (this.jjmatchedKind & 0x3F)) != 0L)
/* 1956:     */         {
/* 1957:1749 */           if ((jjtoSpecial[(this.jjmatchedKind >> 6)] & 1L << (this.jjmatchedKind & 0x3F)) != 0L)
/* 1958:     */           {
/* 1959:1751 */             localToken = jjFillToken();
/* 1960:1752 */             if (localObject == null)
/* 1961:     */             {
/* 1962:1753 */               localObject = localToken;
/* 1963:     */             }
/* 1964:     */             else
/* 1965:     */             {
/* 1966:1756 */               localToken.specialToken = localObject;
/* 1967:1757 */               localObject = localObject.next = localToken;
/* 1968:     */             }
/* 1969:1759 */             SkipLexicalActions(localToken);
/* 1970:     */           }
/* 1971:     */           else
/* 1972:     */           {
/* 1973:1762 */             SkipLexicalActions(null);
/* 1974:     */           }
/* 1975:1763 */           if (jjnewLexState[this.jjmatchedKind] == -1) {
/* 1976:     */             break;
/* 1977:     */           }
/* 1978:1764 */           this.curLexState = jjnewLexState[this.jjmatchedKind]; break;
/* 1979:     */         }
/* 1980:1767 */         MoreLexicalActions();
/* 1981:1768 */         if (jjnewLexState[this.jjmatchedKind] != -1) {
/* 1982:1769 */           this.curLexState = jjnewLexState[this.jjmatchedKind];
/* 1983:     */         }
/* 1984:1770 */         i = 0;
/* 1985:1771 */         this.jjmatchedKind = 2147483647;
/* 1986:     */         try
/* 1987:     */         {
/* 1988:1773 */           this.curChar = this.input_stream.readChar();
/* 1989:     */         }
/* 1990:     */         catch (IOException localIOException2) {}
/* 1991:     */       }
/* 1992:     */     }
/* 1993:1778 */     int j = this.input_stream.getEndLine();
/* 1994:1779 */     int k = this.input_stream.getEndColumn();
/* 1995:1780 */     String str = null;
/* 1996:1781 */     boolean bool = false;
/* 1997:     */     try
/* 1998:     */     {
/* 1999:1782 */       this.input_stream.readChar();this.input_stream.backup(1);
/* 2000:     */     }
/* 2001:     */     catch (IOException localIOException3)
/* 2002:     */     {
/* 2003:1784 */       bool = true;
/* 2004:1785 */       str = i <= 1 ? "" : this.input_stream.GetImage();
/* 2005:1786 */       if ((this.curChar == '\n') || (this.curChar == '\r'))
/* 2006:     */       {
/* 2007:1787 */         j++;
/* 2008:1788 */         k = 0;
/* 2009:     */       }
/* 2010:     */       else
/* 2011:     */       {
/* 2012:1791 */         k++;
/* 2013:     */       }
/* 2014:     */     }
/* 2015:1793 */     if (!bool)
/* 2016:     */     {
/* 2017:1794 */       this.input_stream.backup(1);
/* 2018:1795 */       str = i <= 1 ? "" : this.input_stream.GetImage();
/* 2019:     */     }
/* 2020:1797 */     throw new TokenMgrError(bool, this.curLexState, j, k, str, this.curChar, 0);
/* 2021:     */   }
/* 2022:     */   
/* 2023:     */   final void SkipLexicalActions(Token paramToken)
/* 2024:     */   {
/* 2025:1804 */     switch (this.jjmatchedKind)
/* 2026:     */     {
/* 2027:     */     }
/* 2028:     */   }
/* 2029:     */   
/* 2030:     */   final void MoreLexicalActions()
/* 2031:     */   {
/* 2032:1812 */     this.jjimageLen += (this.lengthOfMatch = this.jjmatchedPos + 1);
/* 2033:1813 */     switch (this.jjmatchedKind)
/* 2034:     */     {
/* 2035:     */     case 7: 
/* 2036:1816 */       if (this.image == null) {
/* 2037:1817 */         this.image = new StringBuffer(new String(this.input_stream.GetSuffix(this.jjimageLen)));
/* 2038:     */       } else {
/* 2039:1819 */         this.image.append(this.input_stream.GetSuffix(this.jjimageLen));
/* 2040:     */       }
/* 2041:1820 */       this.jjimageLen = 0;
/* 2042:1821 */       this.input_stream.backup(1);
/* 2043:1822 */       break;
/* 2044:     */     }
/* 2045:     */   }
/* 2046:     */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.compiler.JavaParserTokenManager
 * JD-Core Version:    0.7.0.1
 */