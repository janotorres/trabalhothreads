/*   1:    */ package jomp.compiler;
/*   2:    */ 
/*   3:    */ public abstract interface JavaParserTreeConstants
/*   4:    */ {
/*   5:    */   public static final int JJTCOMPILATIONUNIT = 0;
/*   6:    */   public static final int JJTPACKAGEDECLARATION = 1;
/*   7:    */   public static final int JJTIMPORTDECLARATION = 2;
/*   8:    */   public static final int JJTTYPEDECLARATION = 3;
/*   9:    */   public static final int JJTCLASSDECLARATION = 4;
/*  10:    */   public static final int JJTUNMODIFIEDCLASSDECLARATION = 5;
/*  11:    */   public static final int JJTCLASSBODY = 6;
/*  12:    */   public static final int JJTNESTEDCLASSDECLARATION = 7;
/*  13:    */   public static final int JJTCLASSBODYDECLARATION = 8;
/*  14:    */   public static final int JJTMETHODDECLARATIONLOOKAHEAD = 9;
/*  15:    */   public static final int JJTINTERFACEDECLARATION = 10;
/*  16:    */   public static final int JJTNESTEDINTERFACEDECLARATION = 11;
/*  17:    */   public static final int JJTUNMODIFIEDINTERFACEDECLARATION = 12;
/*  18:    */   public static final int JJTINTERFACEMEMBERDECLARATION = 13;
/*  19:    */   public static final int JJTFIELDDECLARATION = 14;
/*  20:    */   public static final int JJTVARIABLEDECLARATOR = 15;
/*  21:    */   public static final int JJTVARIABLEDECLARATORID = 16;
/*  22:    */   public static final int JJTVARIABLEINITIALIZER = 17;
/*  23:    */   public static final int JJTARRAYINITIALIZER = 18;
/*  24:    */   public static final int JJTMETHODDECLARATION = 19;
/*  25:    */   public static final int JJTMETHODDECLARATOR = 20;
/*  26:    */   public static final int JJTFORMALPARAMETERS = 21;
/*  27:    */   public static final int JJTFORMALPARAMETER = 22;
/*  28:    */   public static final int JJTCONSTRUCTORDECLARATION = 23;
/*  29:    */   public static final int JJTEXPLICITCONSTRUCTORINVOCATION = 24;
/*  30:    */   public static final int JJTINITIALIZER = 25;
/*  31:    */   public static final int JJTTYPE = 26;
/*  32:    */   public static final int JJTPRIMITIVETYPE = 27;
/*  33:    */   public static final int JJTRESULTTYPE = 28;
/*  34:    */   public static final int JJTNAME = 29;
/*  35:    */   public static final int JJTNAMELIST = 30;
/*  36:    */   public static final int JJTEXPRESSION = 31;
/*  37:    */   public static final int JJTASSIGNMENTOPERATOR = 32;
/*  38:    */   public static final int JJTCONDITIONALEXPRESSION = 33;
/*  39:    */   public static final int JJTCONDITIONALOREXPRESSION = 34;
/*  40:    */   public static final int JJTCONDITIONALANDEXPRESSION = 35;
/*  41:    */   public static final int JJTINCLUSIVEOREXPRESSION = 36;
/*  42:    */   public static final int JJTEXCLUSIVEOREXPRESSION = 37;
/*  43:    */   public static final int JJTANDEXPRESSION = 38;
/*  44:    */   public static final int JJTEQUALITYEXPRESSION = 39;
/*  45:    */   public static final int JJTINSTANCEOFEXPRESSION = 40;
/*  46:    */   public static final int JJTRELATIONALEXPRESSION = 41;
/*  47:    */   public static final int JJTSHIFTEXPRESSION = 42;
/*  48:    */   public static final int JJTADDITIVEEXPRESSION = 43;
/*  49:    */   public static final int JJTMULTIPLICATIVEEXPRESSION = 44;
/*  50:    */   public static final int JJTUNARYEXPRESSION = 45;
/*  51:    */   public static final int JJTPREINCREMENTEXPRESSION = 46;
/*  52:    */   public static final int JJTPREDECREMENTEXPRESSION = 47;
/*  53:    */   public static final int JJTUNARYEXPRESSIONNOTPLUSMINUS = 48;
/*  54:    */   public static final int JJTCASTLOOKAHEAD = 49;
/*  55:    */   public static final int JJTPOSTFIXEXPRESSION = 50;
/*  56:    */   public static final int JJTCASTEXPRESSION = 51;
/*  57:    */   public static final int JJTPRIMARYEXPRESSION = 52;
/*  58:    */   public static final int JJTPRIMARYPREFIX = 53;
/*  59:    */   public static final int JJTPRIMARYSUFFIX = 54;
/*  60:    */   public static final int JJTLITERAL = 55;
/*  61:    */   public static final int JJTBOOLEANLITERAL = 56;
/*  62:    */   public static final int JJTNULLLITERAL = 57;
/*  63:    */   public static final int JJTARGUMENTS = 58;
/*  64:    */   public static final int JJTARGUMENTLIST = 59;
/*  65:    */   public static final int JJTALLOCATIONEXPRESSION = 60;
/*  66:    */   public static final int JJTARRAYDIMSANDINITS = 61;
/*  67:    */   public static final int JJTSTATEMENT = 62;
/*  68:    */   public static final int JJTLABELEDSTATEMENT = 63;
/*  69:    */   public static final int JJTBLOCK = 64;
/*  70:    */   public static final int JJTBLOCKSTATEMENT = 65;
/*  71:    */   public static final int JJTLOCALVARIABLEDECLARATION = 66;
/*  72:    */   public static final int JJTEMPTYSTATEMENT = 67;
/*  73:    */   public static final int JJTSTATEMENTEXPRESSION = 68;
/*  74:    */   public static final int JJTSWITCHSTATEMENT = 69;
/*  75:    */   public static final int JJTSWITCHLABEL = 70;
/*  76:    */   public static final int JJTIFSTATEMENT = 71;
/*  77:    */   public static final int JJTWHILESTATEMENT = 72;
/*  78:    */   public static final int JJTDOSTATEMENT = 73;
/*  79:    */   public static final int JJTFORSTATEMENT = 74;
/*  80:    */   public static final int JJTFORINIT = 75;
/*  81:    */   public static final int JJTSTATEMENTEXPRESSIONLIST = 76;
/*  82:    */   public static final int JJTFORUPDATE = 77;
/*  83:    */   public static final int JJTBREAKSTATEMENT = 78;
/*  84:    */   public static final int JJTCONTINUESTATEMENT = 79;
/*  85:    */   public static final int JJTRETURNSTATEMENT = 80;
/*  86:    */   public static final int JJTTHROWSTATEMENT = 81;
/*  87:    */   public static final int JJTSYNCHRONIZEDSTATEMENT = 82;
/*  88:    */   public static final int JJTTRYSTATEMENT = 83;
/*  89:    */   public static final int JJTOMPDIRECTIVE = 84;
/*  90:    */   public static final int JJTOMPPARALLELDIRECTIVE = 85;
/*  91:    */   public static final int JJTOMPMASTERDIRECTIVE = 86;
/*  92:    */   public static final int JJTOMPORDEREDDIRECTIVE = 87;
/*  93:    */   public static final int JJTOMPBARRIERDIRECTIVE = 88;
/*  94:    */   public static final int JJTOMPSINGLEDIRECTIVE = 89;
/*  95:    */   public static final int JJTOMPFORDIRECTIVE = 90;
/*  96:    */   public static final int JJTOMPFORSTATEMENT = 91;
/*  97:    */   public static final int JJTOMPSIMPLERELATION = 92;
/*  98:    */   public static final int JJTOMPSIMPLEUPDATE = 93;
/*  99:    */   public static final int JJTOMPLONGUPDATE = 94;
/* 100:    */   public static final int JJTOMPSECTIONSDIRECTIVE = 95;
/* 101:    */   public static final int JJTOMPSECTIONSBLOCK = 96;
/* 102:    */   public static final int JJTOMPSECTIONDIRECTIVE = 97;
/* 103:    */   public static final int JJTOMPCRITICALDIRECTIVE = 98;
/* 104:    */   public static final int JJTOMPONLYDIRECTIVE = 99;
/* 105:    */   public static final int JJTOMPCLAUSELIST = 100;
/* 106:    */   public static final int JJTOMPCLAUSE = 101;
/* 107:    */   public static final int JJTOMPPRIVATECLAUSE = 102;
/* 108:    */   public static final int JJTOMPFIRSTPRIVATECLAUSE = 103;
/* 109:    */   public static final int JJTOMPLASTPRIVATECLAUSE = 104;
/* 110:    */   public static final int JJTOMPSHAREDCLAUSE = 105;
/* 111:    */   public static final int JJTOMPDEFAULTCLAUSE = 106;
/* 112:    */   public static final int JJTOMPNOWAITCLAUSE = 107;
/* 113:    */   public static final int JJTOMPIFCLAUSE = 108;
/* 114:    */   public static final int JJTOMPSCHEDULECLAUSE = 109;
/* 115:    */   public static final int JJTOMPORDEREDCLAUSE = 110;
/* 116:    */   public static final int JJTOMPREDUCTIONCLAUSE = 111;
/* 117:    */   public static final int JJTOMPREDUCTIONOP = 112;
/* 118:    */   public static final int JJTVARNAMELIST = 113;
/* 119:    */   public static final int JJTVARNAME = 114;
/* 120:    */   public static final int JJTIDENTIFIER = 115;
/* 121:125 */   public static final String[] jjtNodeName = { "CompilationUnit", "PackageDeclaration", "ImportDeclaration", "TypeDeclaration", "ClassDeclaration", "UnmodifiedClassDeclaration", "ClassBody", "NestedClassDeclaration", "ClassBodyDeclaration", "MethodDeclarationLookahead", "InterfaceDeclaration", "NestedInterfaceDeclaration", "UnmodifiedInterfaceDeclaration", "InterfaceMemberDeclaration", "FieldDeclaration", "VariableDeclarator", "VariableDeclaratorId", "VariableInitializer", "ArrayInitializer", "MethodDeclaration", "MethodDeclarator", "FormalParameters", "FormalParameter", "ConstructorDeclaration", "ExplicitConstructorInvocation", "Initializer", "Type", "PrimitiveType", "ResultType", "Name", "NameList", "Expression", "AssignmentOperator", "ConditionalExpression", "ConditionalOrExpression", "ConditionalAndExpression", "InclusiveOrExpression", "ExclusiveOrExpression", "AndExpression", "EqualityExpression", "InstanceOfExpression", "RelationalExpression", "ShiftExpression", "AdditiveExpression", "MultiplicativeExpression", "UnaryExpression", "PreIncrementExpression", "PreDecrementExpression", "UnaryExpressionNotPlusMinus", "CastLookahead", "PostfixExpression", "CastExpression", "PrimaryExpression", "PrimaryPrefix", "PrimarySuffix", "Literal", "BooleanLiteral", "NullLiteral", "Arguments", "ArgumentList", "AllocationExpression", "ArrayDimsAndInits", "Statement", "LabeledStatement", "Block", "BlockStatement", "LocalVariableDeclaration", "EmptyStatement", "StatementExpression", "SwitchStatement", "SwitchLabel", "IfStatement", "WhileStatement", "DoStatement", "ForStatement", "ForInit", "StatementExpressionList", "ForUpdate", "BreakStatement", "ContinueStatement", "ReturnStatement", "ThrowStatement", "SynchronizedStatement", "TryStatement", "OMPDirective", "OMPParallelDirective", "OMPMasterDirective", "OMPOrderedDirective", "OMPBarrierDirective", "OMPSingleDirective", "OMPForDirective", "OMPForStatement", "OMPSimpleRelation", "OMPSimpleUpdate", "OMPLongUpdate", "OMPSectionsDirective", "OMPSectionsBlock", "OMPSectionDirective", "OMPCriticalDirective", "OMPOnlyDirective", "OMPClauseList", "OMPClause", "OMPPrivateClause", "OMPFirstPrivateClause", "OMPLastPrivateClause", "OMPSharedClause", "OMPDefaultClause", "OMPNowaitClause", "OMPIfClause", "OMPScheduleClause", "OMPOrderedClause", "OMPReductionClause", "OMPReductionOp", "VarNameList", "VarName", "Identifier" };
/* 122:    */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.compiler.JavaParserTreeConstants
 * JD-Core Version:    0.7.0.1
 */