package jomp.compiler;

public class VarItem
{
  public String name;
  public String type;
  public int kind;
  public int flag;
  public int red;
  public static final int PRIVATE = 1;
  public static final int FIRSTPRIVATE = 2;
  public static final int LASTPRIVATE = 4;
  public static final int REDUCTION = 8;
  public static final int SHARED = 16;
  public static final int INITIALIZED = 1;
}


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.compiler.VarItem
 * JD-Core Version:    0.7.0.1
 */