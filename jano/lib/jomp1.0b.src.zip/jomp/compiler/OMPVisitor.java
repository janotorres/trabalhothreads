/*    1:     */ package jomp.compiler;
/*    2:     */ 
/*    3:     */ import java.io.PrintStream;
/*    4:     */ import java.io.PrintWriter;
/*    5:     */ import java.io.StringWriter;
/*    6:     */ import java.util.EmptyStackException;
/*    7:     */ import java.util.LinkedList;
/*    8:     */ import java.util.Stack;
/*    9:     */ 
/*   10:     */ public class OMPVisitor
/*   11:     */   extends UnparseVisitor
/*   12:     */ {
/*   13:  11 */   SymbolTable table = new SymbolTable();
/*   14:  13 */   Stack classStack = new Stack();
/*   15:  14 */   Stack outerStack = new Stack();
/*   16:  16 */   boolean isStatic = false;
/*   17:  17 */   boolean isMeDefined = false;
/*   18:  18 */   boolean isInOrderedLoop = false;
/*   19:  19 */   String loopVarName = null;
/*   20:  20 */   String loopWholeDataName = null;
/*   21:  21 */   VarTable pvt = null;
/*   22:     */   
/*   23:     */   public OMPVisitor(PrintWriter paramPrintWriter)
/*   24:     */   {
/*   25:  25 */     super(paramPrintWriter);
/*   26:     */   }
/*   27:     */   
/*   28:  31 */   private int uniqueNumber = 0;
/*   29:     */   
/*   30:     */   public String getUniqueName()
/*   31:     */   {
/*   32:  34 */     return "__ompName_" + Integer.toString(this.uniqueNumber++);
/*   33:     */   }
/*   34:     */   
/*   35:     */   public String getUniqueName(String paramString)
/*   36:     */   {
/*   37:  38 */     return "__omp_" + paramString + Integer.toString(this.uniqueNumber++);
/*   38:     */   }
/*   39:     */   
/*   40:     */   public String getSameName(String paramString)
/*   41:     */   {
/*   42:  42 */     return "__omp_" + paramString + Integer.toString(this.uniqueNumber - 1);
/*   43:     */   }
/*   44:     */   
/*   45:     */   public Object visit(ASTVariableInitializer paramASTVariableInitializer, Object paramObject)
/*   46:     */   {
/*   47:  50 */     if (((SimpleNode)paramASTVariableInitializer.jjtGetParent()).id == 15)
/*   48:     */     {
/*   49:  51 */       ASTVariableDeclaratorId localASTVariableDeclaratorId = (ASTVariableDeclaratorId)paramASTVariableInitializer.jjtGetParent().jjtGetChild(0);
/*   50:  52 */       SymbolTable.Symbol localSymbol = this.table.findSymbol(localASTVariableDeclaratorId.getFirstToken().toString());
/*   51:  53 */       if (localSymbol != null) {
/*   52:  54 */         localSymbol.isInitialized = true;
/*   53:     */       }
/*   54:     */     }
/*   55:  56 */     return print(paramASTVariableInitializer, paramObject);
/*   56:     */   }
/*   57:     */   
/*   58:     */   public Object visit(ASTAssignmentOperator paramASTAssignmentOperator, Object paramObject)
/*   59:     */   {
/*   60:  62 */     SimpleNode localSimpleNode = (SimpleNode)paramASTAssignmentOperator.jjtGetParent();
/*   61:     */     try
/*   62:     */     {
/*   63:     */       do
/*   64:     */       {
/*   65:  67 */         localSimpleNode = (SimpleNode)localSimpleNode.jjtGetChild(0);
/*   66:  68 */       } while (localSimpleNode.id != 52);
/*   67:  69 */       ASTPrimaryExpression localASTPrimaryExpression = (ASTPrimaryExpression)localSimpleNode;
/*   68:  70 */       SymbolTable.Symbol localSymbol = this.table.findSymbol(localASTPrimaryExpression.getFirstToken().toString());
/*   69:  71 */       if (localSymbol != null) {
/*   70:  72 */         localSymbol.isInitialized = true;
/*   71:     */       }
/*   72:     */     }
/*   73:     */     catch (Exception localException)
/*   74:     */     {
/*   75:  74 */       System.err.println("Hey, guy, why you use so nasty expressions like this?");
/*   76:  75 */       paramASTAssignmentOperator.dump("==>");
/*   77:     */     }
/*   78:  77 */     return print(paramASTAssignmentOperator, paramObject);
/*   79:     */   }
/*   80:     */   
/*   81:     */   public Object visit(ASTStatement paramASTStatement, Object paramObject)
/*   82:     */   {
/*   83:  84 */     if (paramASTStatement.getFirstToken().toString() == "//omp") {
/*   84:  85 */       return print((SimpleNode)paramASTStatement.jjtGetChild(0), paramObject);
/*   85:     */     }
/*   86:  87 */     return print(paramASTStatement, paramObject);
/*   87:     */   }
/*   88:     */   
/*   89:     */   public Object visit(ASTMethodDeclaration paramASTMethodDeclaration, Object paramObject)
/*   90:     */   {
/*   91:  97 */     boolean bool = this.isStatic;
/*   92:  98 */     this.isStatic = false;
/*   93:  99 */     for (Token localToken = paramASTMethodDeclaration.getFirstToken(); localToken != ((SimpleNode)paramASTMethodDeclaration.jjtGetChild(0)).getFirstToken(); localToken = localToken.next) {
/*   94: 100 */       if (localToken.kind == 50) {
/*   95: 101 */         this.isStatic = true;
/*   96:     */       }
/*   97:     */     }
/*   98: 105 */     this.table.addScope();
/*   99: 106 */     paramObject = super.visit(paramASTMethodDeclaration, paramObject);
/*  100: 107 */     this.table.killScope();
/*  101: 108 */     this.isStatic = bool;
/*  102: 109 */     return paramObject;
/*  103:     */   }
/*  104:     */   
/*  105:     */   public Object visit(ASTBlock paramASTBlock, Object paramObject)
/*  106:     */   {
/*  107: 118 */     this.table.addScope();
/*  108: 119 */     paramObject = super.visit(paramASTBlock, paramObject);
/*  109: 120 */     this.table.killScope();
/*  110: 121 */     return paramObject;
/*  111:     */   }
/*  112:     */   
/*  113:     */   public Object visit(ASTForStatement paramASTForStatement, Object paramObject)
/*  114:     */   {
/*  115: 127 */     this.table.addScope();
/*  116: 128 */     paramObject = super.visit(paramASTForStatement, paramObject);
/*  117: 129 */     this.table.killScope();
/*  118: 130 */     return paramObject;
/*  119:     */   }
/*  120:     */   
/*  121:     */   public Object visit(ASTFormalParameter paramASTFormalParameter, Object paramObject)
/*  122:     */   {
/*  123: 137 */     ASTType localASTType = (ASTType)paramASTFormalParameter.jjtGetChild(0);
/*  124: 138 */     ASTVariableDeclaratorId localASTVariableDeclaratorId = (ASTVariableDeclaratorId)paramASTFormalParameter.jjtGetChild(1);
/*  125:     */     
/*  126:     */ 
/*  127: 141 */     String str2 = ((SimpleNode)paramASTFormalParameter.jjtGetChild(1)).getFirstToken().toString();
/*  128:     */     
/*  129: 143 */     String str1 = "";
/*  130:     */     
/*  131: 145 */     Token localToken = localASTType.getFirstToken();
/*  132:     */     for (;;)
/*  133:     */     {
/*  134: 147 */       str1 = str1 + " " + localToken.toString();
/*  135: 148 */       if (localToken == localASTType.getLastToken()) {
/*  136:     */         break;
/*  137:     */       }
/*  138: 149 */       localToken = localToken.next;
/*  139:     */     }
/*  140: 154 */     localToken = localASTVariableDeclaratorId.getFirstToken();
/*  141: 155 */     while (localToken != localASTVariableDeclaratorId.getLastToken())
/*  142:     */     {
/*  143: 156 */       localToken = localToken.next;
/*  144: 157 */       str1 = str1 + " " + localToken.toString();
/*  145:     */     }
/*  146: 160 */     SymbolTable.Symbol localSymbol = this.table.addSymbol(str2);
/*  147: 161 */     localSymbol.sig = str1.trim();
/*  148:     */     
/*  149:     */ 
/*  150: 164 */     localSymbol.isInitialized = true;
/*  151: 165 */     return super.visit(paramASTFormalParameter, paramObject);
/*  152:     */   }
/*  153:     */   
/*  154:     */   public Object visit(ASTLocalVariableDeclaration paramASTLocalVariableDeclaration, Object paramObject)
/*  155:     */   {
/*  156: 175 */     ASTType localASTType = (ASTType)paramASTLocalVariableDeclaration.jjtGetChild(0);
/*  157: 177 */     for (int i = 1; i < paramASTLocalVariableDeclaration.jjtGetNumChildren(); i++)
/*  158:     */     {
/*  159: 178 */       String str1 = ((SimpleNode)paramASTLocalVariableDeclaration.jjtGetChild(i).jjtGetChild(0)).getFirstToken().toString();
/*  160: 179 */       ASTVariableDeclaratorId localASTVariableDeclaratorId = (ASTVariableDeclaratorId)paramASTLocalVariableDeclaration.jjtGetChild(i).jjtGetChild(0);
/*  161:     */       
/*  162: 181 */       String str2 = "";
/*  163:     */       
/*  164: 183 */       Token localToken = localASTType.getFirstToken();
/*  165:     */       for (;;)
/*  166:     */       {
/*  167: 185 */         str2 = str2 + " " + localToken.toString();
/*  168: 186 */         if (localToken == localASTType.getLastToken()) {
/*  169:     */           break;
/*  170:     */         }
/*  171: 187 */         localToken = localToken.next;
/*  172:     */       }
/*  173: 192 */       localToken = localASTVariableDeclaratorId.getFirstToken();
/*  174: 193 */       while (localToken != localASTVariableDeclaratorId.getLastToken())
/*  175:     */       {
/*  176: 194 */         localToken = localToken.next;
/*  177: 195 */         str2 = str2 + " " + localToken.toString();
/*  178:     */       }
/*  179: 198 */       SymbolTable.Symbol localSymbol = this.table.addSymbol(str1);
/*  180: 199 */       localSymbol.sig = str2.trim();
/*  181:     */     }
/*  182: 201 */     return super.visit(paramASTLocalVariableDeclaration, paramObject);
/*  183:     */   }
/*  184:     */   
/*  185:     */   public Object visit(ASTClassBody paramASTClassBody, Object paramObject)
/*  186:     */   {
/*  187: 212 */     this.out.println(" {");
/*  188: 213 */     for (int i = 0; i < paramASTClassBody.jjtGetNumChildren(); i++) {
/*  189: 214 */       paramObject = print((SimpleNode)paramASTClassBody.jjtGetChild(i), paramObject);
/*  190:     */     }
/*  191:     */     try
/*  192:     */     {
/*  193:     */       for (;;)
/*  194:     */       {
/*  195: 219 */         localStringWriter = (StringWriter)this.classStack.pop();
/*  196: 220 */         this.out.println(localStringWriter.toString());
/*  197:     */       }
/*  198:     */     }
/*  199:     */     catch (EmptyStackException localEmptyStackException1)
/*  200:     */     {
/*  201:     */       StringWriter localStringWriter;
/*  202: 225 */       this.out.println("}");
/*  203:     */       try
/*  204:     */       {
/*  205:     */         for (;;)
/*  206:     */         {
/*  207: 230 */           localStringWriter = (StringWriter)this.outerStack.pop();
/*  208: 231 */           this.out.println(localStringWriter.toString());
/*  209:     */         }
/*  210:     */       }
/*  211:     */       catch (EmptyStackException localEmptyStackException2) {}
/*  212:     */     }
/*  213: 236 */     return paramObject;
/*  214:     */   }
/*  215:     */   
/*  216:     */   public Object visit(ASTOMPParallelDirective paramASTOMPParallelDirective, Object paramObject)
/*  217:     */   {
/*  218: 247 */     VarTable localVarTable1 = new VarTable();
/*  219:     */     
/*  220: 249 */     ASTExpression localASTExpression = null;
/*  221:     */     
/*  222: 251 */     int i = 0;
/*  223: 252 */     int j = 0;
/*  224: 253 */     int k = 0;
/*  225: 254 */     int m = 0;
/*  226: 255 */     ASTOMPClauseList localASTOMPClauseList = null;
/*  227: 257 */     switch (((SimpleNode)paramASTOMPParallelDirective.jjtGetChild(0)).id)
/*  228:     */     {
/*  229:     */     case 90: 
/*  230: 259 */       System.err.println("Parallel For Directive Encountered");
/*  231: 260 */       j = 1;
/*  232: 261 */       localASTOMPClauseList = (ASTOMPClauseList)paramASTOMPParallelDirective.jjtGetChild(0).jjtGetChild(0);
/*  233: 262 */       break;
/*  234:     */     case 95: 
/*  235: 264 */       System.err.println("Parallel Sections Directive Encountered");
/*  236: 265 */       k = 1;
/*  237: 266 */       localASTOMPClauseList = (ASTOMPClauseList)paramASTOMPParallelDirective.jjtGetChild(0).jjtGetChild(0);
/*  238: 267 */       break;
/*  239:     */     case 100: 
/*  240: 269 */       System.err.println("Parallel Directive Encountered");
/*  241: 270 */       localASTOMPClauseList = (ASTOMPClauseList)paramASTOMPParallelDirective.jjtGetChild(0);
/*  242:     */     }
/*  243: 275 */     for (int n = 0; n < localASTOMPClauseList.jjtGetNumChildren(); n++) {
/*  244: 276 */       switch (((SimpleNode)localASTOMPClauseList.jjtGetChild(n).jjtGetChild(0)).id)
/*  245:     */       {
/*  246:     */       case 107: 
/*  247: 278 */         System.err.println("Warning: Can't use nowait clause with parallel directive");
/*  248: 279 */         break;
/*  249:     */       case 106: 
/*  250: 281 */         if (((SimpleNode)localASTOMPClauseList.jjtGetChild(n).jjtGetChild(0)).getFirstToken().next.next.kind == 69) {
/*  251: 282 */           m = 1;
/*  252:     */         }
/*  253:     */         break;
/*  254:     */       case 105: 
/*  255: 285 */         localVarTable1.addNameList((ASTVarNameList)localASTOMPClauseList.jjtGetChild(n).jjtGetChild(0).jjtGetChild(0), 16, 0, this.table);
/*  256: 286 */         break;
/*  257:     */       case 102: 
/*  258: 288 */         localVarTable1.addNameList((ASTVarNameList)localASTOMPClauseList.jjtGetChild(n).jjtGetChild(0).jjtGetChild(0), 1, 0, this.table);
/*  259: 289 */         break;
/*  260:     */       case 103: 
/*  261: 291 */         localVarTable1.addNameList((ASTVarNameList)localASTOMPClauseList.jjtGetChild(n).jjtGetChild(0).jjtGetChild(0), 2, 0, this.table);
/*  262: 292 */         break;
/*  263:     */       case 104: 
/*  264: 294 */         if ((j == 0) && (k == 0)) {
/*  265: 295 */           System.err.println("Warning: lastprivate clause has no meaning with parallel directive");
/*  266:     */         } else {
/*  267: 297 */           localVarTable1.addNameList((ASTVarNameList)localASTOMPClauseList.jjtGetChild(n).jjtGetChild(0).jjtGetChild(0), 16, 0, this.table);
/*  268:     */         }
/*  269: 298 */         break;
/*  270:     */       case 108: 
/*  271: 300 */         localASTExpression = (ASTExpression)localASTOMPClauseList.jjtGetChild(n).jjtGetChild(0).jjtGetChild(0);
/*  272: 301 */         break;
/*  273:     */       case 111: 
/*  274: 303 */         localObject = (ASTOMPReductionClause)localASTOMPClauseList.jjtGetChild(n).jjtGetChild(0);
/*  275: 304 */         if ((j == 0) && (k == 0))
/*  276:     */         {
/*  277: 305 */           int i1 = ReductionType.getTypeByToken(((SimpleNode)((SimpleNode)localObject).jjtGetChild(0)).getFirstToken().kind);
/*  278: 306 */           localVarTable1.addNameList((ASTVarNameList)((SimpleNode)localObject).jjtGetChild(1), 8, i1, this.table);
/*  279:     */         }
/*  280:     */         else
/*  281:     */         {
/*  282: 308 */           localVarTable1.addNameList((ASTVarNameList)((SimpleNode)localObject).jjtGetChild(1), 16, 0, this.table);
/*  283:     */         }
/*  284: 310 */         break;
/*  285:     */       case 109: 
/*  286:     */       case 110: 
/*  287:     */       default: 
/*  288: 312 */         if ((j == 0) && (k == 0)) {
/*  289: 313 */           System.err.println("Warning: meaningless clause " + ((SimpleNode)localASTOMPClauseList.jjtGetChild(n)).id + " with master - ignored");
/*  290:     */         }
/*  291:     */         break;
/*  292:     */       }
/*  293:     */     }
/*  294: 319 */     if (m == 0) {
/*  295: 320 */       localVarTable1.addShared(this.table);
/*  296:     */     }
/*  297: 324 */     Object localObject = getUniqueName("Class");
/*  298: 325 */     String str1 = getSameName("Object");
/*  299:     */     
/*  300:     */ 
/*  301:     */ 
/*  302:     */ 
/*  303:     */ 
/*  304:     */ 
/*  305:     */ 
/*  306: 333 */     this.out.println("\n");
/*  307: 334 */     this.out.println("// OMP PARALLEL BLOCK BEGINS");
/*  308: 335 */     this.out.println("{");
/*  309: 336 */     this.out.println("  " + (String)localObject + " " + str1 + " = new " + (String)localObject + "();");
/*  310:     */     
/*  311:     */ 
/*  312: 339 */     this.out.println("  // shared variables");
/*  313: 340 */     localVarTable1.getInit(16);
/*  314:     */     VarItem localVarItem;
/*  315: 341 */     while ((localVarItem = localVarTable1.getNext()) != null) {
/*  316: 343 */       if ((localVarItem.flag & 0x1) == 1) {
/*  317: 344 */         this.out.println("  " + str1 + "." + localVarItem.name + " = " + localVarItem.name + ";");
/*  318:     */       }
/*  319:     */     }
/*  320: 348 */     this.out.println("  // firstprivate variables");
/*  321: 349 */     localVarTable1.getInit(2);
/*  322: 350 */     while ((localVarItem = localVarTable1.getNext()) != null) {
/*  323: 351 */       this.out.println("  " + str1 + "._fp_" + localVarItem.name + " = " + localVarItem.name + ";");
/*  324:     */     }
/*  325: 354 */     this.out.println("  try {");
/*  326: 356 */     if (localASTExpression != null)
/*  327:     */     {
/*  328: 357 */       this.out.print("    if(");
/*  329: 358 */       paramObject = print(localASTExpression, paramObject);
/*  330: 359 */       this.out.println(") {");
/*  331: 360 */       this.out.println("        jomp.runtime.OMP.doParallel(" + str1 + ");");
/*  332: 361 */       this.out.println("    } else {");
/*  333: 362 */       this.out.println("        " + str1 + ".go(0);");
/*  334: 363 */       this.out.println("    }");
/*  335:     */     }
/*  336:     */     else
/*  337:     */     {
/*  338: 365 */       this.out.println("    jomp.runtime.OMP.doParallel(" + str1 + ");");
/*  339:     */     }
/*  340: 367 */     this.out.println("  } catch(Throwable __omp_exception) {");
/*  341: 368 */     this.out.println("    System.err.println(\"OMP Warning: Illegal thread exception ignored!\");");
/*  342: 369 */     this.out.println("    System.err.println(__omp_exception);");
/*  343: 370 */     this.out.println("  }");
/*  344:     */     
/*  345:     */ 
/*  346: 373 */     this.out.println("  // reduction variables");
/*  347: 374 */     localVarTable1.getInit(8);
/*  348: 375 */     while ((localVarItem = localVarTable1.getNext()) != null) {
/*  349: 376 */       this.out.println("  " + localVarItem.name + "  " + ReductionType.opName(localVarItem.red) + "= " + str1 + "._rd_" + localVarItem.name + ";");
/*  350:     */     }
/*  351: 392 */     this.out.println("  // shared variables");
/*  352: 393 */     localVarTable1.getInit(16);
/*  353: 394 */     while ((localVarItem = localVarTable1.getNext()) != null) {
/*  354: 395 */       this.out.println("  " + localVarItem.name + " = " + str1 + "." + localVarItem.name + ";");
/*  355:     */     }
/*  356: 398 */     this.out.println("}");
/*  357: 399 */     this.out.println("// OMP PARALLEL BLOCK ENDS");
/*  358:     */     
/*  359:     */ 
/*  360:     */ 
/*  361:     */ 
/*  362:     */ 
/*  363:     */ 
/*  364:     */ 
/*  365:     */ 
/*  366:     */ 
/*  367:     */ 
/*  368: 410 */     StringWriter localStringWriter = new StringWriter();
/*  369: 411 */     PrintWriter localPrintWriter1 = new PrintWriter(localStringWriter);
/*  370:     */     
/*  371:     */ 
/*  372: 414 */     localPrintWriter1.println("\n");
/*  373:     */     String str2;
/*  374: 415 */     if (m == 0)
/*  375:     */     {
/*  376: 416 */       this.classStack.push(localStringWriter);
/*  377: 417 */       localPrintWriter1.println("// OMP PARALLEL REGION INNER CLASS DEFINITION BEGINS");
/*  378: 418 */       localPrintWriter1.print("private");
/*  379: 421 */       if (this.isStatic) {
/*  380: 422 */         localPrintWriter1.print(" static");
/*  381:     */       }
/*  382: 423 */       str2 = "// OMP PARALLEL REGION INNER CLASS DEFINITION ENDS";
/*  383:     */     }
/*  384:     */     else
/*  385:     */     {
/*  386: 425 */       this.outerStack.push(localStringWriter);
/*  387: 426 */       localPrintWriter1.println("// OMP PARALLEL REGION OUTER CLASS DEFINITION BEGINS");
/*  388: 427 */       str2 = "// OMP PARALLEL REGION OUTER CLASS DEFINITION ENDS";
/*  389:     */     }
/*  390: 430 */     localPrintWriter1.println(" class " + (String)localObject + " extends jomp.runtime.BusyTask {");
/*  391:     */     
/*  392: 432 */     StringBuffer localStringBuffer = new StringBuffer("  ");
/*  393:     */     
/*  394:     */ 
/*  395: 435 */     localPrintWriter1.println(localStringBuffer + "// shared variables");
/*  396: 436 */     localVarTable1.getInit(16);
/*  397: 437 */     while ((localVarItem = localVarTable1.getNext()) != null) {
/*  398: 438 */       localPrintWriter1.println(localStringBuffer + localVarItem.type + " " + localVarItem.name + ";");
/*  399:     */     }
/*  400: 441 */     localPrintWriter1.println(localStringBuffer + "// firstprivate variables");
/*  401: 442 */     localVarTable1.getInit(2);
/*  402: 443 */     while ((localVarItem = localVarTable1.getNext()) != null) {
/*  403: 444 */       localPrintWriter1.println(localStringBuffer + localVarItem.type + " _fp_" + localVarItem.name + ";");
/*  404:     */     }
/*  405: 447 */     localPrintWriter1.println(localStringBuffer + "// variables to hold results of reduction");
/*  406: 448 */     localVarTable1.getInit(8);
/*  407: 449 */     while ((localVarItem = localVarTable1.getNext()) != null) {
/*  408: 450 */       localPrintWriter1.println(localStringBuffer + localVarItem.type + " _rd_" + localVarItem.name + ";");
/*  409:     */     }
/*  410: 454 */     localPrintWriter1.println("");
/*  411: 455 */     localPrintWriter1.println(localStringBuffer + "public void go(int __omp_me) throws Throwable {");
/*  412: 456 */     boolean bool = this.isMeDefined;
/*  413: 457 */     this.isMeDefined = true;
/*  414:     */     
/*  415:     */ 
/*  416:     */ 
/*  417: 461 */     localPrintWriter1.println(localStringBuffer + "// firstprivate variables + init");
/*  418: 462 */     localVarTable1.getInit(2);
/*  419: 463 */     while ((localVarItem = localVarTable1.getNext()) != null)
/*  420:     */     {
/*  421: 464 */       localPrintWriter1.print(localStringBuffer + localVarItem.type + " " + localVarItem.name + " = ");
/*  422: 465 */       localPrintWriter1.print("(" + localVarItem.type + ")" + " _fp_" + localVarItem.name);
/*  423: 466 */       if (!isPrimitiveType(localVarItem.type)) {
/*  424: 467 */         localPrintWriter1.print(".clone()");
/*  425:     */       }
/*  426: 468 */       localPrintWriter1.println(";");
/*  427:     */     }
/*  428: 472 */     localPrintWriter1.println(localStringBuffer + "// private variables");
/*  429: 473 */     localVarTable1.getInit(1);
/*  430: 474 */     while ((localVarItem = localVarTable1.getNext()) != null)
/*  431:     */     {
/*  432: 475 */       localPrintWriter1.print(localStringBuffer + localVarItem.type + " " + localVarItem.name);
/*  433: 476 */       if ((!isPrimitiveType(localVarItem.type)) && (!isArray(localVarItem.type))) {
/*  434: 478 */         localPrintWriter1.print(" = new " + localVarItem.type + "()");
/*  435:     */       }
/*  436: 479 */       localPrintWriter1.println(";");
/*  437:     */     }
/*  438: 483 */     localPrintWriter1.println(localStringBuffer + "// reduction variables, init to default");
/*  439: 484 */     localVarTable1.getInit(8);
/*  440: 485 */     while ((localVarItem = localVarTable1.getNext()) != null) {
/*  441: 486 */       localPrintWriter1.println(localStringBuffer + localVarItem.type + " " + localVarItem.name + " = " + ReductionType.opDefault(localVarItem.red) + ";");
/*  442:     */     }
/*  443: 490 */     localStringBuffer.append("  ");
/*  444: 491 */     localPrintWriter1.println(localStringBuffer + "// OMP USER CODE BEGINS");
/*  445: 492 */     PrintWriter localPrintWriter2 = swapOut(localPrintWriter1);
/*  446:     */     
/*  447: 494 */     VarTable localVarTable2 = this.pvt;
/*  448: 495 */     this.pvt = localVarTable1;
/*  449: 496 */     this.table.addScope();
/*  450: 497 */     if (j != 0) {
/*  451: 498 */       paramObject = visit((ASTOMPForDirective)paramASTOMPParallelDirective.jjtGetChild(0), paramObject, true);
/*  452: 499 */     } else if (k != 0) {
/*  453: 500 */       paramObject = visit((ASTOMPSectionsDirective)paramASTOMPParallelDirective.jjtGetChild(0), paramObject, true);
/*  454:     */     } else {
/*  455: 502 */       paramObject = visit((SimpleNode)paramASTOMPParallelDirective.jjtGetChild(1), paramObject);
/*  456:     */     }
/*  457: 504 */     this.table.killScope();
/*  458: 505 */     this.pvt = localVarTable2;
/*  459:     */     
/*  460: 507 */     localPrintWriter2 = swapOut(localPrintWriter2);
/*  461: 508 */     localPrintWriter1.println("");
/*  462: 509 */     localPrintWriter1.println(localStringBuffer + "// OMP USER CODE ENDS");
/*  463: 510 */     localStringBuffer.setLength(localStringBuffer.length() - 2);
/*  464:     */     
/*  465:     */ 
/*  466:     */ 
/*  467: 514 */     localPrintWriter1.println(localStringBuffer + "// call reducer");
/*  468: 515 */     localVarTable1.getInit(8);
/*  469: 516 */     while ((localVarItem = localVarTable1.getNext()) != null) {
/*  470: 517 */       localPrintWriter1.println(localStringBuffer + localVarItem.name + " = (" + localVarItem.type + ") " + ReductionType.reducerName(localVarItem.red, localVarItem.name) + ";");
/*  471:     */     }
/*  472: 520 */     localPrintWriter1.println(localStringBuffer + "// output to _rd_ copy");
/*  473: 521 */     localPrintWriter1.println(localStringBuffer + "if (jomp.runtime.OMP.getThreadNum(__omp_me) == 0) {");
/*  474: 522 */     localVarTable1.getInit(8);
/*  475: 523 */     while ((localVarItem = localVarTable1.getNext()) != null) {
/*  476: 524 */       localPrintWriter1.println(localStringBuffer + "  _rd_" + localVarItem.name + " = " + localVarItem.name + ";");
/*  477:     */     }
/*  478: 525 */     localPrintWriter1.println(localStringBuffer + "}");
/*  479:     */     
/*  480:     */ 
/*  481: 528 */     localPrintWriter1.println("  }");
/*  482:     */     
/*  483:     */ 
/*  484:     */ 
/*  485: 532 */     localPrintWriter1.println("}");
/*  486: 533 */     this.isMeDefined = bool;
/*  487:     */     
/*  488: 535 */     localPrintWriter1.println(str2);
/*  489: 536 */     return paramObject;
/*  490:     */   }
/*  491:     */   
/*  492:     */   public Object visit(ASTOMPMasterDirective paramASTOMPMasterDirective, Object paramObject)
/*  493:     */   {
/*  494: 546 */     StringBuffer localStringBuffer = new StringBuffer("");
/*  495: 547 */     for (int i = 6; i < paramASTOMPMasterDirective.getFirstToken().beginColumn; i++) {
/*  496: 548 */       localStringBuffer.append(" ");
/*  497:     */     }
/*  498: 551 */     this.out.println("");
/*  499: 552 */     this.out.println(localStringBuffer + "// OMP MASTER BLOCK BEGINS");
/*  500: 553 */     boolean bool = this.isMeDefined;
/*  501: 554 */     if (!this.isMeDefined)
/*  502:     */     {
/*  503: 555 */       this.out.println(localStringBuffer + "int __omp_me = jomp.runtime.OMP.getAbsoluteID();");
/*  504: 556 */       this.isMeDefined = true;
/*  505:     */     }
/*  506: 558 */     this.out.println(localStringBuffer + "if(jomp.runtime.OMP.getThreadNum(__omp_me) == 0)");
/*  507: 559 */     this.out.println(localStringBuffer + "// OMP USER CODE BEGINS");
/*  508: 560 */     paramObject = print((SimpleNode)paramASTOMPMasterDirective.jjtGetChild(paramASTOMPMasterDirective.jjtGetNumChildren() - 1), paramObject);
/*  509: 561 */     this.out.println("");
/*  510: 562 */     this.out.println(localStringBuffer + "// OMP USER CODE ENDS");
/*  511: 563 */     this.isMeDefined = bool;
/*  512: 564 */     this.out.println(localStringBuffer + "// OMP MASTER BLOCK ENDS");
/*  513: 565 */     return paramObject;
/*  514:     */   }
/*  515:     */   
/*  516:     */   public Object visit(ASTOMPSingleDirective paramASTOMPSingleDirective, Object paramObject)
/*  517:     */   {
/*  518: 570 */     int i = 0;
/*  519: 571 */     VarTable localVarTable = new VarTable();
/*  520:     */     
/*  521:     */ 
/*  522: 574 */     ASTOMPClauseList localASTOMPClauseList = (ASTOMPClauseList)paramASTOMPSingleDirective.jjtGetChild(0);
/*  523: 575 */     for (int j = 0; j < localASTOMPClauseList.jjtGetNumChildren(); j++) {
/*  524: 576 */       switch (((SimpleNode)localASTOMPClauseList.jjtGetChild(j).jjtGetChild(0)).id)
/*  525:     */       {
/*  526:     */       case 107: 
/*  527: 578 */         i = 1;
/*  528: 579 */         break;
/*  529:     */       case 102: 
/*  530: 581 */         localVarTable.addNameList((ASTVarNameList)localASTOMPClauseList.jjtGetChild(j).jjtGetChild(0).jjtGetChild(0), 1, 0, this.table);
/*  531: 582 */         break;
/*  532:     */       case 103: 
/*  533: 584 */         localVarTable.addNameList((ASTVarNameList)localASTOMPClauseList.jjtGetChild(j).jjtGetChild(0).jjtGetChild(0), 2, 0, this.table);
/*  534: 585 */         break;
/*  535:     */       default: 
/*  536: 587 */         System.err.println("Warning: meaningless clause " + ((SimpleNode)localASTOMPClauseList.jjtGetChild(j)).id + " with master - ignored");
/*  537:     */       }
/*  538:     */     }
/*  539: 593 */     StringBuffer localStringBuffer = new StringBuffer("");
/*  540: 594 */     for (int k = 6; k < paramASTOMPSingleDirective.getFirstToken().beginColumn; k++) {
/*  541: 595 */       localStringBuffer.append(" ");
/*  542:     */     }
/*  543: 598 */     this.out.println("");
/*  544: 599 */     boolean bool = this.isMeDefined;
/*  545: 600 */     if (!this.isMeDefined)
/*  546:     */     {
/*  547: 601 */       this.out.println(localStringBuffer + "int __omp_me = jomp.runtime.OMP.getAbsoluteID();");
/*  548: 602 */       this.isMeDefined = true;
/*  549:     */     }
/*  550: 604 */     this.out.println(localStringBuffer + "{ // OMP SINGLE BLOCK BEGINS");
/*  551: 605 */     this.out.println(localStringBuffer + "if(jomp.runtime.OMP.getTicket(__omp_me) == 0) {");
/*  552:     */     
/*  553:     */ 
/*  554: 608 */     this.out.println(localStringBuffer + "// copy of firstprivate variables, initialized");
/*  555: 609 */     localVarTable.getInit(2);
/*  556:     */     VarItem localVarItem;
/*  557: 610 */     while ((localVarItem = localVarTable.getNext()) != null) {
/*  558: 611 */       this.out.println(localStringBuffer + localVarItem.type + " _cp_" + localVarItem.name + " = " + localVarItem.name + ";");
/*  559:     */     }
/*  560: 615 */     this.out.println(localStringBuffer + "{");
/*  561: 616 */     localStringBuffer = localStringBuffer.append("  ");
/*  562:     */     
/*  563:     */ 
/*  564: 619 */     this.out.println(localStringBuffer + "// firstprivate variables + init");
/*  565: 620 */     localVarTable.getInit(2);
/*  566: 621 */     while ((localVarItem = localVarTable.getNext()) != null)
/*  567:     */     {
/*  568: 622 */       this.out.print(localStringBuffer + localVarItem.type + "  " + localVarItem.name + " = ");
/*  569: 623 */       this.out.print("(" + localVarItem.type + ")" + " _cp_" + localVarItem.name);
/*  570: 624 */       if (!isPrimitiveType(localVarItem.type)) {
/*  571: 625 */         this.out.print(".clone()");
/*  572:     */       }
/*  573: 626 */       this.out.println(";");
/*  574:     */     }
/*  575: 630 */     this.out.println(localStringBuffer + "// private variables");
/*  576: 631 */     localVarTable.getInit(1);
/*  577: 632 */     while ((localVarItem = localVarTable.getNext()) != null)
/*  578:     */     {
/*  579: 633 */       this.out.print(localStringBuffer + localVarItem.type + " " + localVarItem.name);
/*  580: 634 */       if ((!isPrimitiveType(localVarItem.type)) && (!isArray(localVarItem.type))) {
/*  581: 636 */         this.out.print(" = new " + localVarItem.type + "()");
/*  582:     */       }
/*  583: 637 */       this.out.println(";");
/*  584:     */     }
/*  585: 640 */     this.out.println(localStringBuffer + " // OMP USER CODE BEGINS");
/*  586: 641 */     paramObject = print((SimpleNode)paramASTOMPSingleDirective.jjtGetChild(paramASTOMPSingleDirective.jjtGetNumChildren() - 1), paramObject);
/*  587: 642 */     this.out.println("");
/*  588: 643 */     this.out.println(localStringBuffer + " // OMP USER CODE ENDS");
/*  589:     */     
/*  590: 645 */     localStringBuffer.setLength(localStringBuffer.length() - 2);
/*  591: 646 */     this.out.println(localStringBuffer + "}");
/*  592:     */     
/*  593:     */ 
/*  594:     */ 
/*  595:     */ 
/*  596: 651 */     this.out.println(localStringBuffer + "}");
/*  597: 652 */     this.out.println(localStringBuffer + "jomp.runtime.OMP.resetTicket(__omp_me);");
/*  598: 653 */     if (i == 0) {
/*  599: 654 */       this.out.println(localStringBuffer + "jomp.runtime.OMP.doBarrier(__omp_me);");
/*  600:     */     }
/*  601: 656 */     this.out.println(localStringBuffer + "} // OMP SINGLE BLOCK ENDS");
/*  602: 657 */     this.isMeDefined = bool;
/*  603: 658 */     return paramObject;
/*  604:     */   }
/*  605:     */   
/*  606:     */   public Object visit(ASTOMPForDirective paramASTOMPForDirective, Object paramObject)
/*  607:     */   {
/*  608: 663 */     return visit(paramASTOMPForDirective, paramObject, false);
/*  609:     */   }
/*  610:     */   
/*  611:     */   public Object visit(ASTOMPForDirective paramASTOMPForDirective, Object paramObject, boolean paramBoolean)
/*  612:     */   {
/*  613: 668 */     int i = 0;
/*  614: 669 */     int j = 0;
/*  615: 670 */     int k = 0;
/*  616: 671 */     VarTable localVarTable = new VarTable();
/*  617:     */     
/*  618: 673 */     ASTExpression localASTExpression = null;
/*  619: 674 */     int m = Jomp.Options.schedMode;
/*  620:     */     
/*  621: 676 */     ASTOMPClauseList localASTOMPClauseList = (ASTOMPClauseList)paramASTOMPForDirective.jjtGetChild(0);
/*  622: 677 */     for (int n = 0; n < localASTOMPClauseList.jjtGetNumChildren(); n++) {
/*  623: 678 */       switch (((SimpleNode)localASTOMPClauseList.jjtGetChild(n).jjtGetChild(0)).id)
/*  624:     */       {
/*  625:     */       case 107: 
/*  626: 680 */         if (paramBoolean) {
/*  627: 681 */           System.err.println("Warning - can't use nowait clause with parallel for!");
/*  628:     */         } else {
/*  629: 683 */           i = 1;
/*  630:     */         }
/*  631: 684 */         break;
/*  632:     */       case 110: 
/*  633: 686 */         j = 1;
/*  634: 687 */         break;
/*  635:     */       case 109: 
/*  636: 689 */         localObject1 = (ASTOMPScheduleClause)localASTOMPClauseList.jjtGetChild(n).jjtGetChild(0);
/*  637: 690 */         m = ((SimpleNode)localObject1).getFirstToken().next.next.kind;
/*  638: 691 */         if (((SimpleNode)localObject1).jjtGetNumChildren() > 0)
/*  639:     */         {
/*  640: 692 */           k = 1;
/*  641: 693 */           localASTExpression = (ASTExpression)((SimpleNode)localObject1).jjtGetChild(0);
/*  642:     */         }
/*  643:     */         break;
/*  644:     */       case 111: 
/*  645: 697 */         localObject2 = (ASTOMPReductionClause)localASTOMPClauseList.jjtGetChild(n).jjtGetChild(0);
/*  646: 698 */         i1 = ReductionType.getTypeByToken(((SimpleNode)((SimpleNode)localObject2).jjtGetChild(0)).getFirstToken().kind);
/*  647: 699 */         localVarTable.addNameList((ASTVarNameList)((SimpleNode)localObject2).jjtGetChild(1), 8, i1, this.table);
/*  648: 700 */         break;
/*  649:     */       case 102: 
/*  650: 702 */         if (!paramBoolean) {
/*  651: 703 */           localVarTable.addNameList((ASTVarNameList)localASTOMPClauseList.jjtGetChild(n).jjtGetChild(0).jjtGetChild(0), 1, 0, this.table);
/*  652:     */         }
/*  653:     */         break;
/*  654:     */       case 103: 
/*  655: 707 */         if (!paramBoolean) {
/*  656: 708 */           localVarTable.addNameList((ASTVarNameList)localASTOMPClauseList.jjtGetChild(n).jjtGetChild(0).jjtGetChild(0), 2, 0, this.table);
/*  657:     */         }
/*  658:     */         break;
/*  659:     */       case 104: 
/*  660: 712 */         localVarTable.addNameList((ASTVarNameList)localASTOMPClauseList.jjtGetChild(n).jjtGetChild(0).jjtGetChild(0), 4, 0, this.table);
/*  661: 713 */         break;
/*  662:     */       case 105: 
/*  663: 715 */         if (!paramBoolean) {
/*  664: 716 */           Jomp.message(2, "Warning: shared clause has no meaning with for directive!");
/*  665:     */         }
/*  666:     */         break;
/*  667:     */       case 108: 
/*  668: 720 */         if (!paramBoolean) {
/*  669: 721 */           Jomp.message(2, "Warning: if clause has no meaning with for directive!");
/*  670:     */         }
/*  671:     */         break;
/*  672:     */       case 106: 
/*  673: 725 */         if (!paramBoolean) {
/*  674: 726 */           Jomp.message(2, "Warning: default clause has no meaning with for directive!");
/*  675:     */         }
/*  676:     */         break;
/*  677:     */       default: 
/*  678: 730 */         Jomp.message(6, "Warning: meaningless clause " + ((SimpleNode)localASTOMPClauseList.jjtGetChild(n)).id + " with master - ignored");
/*  679:     */       }
/*  680:     */     }
/*  681: 735 */     Object localObject1 = (ASTOMPForStatement)paramASTOMPForDirective.jjtGetChild(1);
/*  682:     */     
/*  683:     */ 
/*  684:     */ 
/*  685: 739 */     Object localObject2 = new StringBuffer("");
/*  686: 740 */     for (int i1 = 6; i1 < paramASTOMPForDirective.getFirstToken().beginColumn; i1++) {
/*  687: 741 */       ((StringBuffer)localObject2).append(" ");
/*  688:     */     }
/*  689: 744 */     String str1 = getUniqueName("ChunkData");
/*  690: 745 */     String str2 = getUniqueName("WholeData");
/*  691:     */     
/*  692: 747 */     this.out.println("");
/*  693: 748 */     this.out.println(localObject2 + "{ // OMP FOR BLOCK BEGINS");
/*  694:     */     
/*  695:     */ 
/*  696: 751 */     this.out.println(localObject2 + "// copy of firstprivate variables, initialized");
/*  697: 752 */     localVarTable.getInit(2);
/*  698:     */     VarItem localVarItem1;
/*  699: 753 */     while ((localVarItem1 = localVarTable.getNext()) != null) {
/*  700: 754 */       this.out.println(localObject2 + localVarItem1.type + " _cp_" + localVarItem1.name + " = " + localVarItem1.name + ";");
/*  701:     */     }
/*  702: 757 */     this.out.println(localObject2 + "// copy of lastprivate variables");
/*  703: 758 */     localVarTable.getInit(4);
/*  704: 759 */     while ((localVarItem1 = localVarTable.getNext()) != null) {
/*  705: 760 */       this.out.print(localObject2 + localVarItem1.type + " _cp_" + localVarItem1.name + ";");
/*  706:     */     }
/*  707: 763 */     this.out.println(localObject2 + "// variables to hold result of reduction");
/*  708: 764 */     localVarTable.getInit(8);
/*  709: 765 */     while ((localVarItem1 = localVarTable.getNext()) != null) {
/*  710: 766 */       this.out.println(localObject2 + localVarItem1.type + " _cp_" + localVarItem1.name + ";");
/*  711:     */     }
/*  712: 769 */     this.out.println(localObject2 + "boolean amLast=false;");
/*  713:     */     
/*  714: 771 */     boolean bool1 = this.isMeDefined;
/*  715: 772 */     if (!this.isMeDefined)
/*  716:     */     {
/*  717: 773 */       this.out.println(localObject2 + "int __omp_me = jomp.runtime.OMP.getAbsoluteID();");
/*  718: 774 */       this.isMeDefined = true;
/*  719:     */     }
/*  720: 779 */     this.out.println(localObject2 + "{");
/*  721: 780 */     localObject2 = ((StringBuffer)localObject2).append("  ");
/*  722:     */     
/*  723:     */ 
/*  724: 783 */     this.out.println(localObject2 + "// firstprivate variables + init");
/*  725: 784 */     localVarTable.getInit(2);
/*  726: 785 */     while ((localVarItem1 = localVarTable.getNext()) != null)
/*  727:     */     {
/*  728: 786 */       this.out.print(localObject2 + localVarItem1.type + "  " + localVarItem1.name + " = ");
/*  729: 787 */       this.out.print("(" + localVarItem1.type + ")" + " _cp_" + localVarItem1.name);
/*  730: 788 */       if (!isPrimitiveType(localVarItem1.type)) {
/*  731: 789 */         this.out.print(".clone()");
/*  732:     */       }
/*  733: 790 */       this.out.println(";");
/*  734:     */     }
/*  735: 794 */     this.out.println(localObject2 + "// [last]private variables");
/*  736: 795 */     localVarTable.getInit(5);
/*  737: 796 */     while ((localVarItem1 = localVarTable.getNext()) != null)
/*  738:     */     {
/*  739: 797 */       this.out.print(localObject2 + localVarItem1.type + " " + localVarItem1.name);
/*  740: 798 */       if ((!isPrimitiveType(localVarItem1.type)) && (!isArray(localVarItem1.type))) {
/*  741: 800 */         this.out.print(" = new " + localVarItem1.type + "()");
/*  742:     */       }
/*  743: 801 */       this.out.println(";");
/*  744:     */     }
/*  745: 805 */     this.out.println(localObject2 + "// reduction variables + init to default");
/*  746: 806 */     localVarTable.getInit(8);
/*  747: 807 */     while ((localVarItem1 = localVarTable.getNext()) != null) {
/*  748: 808 */       this.out.println(localObject2 + localVarItem1.type + "  " + localVarItem1.name + " = " + ReductionType.opDefault(localVarItem1.red) + ";");
/*  749:     */     }
/*  750: 810 */     this.out.println(localObject2 + "// -------------------------------------");
/*  751:     */     
/*  752:     */ 
/*  753: 813 */     this.out.println(localObject2 + "jomp.runtime.LoopData " + str2 + " = new jomp.runtime.LoopData();");
/*  754: 814 */     this.out.println(localObject2 + "jomp.runtime.LoopData " + str1 + " = new jomp.runtime.LoopData();");
/*  755:     */     
/*  756:     */ 
/*  757:     */ 
/*  758: 818 */     int i2 = 1;
/*  759:     */     
/*  760:     */ 
/*  761: 821 */     this.out.print(localObject2 + str2 + ".start = (long)(");
/*  762: 822 */     paramObject = print((SimpleNode)((SimpleNode)localObject1).jjtGetChild(1), paramObject);
/*  763: 823 */     this.out.println(");");
/*  764:     */     
/*  765: 825 */     this.out.print(localObject2 + str2 + ".stop = (long)(");
/*  766: 826 */     paramObject = print((SimpleNode)((SimpleNode)localObject1).jjtGetChild(4), paramObject);
/*  767: 827 */     this.out.print(")");
/*  768: 829 */     switch (((SimpleNode)((SimpleNode)localObject1).jjtGetChild(3)).getFirstToken().kind)
/*  769:     */     {
/*  770:     */     case 111: 
/*  771: 831 */       i2 = 1;
/*  772: 832 */       this.out.print("+1");
/*  773: 833 */       break;
/*  774:     */     case 112: 
/*  775: 835 */       i2 = 0;
/*  776: 836 */       this.out.print("-1");
/*  777: 837 */       break;
/*  778:     */     case 105: 
/*  779: 839 */       i2 = 1;
/*  780: 840 */       break;
/*  781:     */     case 104: 
/*  782: 842 */       i2 = 0;
/*  783:     */     }
/*  784: 845 */     this.out.println(";");
/*  785:     */     
/*  786:     */ 
/*  787: 848 */     this.out.print(localObject2 + str2 + ".step = (long)(");
/*  788: 849 */     switch (((SimpleNode)((SimpleNode)localObject1).jjtGetChild(5)).getFirstToken().kind)
/*  789:     */     {
/*  790:     */     case 116: 
/*  791: 851 */       this.out.print("1"); break;
/*  792:     */     case 117: 
/*  793: 852 */       this.out.print("-1"); break;
/*  794:     */     default: 
/*  795: 854 */       switch (((SimpleNode)((SimpleNode)localObject1).jjtGetChild(5)).getFirstToken().next.kind)
/*  796:     */       {
/*  797:     */       case 116: 
/*  798: 856 */         this.out.print("1"); break;
/*  799:     */       case 117: 
/*  800: 857 */         this.out.print("-1"); break;
/*  801:     */       case 129: 
/*  802: 860 */         print((SimpleNode)((SimpleNode)localObject1).jjtGetChild(5).jjtGetChild(1), paramObject);
/*  803: 861 */         break;
/*  804:     */       case 130: 
/*  805: 863 */         this.out.print("-(");
/*  806: 864 */         print((SimpleNode)((SimpleNode)localObject1).jjtGetChild(5).jjtGetChild(1), paramObject);
/*  807: 865 */         this.out.print(")");
/*  808: 866 */         break;
/*  809:     */       case 103: 
/*  810: 869 */         SimpleNode localSimpleNode1 = (SimpleNode)((SimpleNode)localObject1).jjtGetChild(5).jjtGetChild(1);
/*  811: 870 */         SimpleNode localSimpleNode2 = (SimpleNode)localSimpleNode1.jjtGetChild(1);
/*  812: 871 */         String str3 = ((SimpleNode)localSimpleNode1.jjtGetChild(0)).getFirstToken().toString();
/*  813: 873 */         if (!str3.equals(((SimpleNode)((SimpleNode)localObject1).jjtGetChild(5).jjtGetChild(0)).getFirstToken().toString())) {
/*  814: 874 */           System.err.println("In FOR - update - used variables do not match!");
/*  815:     */         }
/*  816: 875 */         switch (localSimpleNode1.getFirstToken().next.kind)
/*  817:     */         {
/*  818:     */         case 118: 
/*  819: 877 */           print(localSimpleNode2, paramObject);
/*  820: 878 */           break;
/*  821:     */         case 119: 
/*  822: 880 */           this.out.print("-(");
/*  823: 881 */           print(localSimpleNode2, paramObject);
/*  824: 882 */           this.out.print(")");
/*  825: 883 */           break;
/*  826:     */         default: 
/*  827: 885 */           System.err.println("Panic parsing FOR - 1!");
/*  828:     */         }
/*  829: 887 */         break;
/*  830:     */       default: 
/*  831: 889 */         System.err.println("Panic parsing FOR - 2 !");
/*  832:     */       }
/*  833:     */       break;
/*  834:     */     }
/*  835: 892 */     this.out.println(");");
/*  836: 894 */     if (localASTExpression == null)
/*  837:     */     {
/*  838: 895 */       switch (m)
/*  839:     */       {
/*  840:     */       case 50: 
/*  841: 897 */         this.out.println(localObject2 + "jomp.runtime.OMP.setChunkStatic(" + str2 + ");");
/*  842: 898 */         break;
/*  843:     */       case 79: 
/*  844:     */       case 80: 
/*  845: 901 */         this.out.println(localObject2 + str2 + ".chunkSize = 1;");
/*  846: 902 */         break;
/*  847:     */       case 81: 
/*  848: 904 */         this.out.println(localObject2 + "jomp.runtime.OMP.setChunkRuntime(" + str2 + ");");
/*  849: 905 */         break;
/*  850:     */       default: 
/*  851: 906 */         System.err.println("Unknown scheduling policy!"); break;
/*  852:     */       }
/*  853:     */     }
/*  854:     */     else
/*  855:     */     {
/*  856: 909 */       this.out.print(localObject2 + str2 + ".chunkSize = (long)(");
/*  857: 910 */       paramObject = print(localASTExpression, paramObject);
/*  858: 911 */       this.out.println(");");
/*  859:     */     }
/*  860: 918 */     this.table.addScope();
/*  861:     */     String str4;
/*  862:     */     String str5;
/*  863:     */     SymbolTable.Symbol localSymbol;
/*  864:     */     String str6;
/*  865: 921 */     switch (((SimpleNode)localObject1).getFirstToken().next.next.kind)
/*  866:     */     {
/*  867:     */     case 16: 
/*  868:     */     case 38: 
/*  869:     */     case 40: 
/*  870:     */     case 49: 
/*  871: 926 */       str4 = ((SimpleNode)localObject1).getFirstToken().next.next.toString();
/*  872: 927 */       str5 = ((SimpleNode)localObject1).getFirstToken().next.next.next.toString();
/*  873: 928 */       localSymbol = this.table.addSymbol(str5);
/*  874: 929 */       localSymbol.sig = str4;
/*  875: 930 */       str6 = str4;
/*  876: 931 */       break;
/*  877:     */     default: 
/*  878: 933 */       str5 = ((SimpleNode)localObject1).getFirstToken().next.next.toString();
/*  879: 934 */       localSymbol = this.table.findSymbol(str5);
/*  880: 935 */       if (localSymbol == null) {
/*  881: 936 */         System.err.println("Variable in For statement must be local!");
/*  882:     */       }
/*  883: 937 */       str4 = localSymbol.sig;
/*  884:     */       
/*  885:     */ 
/*  886:     */ 
/*  887: 941 */       str6 = "";
/*  888: 943 */       if (this.pvt != null)
/*  889:     */       {
/*  890: 944 */         i3 = this.pvt.search(str5);
/*  891: 945 */         if (i3 != -1)
/*  892:     */         {
/*  893: 946 */           VarItem localVarItem2 = (VarItem)this.pvt.get(i3);
/*  894: 947 */           if (localVarItem2.kind == 16) {
/*  895: 948 */             str6 = str4;
/*  896:     */           }
/*  897:     */         }
/*  898:     */       }
/*  899:     */       break;
/*  900:     */     }
/*  901: 955 */     int i3 = 0;
/*  902: 956 */     String str7 = null;
/*  903: 957 */     String str8 = null;
/*  904:     */     boolean bool2;
/*  905: 958 */     if (j != 0)
/*  906:     */     {
/*  907: 959 */       this.out.println(localObject2 + "jomp.runtime.OMP.resetOrderer(__omp_me, " + str2 + ".start);");
/*  908: 960 */       bool2 = this.isInOrderedLoop;
/*  909: 961 */       str7 = this.loopVarName;
/*  910: 962 */       str8 = str2;
/*  911: 963 */       this.isInOrderedLoop = true;
/*  912: 964 */       this.loopVarName = str5;
/*  913: 965 */       this.loopWholeDataName = str2;
/*  914:     */     }
/*  915: 968 */     String str9 = i2 != 0 ? "<" : ">";
/*  916: 974 */     switch (m)
/*  917:     */     {
/*  918:     */     case 50: 
/*  919: 976 */       this.out.print(localObject2 + "while(!" + str1 + ".isLast && ");
/*  920: 977 */       this.out.println("jomp.runtime.OMP.getLoopStatic(__omp_me, " + str2 + ", " + str1 + ")) {");
/*  921: 978 */       break;
/*  922:     */     case 79: 
/*  923: 980 */       this.out.println(localObject2 + "jomp.runtime.OMP.initTicket(__omp_me, " + str2 + ");");
/*  924: 981 */       this.out.print(localObject2 + "while(!" + str1 + ".isLast && ");
/*  925: 982 */       this.out.println("jomp.runtime.OMP.getLoopDynamic(__omp_me, " + str2 + ", " + str1 + ")) {");
/*  926: 983 */       break;
/*  927:     */     case 80: 
/*  928: 985 */       this.out.print(localObject2 + "while(!" + str1 + ".isLast && ");
/*  929: 986 */       this.out.println("jomp.runtime.OMP.getLoopGuided(__omp_me, " + str2 + ", " + str1 + ")) {");
/*  930: 987 */       break;
/*  931:     */     case 81: 
/*  932: 989 */       this.out.println(localObject2 + "if (jomp.runtime.OMP.isDynamic())");
/*  933: 990 */       this.out.println(localObject2 + "  jomp.runtime.OMP.initTicket(__omp_me, " + str2 + ");");
/*  934: 991 */       this.out.print(localObject2 + "while(!" + str1 + ".isLast && ");
/*  935: 992 */       this.out.println("jomp.runtime.OMP.getLoopRuntime(__omp_me, " + str2 + ", " + str1 + ")) {");
/*  936: 993 */       break;
/*  937:     */     default: 
/*  938: 994 */       System.err.println("Scheduling option not currently supported!");
/*  939:     */     }
/*  940: 997 */     String str10 = getUniqueName();
/*  941: 998 */     if ((m == 50) || (m == 81))
/*  942:     */     {
/*  943: 999 */       this.out.println(localObject2 + "for(;;) {");
/*  944:1000 */       this.out.println(localObject2 + "  if(" + str2 + ".step > 0) {");
/*  945:1001 */       this.out.println(localObject2 + "     if(" + str1 + ".stop > " + str2 + ".stop) " + str1 + ".stop = " + str2 + ".stop;");
/*  946:1002 */       this.out.println(localObject2 + "     if(" + str1 + ".start >= " + str2 + ".stop) break;");
/*  947:1003 */       this.out.println(localObject2 + "  } else {");
/*  948:1004 */       this.out.println(localObject2 + "     if(" + str1 + ".stop < " + str2 + ".stop) " + str1 + ".stop = " + str2 + ".stop;");
/*  949:1005 */       this.out.println(localObject2 + "     if(" + str1 + ".start > " + str2 + ".stop) break;");
/*  950:1006 */       this.out.println(localObject2 + "  }");
/*  951:     */     }
/*  952:1009 */     if (Jomp.Options.debugLoops) {
/*  953:1010 */       this.out.println(localObject2 + "System.err.println(\"Process \" + jomp.runtime.OMP.getThreadNum() + \" executing iterations \" + " + str1 + ".start + \" to \" + (" + str1 + ".stop - 1) + \" with step \" + " + str1 + ".step);");
/*  954:     */     }
/*  955:1013 */     this.out.println(localObject2 + "  for(" + str6 + " " + str5 + " = (" + str4 + ")" + str1 + ".start; " + str5 + " " + str9 + " " + str1 + ".stop; " + str5 + " += " + str1 + ".step) {");
/*  956:     */     
/*  957:1015 */     this.out.println(localObject2 + "    // OMP USER CODE BEGINS");
/*  958:1016 */     paramObject = print((SimpleNode)paramASTOMPForDirective.jjtGetChild(1).jjtGetChild(6), paramObject);
/*  959:1017 */     this.out.println("");
/*  960:1018 */     this.out.println(localObject2 + "    // OMP USER CODE ENDS");
/*  961:     */     
/*  962:     */ 
/*  963:1021 */     this.out.println(localObject2 + "    if (" + str5 + " == (" + str2 + ".stop-1)) amLast = true;");
/*  964:     */     
/*  965:1023 */     this.out.println(localObject2 + "  } // of for ");
/*  966:1025 */     if ((m == 50) || (m == 81))
/*  967:     */     {
/*  968:1026 */       this.out.println(localObject2 + "  if(" + str1 + ".startStep == 0)");
/*  969:1027 */       this.out.println(localObject2 + "    break;");
/*  970:1028 */       this.out.println(localObject2 + "  " + str1 + ".start += " + str1 + ".startStep;");
/*  971:1029 */       this.out.println(localObject2 + "  " + str1 + ".stop += " + str1 + ".startStep;");
/*  972:1030 */       this.out.println(localObject2 + "} // of for(;;)");
/*  973:     */     }
/*  974:1033 */     this.out.println(localObject2 + "} // of while");
/*  975:     */     
/*  976:     */ 
/*  977:     */ 
/*  978:     */ 
/*  979:1038 */     this.out.println(localObject2 + "// call reducer");
/*  980:1039 */     localVarTable.getInit(8);
/*  981:1040 */     while ((localVarItem1 = localVarTable.getNext()) != null) {
/*  982:1041 */       this.out.println(localObject2 + "_cp_" + localVarItem1.name + " = (" + localVarItem1.type + ") " + ReductionType.reducerName(localVarItem1.red, localVarItem1.name) + ";");
/*  983:     */     }
/*  984:1043 */     if (m != 50) {
/*  985:1044 */       this.out.println(localObject2 + "jomp.runtime.OMP.resetTicket(__omp_me);");
/*  986:     */     }
/*  987:1047 */     if (i == 0) {
/*  988:1048 */       this.out.println(localObject2 + "jomp.runtime.OMP.doBarrier(__omp_me);");
/*  989:     */     }
/*  990:1049 */     this.isMeDefined = bool1;
/*  991:     */     
/*  992:     */ 
/*  993:1052 */     this.out.println(localObject2 + "// copy lastprivate variables out");
/*  994:1053 */     this.out.println(localObject2 + "if (amLast) {");
/*  995:1054 */     localVarTable.getInit(4);
/*  996:1055 */     while ((localVarItem1 = localVarTable.getNext()) != null) {
/*  997:1056 */       this.out.println(localObject2 + "  _cp_" + localVarItem1.name + " = " + localVarItem1.name + ";");
/*  998:     */     }
/*  999:1057 */     this.out.println(localObject2 + "}");
/* 1000:     */     
/* 1001:1059 */     ((StringBuffer)localObject2).setLength(((StringBuffer)localObject2).length() - 2);
/* 1002:1060 */     this.out.println(localObject2 + "}");
/* 1003:     */     
/* 1004:     */ 
/* 1005:     */ 
/* 1006:     */ 
/* 1007:1065 */     this.out.println(localObject2 + "// set global from lastprivate variables");
/* 1008:1066 */     this.out.println(localObject2 + "if (amLast) {");
/* 1009:1067 */     localVarTable.getInit(4);
/* 1010:1068 */     while ((localVarItem1 = localVarTable.getNext()) != null) {
/* 1011:1069 */       this.out.println(localObject2 + "  " + localVarItem1.name + " = _cp_" + localVarItem1.name + ";");
/* 1012:     */     }
/* 1013:1070 */     this.out.println(localObject2 + "}");
/* 1014:     */     
/* 1015:     */ 
/* 1016:1073 */     this.out.println(localObject2 + "// set global from reduction variables");
/* 1017:1074 */     this.out.println(localObject2 + "if (jomp.runtime.OMP.getThreadNum(__omp_me) == 0) {");
/* 1018:1075 */     localVarTable.getInit(8);
/* 1019:1076 */     while ((localVarItem1 = localVarTable.getNext()) != null) {
/* 1020:1077 */       this.out.println(localObject2 + "  " + localVarItem1.name + ReductionType.opName(localVarItem1.red) + "= _cp_" + localVarItem1.name + ";");
/* 1021:     */     }
/* 1022:1078 */     this.out.println(localObject2 + "}");
/* 1023:1081 */     if (j != 0)
/* 1024:     */     {
/* 1025:1082 */       this.isInOrderedLoop = bool2;
/* 1026:1083 */       this.loopVarName = str7;
/* 1027:1084 */       this.loopWholeDataName = str8;
/* 1028:     */     }
/* 1029:1087 */     this.table.killScope();
/* 1030:     */     
/* 1031:1089 */     this.out.println(localObject2 + "} // OMP FOR BLOCK ENDS");
/* 1032:1090 */     return paramObject;
/* 1033:     */   }
/* 1034:     */   
/* 1035:     */   public Object visit(ASTOMPSectionsDirective paramASTOMPSectionsDirective, Object paramObject)
/* 1036:     */   {
/* 1037:1095 */     return visit(paramASTOMPSectionsDirective, paramObject, false);
/* 1038:     */   }
/* 1039:     */   
/* 1040:     */   public Object visit(ASTOMPSectionsDirective paramASTOMPSectionsDirective, Object paramObject, boolean paramBoolean)
/* 1041:     */   {
/* 1042:1099 */     int i = 0;
/* 1043:1100 */     VarTable localVarTable = new VarTable();
/* 1044:     */     
/* 1045:     */ 
/* 1046:1103 */     ASTOMPClauseList localASTOMPClauseList = (ASTOMPClauseList)paramASTOMPSectionsDirective.jjtGetChild(0);
/* 1047:1104 */     for (int j = 0; j < localASTOMPClauseList.jjtGetNumChildren(); j++) {
/* 1048:1105 */       switch (((SimpleNode)localASTOMPClauseList.jjtGetChild(j).jjtGetChild(0)).id)
/* 1049:     */       {
/* 1050:     */       case 107: 
/* 1051:1107 */         if (paramBoolean) {
/* 1052:1108 */           System.err.println("Warning - can't use nowait clause with parallel sections!");
/* 1053:     */         } else {
/* 1054:1110 */           i = 1;
/* 1055:     */         }
/* 1056:1111 */         break;
/* 1057:     */       case 111: 
/* 1058:1113 */         localObject = (ASTOMPReductionClause)localASTOMPClauseList.jjtGetChild(j).jjtGetChild(0);
/* 1059:1114 */         k = ReductionType.getTypeByToken(((SimpleNode)((SimpleNode)localObject).jjtGetChild(0)).getFirstToken().kind);
/* 1060:1115 */         localVarTable.addNameList((ASTVarNameList)((SimpleNode)localObject).jjtGetChild(1), 8, k, this.table);
/* 1061:1116 */         break;
/* 1062:     */       case 102: 
/* 1063:1118 */         if (!paramBoolean) {
/* 1064:1119 */           localVarTable.addNameList((ASTVarNameList)localASTOMPClauseList.jjtGetChild(j).jjtGetChild(0).jjtGetChild(0), 1, 0, this.table);
/* 1065:     */         }
/* 1066:     */         break;
/* 1067:     */       case 103: 
/* 1068:1123 */         if (!paramBoolean) {
/* 1069:1124 */           localVarTable.addNameList((ASTVarNameList)localASTOMPClauseList.jjtGetChild(j).jjtGetChild(0).jjtGetChild(0), 2, 0, this.table);
/* 1070:     */         }
/* 1071:     */         break;
/* 1072:     */       case 104: 
/* 1073:1128 */         localVarTable.addNameList((ASTVarNameList)localASTOMPClauseList.jjtGetChild(j).jjtGetChild(0).jjtGetChild(0), 4, 0, this.table);
/* 1074:1129 */         break;
/* 1075:     */       case 105: 
/* 1076:1131 */         if (!paramBoolean) {
/* 1077:1132 */           Jomp.message(2, "Warning: shared clause has no meaning with sections directive!");
/* 1078:     */         }
/* 1079:     */         break;
/* 1080:     */       case 108: 
/* 1081:1136 */         if (!paramBoolean) {
/* 1082:1137 */           Jomp.message(2, "Warning: if clause has no meaning with sections directive!");
/* 1083:     */         }
/* 1084:     */         break;
/* 1085:     */       case 106: 
/* 1086:1141 */         if (!paramBoolean) {
/* 1087:1142 */           Jomp.message(2, "Warning: default clause has no meaning with sections directive!");
/* 1088:     */         }
/* 1089:     */         break;
/* 1090:     */       case 109: 
/* 1091:     */       case 110: 
/* 1092:     */       default: 
/* 1093:1146 */         Jomp.message(6, "Warning: meaningless clause " + ((SimpleNode)localASTOMPClauseList.jjtGetChild(j)).id + " with master - ignored");
/* 1094:     */       }
/* 1095:     */     }
/* 1096:1152 */     Object localObject = new StringBuffer("");
/* 1097:1153 */     for (int k = 6; k < paramASTOMPSectionsDirective.getFirstToken().beginColumn; k++) {
/* 1098:1154 */       ((StringBuffer)localObject).append(" ");
/* 1099:     */     }
/* 1100:1157 */     String str = getUniqueName();
/* 1101:     */     
/* 1102:1159 */     this.out.println("");
/* 1103:1160 */     this.out.println(localObject + "{ // OMP SECTIONS BLOCK BEGINS");
/* 1104:     */     
/* 1105:     */ 
/* 1106:1163 */     this.out.println(localObject + "// copy of firstprivate variables, initialized");
/* 1107:1164 */     localVarTable.getInit(2);
/* 1108:     */     VarItem localVarItem;
/* 1109:1165 */     while ((localVarItem = localVarTable.getNext()) != null) {
/* 1110:1166 */       this.out.println(localObject + localVarItem.type + " _cp_" + localVarItem.name + " = " + localVarItem.name + ";");
/* 1111:     */     }
/* 1112:1169 */     this.out.println(localObject + "// copy of lastprivate variables");
/* 1113:1170 */     localVarTable.getInit(4);
/* 1114:1171 */     while ((localVarItem = localVarTable.getNext()) != null) {
/* 1115:1172 */       this.out.print(localObject + localVarItem.type + " _cp_" + localVarItem.name + ";");
/* 1116:     */     }
/* 1117:1175 */     this.out.println(localObject + "// variables to hold result of reduction");
/* 1118:1176 */     localVarTable.getInit(8);
/* 1119:1177 */     while ((localVarItem = localVarTable.getNext()) != null) {
/* 1120:1178 */       this.out.println(localObject + localVarItem.type + " _cp_" + localVarItem.name + ";");
/* 1121:     */     }
/* 1122:1181 */     this.out.println(localObject + "boolean amLast=false;");
/* 1123:     */     
/* 1124:1183 */     boolean bool = this.isMeDefined;
/* 1125:1184 */     if (!this.isMeDefined)
/* 1126:     */     {
/* 1127:1185 */       this.out.println(localObject + "int __omp_me = jomp.runtime.OMP.getAbsoluteID();");
/* 1128:1186 */       this.isMeDefined = true;
/* 1129:     */     }
/* 1130:1191 */     this.out.println(localObject + "{");
/* 1131:1192 */     localObject = ((StringBuffer)localObject).append("  ");
/* 1132:     */     
/* 1133:     */ 
/* 1134:1195 */     this.out.println(localObject + "// firstprivate variables + init");
/* 1135:1196 */     localVarTable.getInit(2);
/* 1136:1197 */     while ((localVarItem = localVarTable.getNext()) != null)
/* 1137:     */     {
/* 1138:1198 */       this.out.print(localObject + localVarItem.type + "  " + localVarItem.name + " = ");
/* 1139:1199 */       this.out.print("(" + localVarItem.type + ")" + " _cp_" + localVarItem.name);
/* 1140:1200 */       if (!isPrimitiveType(localVarItem.type)) {
/* 1141:1201 */         this.out.print(".clone()");
/* 1142:     */       }
/* 1143:1202 */       this.out.println(";");
/* 1144:     */     }
/* 1145:1206 */     this.out.println(localObject + "// [last]private variables");
/* 1146:1207 */     localVarTable.getInit(5);
/* 1147:1208 */     while ((localVarItem = localVarTable.getNext()) != null)
/* 1148:     */     {
/* 1149:1209 */       this.out.print(localObject + localVarItem.type + " " + localVarItem.name);
/* 1150:1210 */       if ((!isPrimitiveType(localVarItem.type)) && (!isArray(localVarItem.type))) {
/* 1151:1212 */         this.out.print(" = new " + localVarItem.type + "()");
/* 1152:     */       }
/* 1153:1213 */       this.out.println(";");
/* 1154:     */     }
/* 1155:1217 */     this.out.println(localObject + "// reduction variables + init to default");
/* 1156:1218 */     localVarTable.getInit(8);
/* 1157:1219 */     while ((localVarItem = localVarTable.getNext()) != null) {
/* 1158:1220 */       this.out.println(localObject + localVarItem.type + "  " + localVarItem.name + " = " + ReductionType.opDefault(localVarItem.red) + ";");
/* 1159:     */     }
/* 1160:1222 */     this.out.println(localObject + "// -------------------------------------");
/* 1161:     */     
/* 1162:1224 */     this.out.println(localObject + str + ": while(true) {");
/* 1163:1225 */     this.out.println(localObject + "switch((int)jomp.runtime.OMP.getTicket(__omp_me)) {");
/* 1164:     */     
/* 1165:     */ 
/* 1166:     */ 
/* 1167:1229 */     ASTOMPSectionsBlock localASTOMPSectionsBlock = (ASTOMPSectionsBlock)paramASTOMPSectionsDirective.jjtGetChild(paramASTOMPSectionsDirective.jjtGetNumChildren() - 1);
/* 1168:1231 */     for (int m = 0; m < localASTOMPSectionsBlock.jjtGetNumChildren(); m++)
/* 1169:     */     {
/* 1170:1232 */       this.out.println(localObject + "// OMP SECTION BLOCK " + m + " BEGINS");
/* 1171:1233 */       this.out.println(localObject + "  case " + m + ": {");
/* 1172:1234 */       this.out.println(localObject + "// OMP USER CODE BEGINS");
/* 1173:1235 */       paramObject = print((SimpleNode)localASTOMPSectionsBlock.jjtGetChild(m).jjtGetChild(0), paramObject);
/* 1174:1236 */       this.out.println("");
/* 1175:1237 */       this.out.println(localObject + "// OMP USER CODE ENDS");
/* 1176:1240 */       if (m + 1 == localASTOMPSectionsBlock.jjtGetNumChildren())
/* 1177:     */       {
/* 1178:1241 */         this.out.println(localObject + "amLast = true;");
/* 1179:1242 */         localVarTable.getInit(4);
/* 1180:1243 */         while ((localVarItem = localVarTable.getNext()) != null) {
/* 1181:1244 */           this.out.println(localObject + "_cp_" + localVarItem.name + " = " + localVarItem.name + ";");
/* 1182:     */         }
/* 1183:     */       }
/* 1184:1247 */       this.out.println(localObject + "  };  break;");
/* 1185:1248 */       this.out.println(localObject + "// OMP SECTION BLOCK " + m + " ENDS");
/* 1186:     */     }
/* 1187:1251 */     this.out.println("");
/* 1188:1252 */     this.out.println(localObject + "  default: break " + str + ";");
/* 1189:1253 */     this.out.println(localObject + "} // of switch");
/* 1190:1254 */     this.out.println(localObject + "} // of while");
/* 1191:     */     
/* 1192:     */ 
/* 1193:1257 */     this.out.println(localObject + "// call reducer");
/* 1194:1258 */     localVarTable.getInit(8);
/* 1195:1259 */     while ((localVarItem = localVarTable.getNext()) != null) {
/* 1196:1260 */       this.out.println(localObject + "_cp_" + localVarItem.name + " = (" + localVarItem.type + ") " + ReductionType.reducerName(localVarItem.red, localVarItem.name) + ";");
/* 1197:     */     }
/* 1198:1262 */     this.out.println(localObject + "jomp.runtime.OMP.resetTicket(__omp_me);");
/* 1199:1263 */     if (i == 0) {
/* 1200:1264 */       this.out.println(localObject + "jomp.runtime.OMP.doBarrier(__omp_me);");
/* 1201:     */     }
/* 1202:1265 */     this.isMeDefined = bool;
/* 1203:     */     
/* 1204:     */ 
/* 1205:1268 */     this.out.println(localObject + "// copy lastprivate variables out");
/* 1206:1269 */     this.out.println(localObject + "if (amLast) {");
/* 1207:1270 */     localVarTable.getInit(4);
/* 1208:1271 */     while ((localVarItem = localVarTable.getNext()) != null) {
/* 1209:1272 */       this.out.println(localObject + "  _cp_" + localVarItem.name + " = " + localVarItem.name + ";");
/* 1210:     */     }
/* 1211:1273 */     this.out.println(localObject + "}");
/* 1212:     */     
/* 1213:1275 */     ((StringBuffer)localObject).setLength(((StringBuffer)localObject).length() - 2);
/* 1214:1276 */     this.out.println(localObject + "}");
/* 1215:     */     
/* 1216:     */ 
/* 1217:     */ 
/* 1218:     */ 
/* 1219:1281 */     this.out.println(localObject + "// update lastprivate variables");
/* 1220:1282 */     this.out.println(localObject + "if (amLast) {");
/* 1221:1283 */     localVarTable.getInit(4);
/* 1222:1284 */     while ((localVarItem = localVarTable.getNext()) != null) {
/* 1223:1285 */       this.out.println(localObject + "  " + localVarItem.name + " = _cp_" + localVarItem.name + ";");
/* 1224:     */     }
/* 1225:1286 */     this.out.println(localObject + "}");
/* 1226:     */     
/* 1227:     */ 
/* 1228:1289 */     this.out.println(localObject + "// update reduction variables");
/* 1229:1290 */     this.out.println(localObject + "if (jomp.runtime.OMP.getThreadNum(__omp_me) == 0) {");
/* 1230:1291 */     localVarTable.getInit(8);
/* 1231:1292 */     while ((localVarItem = localVarTable.getNext()) != null) {
/* 1232:1293 */       this.out.println(localObject + "  " + localVarItem.name + ReductionType.opName(localVarItem.red) + "= _cp_" + localVarItem.name + ";");
/* 1233:     */     }
/* 1234:1294 */     this.out.println(localObject + "}");
/* 1235:     */     
/* 1236:1296 */     this.out.println(localObject + "} // OMP SECTIONS BLOCK ENDS");
/* 1237:1297 */     return paramObject;
/* 1238:     */   }
/* 1239:     */   
/* 1240:     */   public Object visit(ASTOMPOrderedDirective paramASTOMPOrderedDirective, Object paramObject)
/* 1241:     */   {
/* 1242:1302 */     if (!this.isInOrderedLoop) {
/* 1243:1303 */       Jomp.message(2, "Error: ordered directive not in ordered loop!");
/* 1244:     */     }
/* 1245:1308 */     StringBuffer localStringBuffer = new StringBuffer("");
/* 1246:1309 */     for (int i = 6; i < paramASTOMPOrderedDirective.getFirstToken().beginColumn; i++) {
/* 1247:1310 */       localStringBuffer.append(" ");
/* 1248:     */     }
/* 1249:1312 */     this.out.println("");
/* 1250:1313 */     this.out.println(localStringBuffer + "// OMP ORDERED BLOCK BEGINS");
/* 1251:1314 */     this.out.println(localStringBuffer + "jomp.runtime.OMP.startOrdered(__omp_me, (long)" + this.loopVarName + ");");
/* 1252:1315 */     this.out.println(localStringBuffer + "// OMP USER CODE BEGINS");
/* 1253:1316 */     paramObject = print((SimpleNode)paramASTOMPOrderedDirective.jjtGetChild(paramASTOMPOrderedDirective.jjtGetNumChildren() - 1), paramObject);
/* 1254:1317 */     this.out.println("");
/* 1255:1318 */     this.out.println(localStringBuffer + "// OMP USER CODE ENDS");
/* 1256:1319 */     this.out.println(localStringBuffer + "jomp.runtime.OMP.stopOrdered(__omp_me, (long)(" + this.loopVarName + " + " + this.loopWholeDataName + ".step));");
/* 1257:1320 */     this.out.println(localStringBuffer + "// OMP ORDERED BLOCK ENDS");
/* 1258:1321 */     return paramObject;
/* 1259:     */   }
/* 1260:     */   
/* 1261:     */   public Object visit(ASTOMPBarrierDirective paramASTOMPBarrierDirective, Object paramObject)
/* 1262:     */   {
/* 1263:1328 */     StringBuffer localStringBuffer = new StringBuffer("");
/* 1264:1329 */     for (int i = 6; i < paramASTOMPBarrierDirective.getFirstToken().beginColumn; i++) {
/* 1265:1330 */       localStringBuffer.append(" ");
/* 1266:     */     }
/* 1267:1332 */     this.out.println("");
/* 1268:1333 */     this.out.println(localStringBuffer + "// OMP BARRIER BLOCK BEGINS");
/* 1269:1334 */     if (this.isMeDefined) {
/* 1270:1335 */       this.out.println(localStringBuffer + "jomp.runtime.OMP.doBarrier(__omp_me);");
/* 1271:     */     } else {
/* 1272:1337 */       this.out.println(localStringBuffer + "jomp.runtime.OMP.doBarrier();");
/* 1273:     */     }
/* 1274:1339 */     this.out.println(localStringBuffer + "// OMP BARRIER BLOCK ENDS");
/* 1275:1340 */     return paramObject;
/* 1276:     */   }
/* 1277:     */   
/* 1278:     */   public Object visit(ASTOMPCriticalDirective paramASTOMPCriticalDirective, Object paramObject)
/* 1279:     */   {
/* 1280:1347 */     StringBuffer localStringBuffer = new StringBuffer("");
/* 1281:1348 */     for (int i = 6; i < paramASTOMPCriticalDirective.getFirstToken().beginColumn; i++) {
/* 1282:1349 */       localStringBuffer.append(" ");
/* 1283:     */     }
/* 1284:     */     String str;
/* 1285:1354 */     if (paramASTOMPCriticalDirective.jjtGetNumChildren() == 2) {
/* 1286:1356 */       str = ((SimpleNode)paramASTOMPCriticalDirective.jjtGetChild(0)).getFirstToken().toString();
/* 1287:     */     } else {
/* 1288:1358 */       str = "";
/* 1289:     */     }
/* 1290:1361 */     this.out.println("");
/* 1291:1362 */     this.out.println(localStringBuffer + "// OMP CRITICAL BLOCK BEGINS");
/* 1292:1363 */     this.out.println(localStringBuffer + "synchronized (jomp.runtime.OMP.getLockByName(\"" + str + "\")) {");
/* 1293:1364 */     this.out.println(localStringBuffer + "// OMP USER CODE BEGINS");
/* 1294:1365 */     paramObject = print((SimpleNode)paramASTOMPCriticalDirective.jjtGetChild(paramASTOMPCriticalDirective.jjtGetNumChildren() - 1), paramObject);
/* 1295:1366 */     this.out.println("");
/* 1296:1367 */     this.out.println(localStringBuffer + "// OMP USER CODE ENDS");
/* 1297:1368 */     this.out.println(localStringBuffer + "}");
/* 1298:1369 */     this.out.println(localStringBuffer + "// OMP CRITICAL BLOCK ENDS");
/* 1299:1370 */     return paramObject;
/* 1300:     */   }
/* 1301:     */   
/* 1302:     */   public Object visit(ASTOMPOnlyDirective paramASTOMPOnlyDirective, Object paramObject)
/* 1303:     */   {
/* 1304:1377 */     StringBuffer localStringBuffer = new StringBuffer("");
/* 1305:1378 */     for (int i = 6; i < paramASTOMPOnlyDirective.getFirstToken().beginColumn; i++) {
/* 1306:1379 */       localStringBuffer.append(" ");
/* 1307:     */     }
/* 1308:1381 */     this.out.println("");
/* 1309:1382 */     this.out.println(localStringBuffer + "// OMP ONLY BLOCK BEGINS");
/* 1310:1383 */     this.out.println(localStringBuffer + "// OMP USER CODE BEGINS");
/* 1311:1384 */     paramObject = print((SimpleNode)paramASTOMPOnlyDirective.jjtGetChild(paramASTOMPOnlyDirective.jjtGetNumChildren() - 1), paramObject);
/* 1312:1385 */     this.out.println(localStringBuffer + "// OMP USER CODE ENDS");
/* 1313:1386 */     this.out.println(localStringBuffer + "// OMP ONLY BLOCK ENDS");
/* 1314:1387 */     return paramObject;
/* 1315:     */   }
/* 1316:     */   
/* 1317:     */   private boolean isPrimitiveType(String paramString)
/* 1318:     */   {
/* 1319:1393 */     if (paramString.equals("byte")) {
/* 1320:1394 */       return true;
/* 1321:     */     }
/* 1322:1395 */     if (paramString.equals("short")) {
/* 1323:1396 */       return true;
/* 1324:     */     }
/* 1325:1397 */     if (paramString.equals("int")) {
/* 1326:1398 */       return true;
/* 1327:     */     }
/* 1328:1399 */     if (paramString.equals("long")) {
/* 1329:1400 */       return true;
/* 1330:     */     }
/* 1331:1401 */     if (paramString.equals("float")) {
/* 1332:1402 */       return true;
/* 1333:     */     }
/* 1334:1403 */     if (paramString.equals("double")) {
/* 1335:1404 */       return true;
/* 1336:     */     }
/* 1337:1405 */     if (paramString.equals("boolean")) {
/* 1338:1406 */       return true;
/* 1339:     */     }
/* 1340:1407 */     if (paramString.equals("char")) {
/* 1341:1408 */       return true;
/* 1342:     */     }
/* 1343:1410 */     return false;
/* 1344:     */   }
/* 1345:     */   
/* 1346:     */   private boolean isArray(String paramString)
/* 1347:     */   {
/* 1348:1414 */     return paramString.endsWith("]");
/* 1349:     */   }
/* 1350:     */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.compiler.OMPVisitor
 * JD-Core Version:    0.7.0.1
 */