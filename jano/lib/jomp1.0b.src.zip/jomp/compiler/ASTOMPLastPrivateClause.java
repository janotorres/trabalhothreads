/*  1:   */ package jomp.compiler;
/*  2:   */ 
/*  3:   */ public class ASTOMPLastPrivateClause
/*  4:   */   extends SimpleNode
/*  5:   */ {
/*  6:   */   public ASTOMPLastPrivateClause(int paramInt)
/*  7:   */   {
/*  8: 7 */     super(paramInt);
/*  9:   */   }
/* 10:   */   
/* 11:   */   public ASTOMPLastPrivateClause(JavaParser paramJavaParser, int paramInt)
/* 12:   */   {
/* 13:11 */     super(paramJavaParser, paramInt);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public Object jjtAccept(JavaParserVisitor paramJavaParserVisitor, Object paramObject)
/* 17:   */   {
/* 18:17 */     return paramJavaParserVisitor.visit(this, paramObject);
/* 19:   */   }
/* 20:   */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.compiler.ASTOMPLastPrivateClause
 * JD-Core Version:    0.7.0.1
 */