/*  1:   */ package jomp.compiler;
/*  2:   */ 
/*  3:   */ import java.io.PrintStream;
/*  4:   */ 
/*  5:   */ public class SimpleNode
/*  6:   */   implements Node
/*  7:   */ {
/*  8:   */   protected Node parent;
/*  9:   */   protected Node[] children;
/* 10:   */   protected int id;
/* 11:   */   protected JavaParser parser;
/* 12:   */   protected Token first;
/* 13:   */   protected Token last;
/* 14:   */   
/* 15:   */   public SimpleNode(int paramInt)
/* 16:   */   {
/* 17:12 */     this.id = paramInt;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public SimpleNode(JavaParser paramJavaParser, int paramInt)
/* 21:   */   {
/* 22:16 */     this(paramInt);
/* 23:17 */     this.parser = paramJavaParser;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public static Node jjtCreate(JavaParser paramJavaParser, int paramInt)
/* 27:   */   {
/* 28:21 */     return new SimpleNode(paramJavaParser, paramInt);
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void jjtOpen()
/* 32:   */   {
/* 33:25 */     this.first = this.parser.getToken(1);
/* 34:   */   }
/* 35:   */   
/* 36:   */   public void jjtClose()
/* 37:   */   {
/* 38:29 */     this.last = this.parser.getToken(0);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public Token getFirstToken()
/* 42:   */   {
/* 43:32 */     return this.first;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public Token getLastToken()
/* 47:   */   {
/* 48:33 */     return this.last;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public void jjtSetParent(Node paramNode)
/* 52:   */   {
/* 53:35 */     this.parent = paramNode;
/* 54:   */   }
/* 55:   */   
/* 56:   */   public Node jjtGetParent()
/* 57:   */   {
/* 58:36 */     return this.parent;
/* 59:   */   }
/* 60:   */   
/* 61:   */   public void jjtAddChild(Node paramNode, int paramInt)
/* 62:   */   {
/* 63:39 */     if (this.children == null)
/* 64:   */     {
/* 65:40 */       this.children = new Node[paramInt + 1];
/* 66:   */     }
/* 67:41 */     else if (paramInt >= this.children.length)
/* 68:   */     {
/* 69:42 */       Node[] arrayOfNode = new Node[paramInt + 1];
/* 70:43 */       System.arraycopy(this.children, 0, arrayOfNode, 0, this.children.length);
/* 71:44 */       this.children = arrayOfNode;
/* 72:   */     }
/* 73:46 */     this.children[paramInt] = paramNode;
/* 74:   */   }
/* 75:   */   
/* 76:   */   public Node jjtGetChild(int paramInt)
/* 77:   */   {
/* 78:50 */     return this.children[paramInt];
/* 79:   */   }
/* 80:   */   
/* 81:   */   public int jjtGetNumChildren()
/* 82:   */   {
/* 83:54 */     return this.children == null ? 0 : this.children.length;
/* 84:   */   }
/* 85:   */   
/* 86:   */   public Object jjtAccept(JavaParserVisitor paramJavaParserVisitor, Object paramObject)
/* 87:   */   {
/* 88:59 */     return paramJavaParserVisitor.visit(this, paramObject);
/* 89:   */   }
/* 90:   */   
/* 91:   */   public Object acceptChildren(JavaParserVisitor paramJavaParserVisitor, Object paramObject)
/* 92:   */   {
/* 93:64 */     if (this.children != null) {
/* 94:65 */       for (int i = 0; i < this.children.length; i++) {
/* 95:66 */         this.children[i].jjtAccept(paramJavaParserVisitor, paramObject);
/* 96:   */       }
/* 97:   */     }
/* 98:69 */     return paramObject;
/* 99:   */   }
/* :0:   */   
/* :1:   */   public String toString()
/* :2:   */   {
/* :3:78 */     return JavaParserTreeConstants.jjtNodeName[this.id];
/* :4:   */   }
/* :5:   */   
/* :6:   */   public String toString(String paramString)
/* :7:   */   {
/* :8:79 */     return paramString + toString();
/* :9:   */   }
/* ;0:   */   
/* ;1:   */   public void dump(String paramString)
/* ;2:   */   {
/* ;3:85 */     System.out.println(toString(paramString));
/* ;4:86 */     if (this.children != null) {
/* ;5:87 */       for (int i = 0; i < this.children.length; i++)
/* ;6:   */       {
/* ;7:88 */         SimpleNode localSimpleNode = (SimpleNode)this.children[i];
/* ;8:89 */         if (localSimpleNode != null) {
/* ;9:90 */           localSimpleNode.dump(paramString + " ");
/* <0:   */         }
/* <1:   */       }
/* <2:   */     }
/* <3:   */   }
/* <4:   */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.compiler.SimpleNode
 * JD-Core Version:    0.7.0.1
 */