/*  1:   */ package jomp.runtime;
/*  2:   */ 
/*  3:   */ public class Lock
/*  4:   */ {
/*  5:13 */   private volatile boolean isSet = false;
/*  6:   */   
/*  7:   */   public synchronized void set()
/*  8:   */   {
/*  9:22 */     while (this.isSet) {
/* 10:   */       try
/* 11:   */       {
/* 12:24 */         wait();
/* 13:   */       }
/* 14:   */       catch (Exception localException) {}
/* 15:   */     }
/* 16:27 */     this.isSet = true;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public synchronized void unset()
/* 20:   */   {
/* 21:37 */     this.isSet = false;
/* 22:38 */     notify();
/* 23:   */   }
/* 24:   */   
/* 25:   */   public synchronized boolean test()
/* 26:   */   {
/* 27:51 */     if (this.isSet) {
/* 28:52 */       return false;
/* 29:   */     }
/* 30:54 */     this.isSet = true;
/* 31:55 */     return true;
/* 32:   */   }
/* 33:   */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.runtime.Lock
 * JD-Core Version:    0.7.0.1
 */