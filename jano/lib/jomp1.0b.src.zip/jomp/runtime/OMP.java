/*   1:    */ package jomp.runtime;
/*   2:    */ 
/*   3:    */ import java.io.PrintStream;
/*   4:    */ import java.util.Hashtable;
/*   5:    */ 
/*   6:    */ public class OMP
/*   7:    */ {
/*   8: 21 */   static boolean isRunning = false;
/*   9: 23 */   static boolean isStarted = false;
/*  10: 25 */   static boolean isParallel = false;
/*  11: 30 */   private static int numThreads = 1;
/*  12: 32 */   private static int numProcs = 16;
/*  13:    */   private static Barrier[] threadBarrier;
/*  14:    */   private static Ticketer[] threadTicketer;
/*  15:    */   private static Orderer[] threadOrderer;
/*  16:    */   private static Reducer[] threadReducer;
/*  17:    */   private static int[] threadID;
/*  18:    */   private static int[] threadNum;
/*  19:    */   private static BusyThread[] threads;
/*  20:    */   private static Throwable[] threadException;
/*  21: 53 */   private static int globTicket = 0;
/*  22:    */   private static Hashtable criticalTable;
/*  23: 61 */   private static BusyTask lastTask = null;
/*  24:    */   
/*  25:    */   static
/*  26:    */   {
/*  27: 73 */     String str = System.getProperty("jomp.schedule");
/*  28: 74 */     if (str != null)
/*  29:    */     {
/*  30: 75 */       i = str.indexOf(',');
/*  31: 76 */       if (i != -1)
/*  32:    */       {
/*  33:    */         try
/*  34:    */         {
/*  35: 78 */           Options.schedChunkSize = Integer.parseInt(str.substring(i + 1));
/*  36: 79 */           Options.isSchedChunkSet = true;
/*  37:    */         }
/*  38:    */         catch (NumberFormatException localNumberFormatException1)
/*  39:    */         {
/*  40: 81 */           System.err.println("Schedule chunksize must be an integer number - using default value");
/*  41:    */         }
/*  42: 83 */         str = str.substring(0, i).toLowerCase();
/*  43:    */       }
/*  44: 85 */       System.err.println("Scheduling mode " + str);
/*  45: 86 */       if (str.compareTo("static") == 0) {
/*  46: 87 */         Options.schedMode = 0;
/*  47: 88 */       } else if (str.compareTo("dynamic") == 0) {
/*  48: 89 */         Options.schedMode = 1;
/*  49: 90 */       } else if (str.compareTo("guided") == 0) {
/*  50: 91 */         Options.schedMode = 2;
/*  51:    */       } else {
/*  52: 93 */         System.err.println("Unknown default scheduling option!");
/*  53:    */       }
/*  54:    */     }
/*  55: 99 */     int i = 1;
/*  56:100 */     str = System.getProperty("jomp.threads");
/*  57:101 */     if (str != null) {
/*  58:    */       try
/*  59:    */       {
/*  60:103 */         i = Integer.parseInt(str);
/*  61:    */       }
/*  62:    */       catch (NumberFormatException localNumberFormatException2)
/*  63:    */       {
/*  64:105 */         System.err.println("jomp.threads must be an integer - using default value.");
/*  65:106 */         i = 1;
/*  66:    */       }
/*  67:    */     }
/*  68:110 */     setNumThreads(i);
/*  69:111 */     setNumProcs(2 * i);
/*  70:    */   }
/*  71:    */   
/*  72:    */   private static class Options
/*  73:    */   {
/*  74:    */     static final int SCHED_STATIC = 0;
/*  75:    */     static final int SCHED_DYNAMIC = 1;
/*  76:    */     static final int SCHED_GUIDED = 2;
/*  77:123 */     static int schedMode = 0;
/*  78:125 */     static boolean isSchedChunkSet = false;
/*  79:    */     static int schedChunkSize;
/*  80:132 */     static boolean isExceptionable = true;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public static void start()
/*  84:    */   {
/*  85:150 */     criticalTable = new Hashtable(5);
/*  86:    */     
/*  87:152 */     threadBarrier = new Barrier[numThreads];
/*  88:153 */     threadTicketer = new Ticketer[numThreads];
/*  89:154 */     threadReducer = new Reducer[numThreads];
/*  90:155 */     threadOrderer = new Orderer[numThreads];
/*  91:156 */     threadID = new int[numThreads];
/*  92:157 */     threadNum = new int[numThreads];
/*  93:158 */     threadException = new Throwable[numThreads];
/*  94:    */     
/*  95:160 */     Barrier localBarrier = new Barrier(numThreads);
/*  96:161 */     Ticketer localTicketer = new Ticketer();
/*  97:162 */     Reducer localReducer = new Reducer(numThreads);
/*  98:163 */     Orderer localOrderer = new Orderer();
/*  99:    */     
/* 100:165 */     isRunning = false;
/* 101:166 */     threads = new BusyThread[numThreads];
/* 102:167 */     for (int i = 0; i < numThreads; i++)
/* 103:    */     {
/* 104:168 */       threadBarrier[i] = localBarrier;
/* 105:169 */       threadTicketer[i] = localTicketer;
/* 106:170 */       threadReducer[i] = localReducer;
/* 107:171 */       threadOrderer[i] = localOrderer;
/* 108:172 */       threadNum[i] = numThreads;
/* 109:173 */       threadID[i] = i;
/* 110:174 */       threadException[i] = null;
/* 111:175 */       if (i == 0)
/* 112:    */       {
/* 113:176 */         threads[0] = null;
/* 114:177 */         Thread.currentThread().setName("0");
/* 115:    */       }
/* 116:    */       else
/* 117:    */       {
/* 118:179 */         threads[i] = new BusyThread(i);
/* 119:180 */         threads[i].setName(Integer.toString(i));
/* 120:181 */         threads[i].setDaemon(true);
/* 121:182 */         threads[i].start();
/* 122:    */       }
/* 123:    */     }
/* 124:185 */     isRunning = true;
/* 125:186 */     isStarted = true;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public static void stop()
/* 129:    */   {
/* 130:193 */     if (isStarted)
/* 131:    */     {
/* 132:194 */       isRunning = false;
/* 133:195 */       doGlobalBarrier(0);
/* 134:196 */       isStarted = false;
/* 135:    */     }
/* 136:    */   }
/* 137:    */   
/* 138:    */   public static void kill()
/* 139:    */   {
/* 140:205 */     for (int i = 1; i < numThreads; i++) {
/* 141:206 */       threads[i].stop();
/* 142:    */     }
/* 143:207 */     isParallel = false;
/* 144:208 */     setNumThreads(numThreads);
/* 145:    */   }
/* 146:    */   
/* 147:    */   public static void doParallel(BusyTask paramBusyTask)
/* 148:    */     throws Throwable
/* 149:    */   {
/* 150:    */     int i;
/* 151:221 */     if (isParallel)
/* 152:    */     {
/* 153:224 */       i = getAbsoluteID();
/* 154:    */       
/* 155:226 */       Barrier localBarrier = threadBarrier[i];
/* 156:227 */       Ticketer localTicketer = threadTicketer[i];
/* 157:228 */       Reducer localReducer = threadReducer[i];
/* 158:229 */       Orderer localOrderer = threadOrderer[i];
/* 159:230 */       int j = threadNum[i];
/* 160:231 */       int k = threadID[i];
/* 161:232 */       Throwable localThrowable2 = threadException[i];
/* 162:    */       
/* 163:234 */       threadBarrier[i] = new Barrier(1);
/* 164:235 */       threadTicketer[i] = new Ticketer();
/* 165:236 */       threadReducer[i] = new Reducer(1);
/* 166:237 */       threadOrderer[i] = new Orderer();
/* 167:238 */       threadNum[i] = 1;
/* 168:239 */       threadID[i] = 0;
/* 169:240 */       threadException[i] = null;
/* 170:    */       
/* 171:242 */       paramBusyTask.go(0);
/* 172:243 */       Throwable localThrowable3 = threadException[i];
/* 173:    */       
/* 174:245 */       threadBarrier[i] = localBarrier;
/* 175:246 */       threadTicketer[i] = localTicketer;
/* 176:247 */       threadReducer[i] = localReducer;
/* 177:248 */       threadOrderer[i] = localOrderer;
/* 178:249 */       threadNum[i] = j;
/* 179:250 */       threadID[i] = k;
/* 180:251 */       threadException[i] = localThrowable2;
/* 181:253 */       if (localThrowable3 != null) {
/* 182:254 */         throw localThrowable3;
/* 183:    */       }
/* 184:    */     }
/* 185:    */     else
/* 186:    */     {
/* 187:258 */       if (!isStarted) {
/* 188:258 */         start();
/* 189:    */       }
/* 190:259 */       isParallel = true;
/* 191:260 */       if (paramBusyTask != lastTask)
/* 192:    */       {
/* 193:261 */         for (i = 1; i < numThreads; i++) {
/* 194:262 */           threads[i].mytask = paramBusyTask;
/* 195:    */         }
/* 196:264 */         lastTask = paramBusyTask;
/* 197:    */       }
/* 198:266 */       doGlobalBarrier(0);
/* 199:    */       try
/* 200:    */       {
/* 201:268 */         paramBusyTask.go(0);
/* 202:    */       }
/* 203:    */       catch (InterruptedException localInterruptedException) {}
/* 204:271 */       if (Options.isExceptionable)
/* 205:    */       {
/* 206:272 */         Throwable localThrowable1 = threadException[0];
/* 207:273 */         threadException[0] = null;
/* 208:274 */         if (localThrowable1 != null)
/* 209:    */         {
/* 210:275 */           kill();
/* 211:276 */           throw localThrowable1;
/* 212:    */         }
/* 213:    */       }
/* 214:279 */       doGlobalBarrier(0);
/* 215:280 */       isParallel = false;
/* 216:    */     }
/* 217:    */   }
/* 218:    */   
/* 219:    */   public static void doBarrier(int paramInt)
/* 220:    */   {
/* 221:293 */     if (getNumThreads(paramInt) > 1) {
/* 222:294 */       threadBarrier[paramInt].DoBarrier(getThreadNum(paramInt));
/* 223:    */     }
/* 224:    */   }
/* 225:    */   
/* 226:    */   public static void doBarrier()
/* 227:    */   {
/* 228:302 */     if (!isParallel) {
/* 229:302 */       return;
/* 230:    */     }
/* 231:303 */     int i = getAbsoluteID();
/* 232:304 */     if (getNumThreads(i) > 1) {
/* 233:305 */       threadBarrier[i].DoBarrier(getThreadNum(i));
/* 234:    */     }
/* 235:    */   }
/* 236:    */   
/* 237:    */   public static void doGlobalBarrier(int paramInt)
/* 238:    */   {
/* 239:315 */     threadBarrier[paramInt].DoBarrier(paramInt);
/* 240:    */   }
/* 241:    */   
/* 242:    */   public static long doPlusReduce(int paramInt, long paramLong)
/* 243:    */   {
/* 244:329 */     if (!isParallel) {
/* 245:329 */       return paramLong;
/* 246:    */     }
/* 247:330 */     return threadReducer[paramInt].doPlusReduce(getThreadNum(paramInt), paramLong);
/* 248:    */   }
/* 249:    */   
/* 250:    */   public static double doPlusReduce(int paramInt, double paramDouble)
/* 251:    */   {
/* 252:340 */     if (!isParallel) {
/* 253:340 */       return paramDouble;
/* 254:    */     }
/* 255:341 */     return threadReducer[paramInt].doPlusReduce(getThreadNum(paramInt), paramDouble);
/* 256:    */   }
/* 257:    */   
/* 258:    */   public static long doMultReduce(int paramInt, long paramLong)
/* 259:    */   {
/* 260:351 */     if (!isParallel) {
/* 261:351 */       return paramLong;
/* 262:    */     }
/* 263:352 */     return threadReducer[paramInt].doMultReduce(getThreadNum(paramInt), paramLong);
/* 264:    */   }
/* 265:    */   
/* 266:    */   public static double doMultReduce(int paramInt, double paramDouble)
/* 267:    */   {
/* 268:362 */     if (!isParallel) {
/* 269:362 */       return paramDouble;
/* 270:    */     }
/* 271:363 */     return threadReducer[paramInt].doMultReduce(getThreadNum(paramInt), paramDouble);
/* 272:    */   }
/* 273:    */   
/* 274:    */   public static boolean doAndReduce(int paramInt, boolean paramBoolean)
/* 275:    */   {
/* 276:374 */     if (!isParallel) {
/* 277:374 */       return paramBoolean;
/* 278:    */     }
/* 279:375 */     return threadReducer[paramInt].doAndReduce(getThreadNum(paramInt), paramBoolean);
/* 280:    */   }
/* 281:    */   
/* 282:    */   public static boolean doOrReduce(int paramInt, boolean paramBoolean)
/* 283:    */   {
/* 284:385 */     if (!isParallel) {
/* 285:385 */       return paramBoolean;
/* 286:    */     }
/* 287:386 */     return threadReducer[paramInt].doOrReduce(getThreadNum(paramInt), paramBoolean);
/* 288:    */   }
/* 289:    */   
/* 290:    */   public static double doBitOrReduce(int paramInt, long paramLong)
/* 291:    */   {
/* 292:396 */     if (!isParallel) {
/* 293:396 */       return paramLong;
/* 294:    */     }
/* 295:397 */     return threadReducer[paramInt].doBitOrReduce(getThreadNum(paramInt), paramLong);
/* 296:    */   }
/* 297:    */   
/* 298:    */   public static double doBitXorReduce(int paramInt, long paramLong)
/* 299:    */   {
/* 300:407 */     if (!isParallel) {
/* 301:407 */       return paramLong;
/* 302:    */     }
/* 303:408 */     return threadReducer[paramInt].doBitXorReduce(getThreadNum(paramInt), paramLong);
/* 304:    */   }
/* 305:    */   
/* 306:    */   public static double doBitAndReduce(int paramInt, long paramLong)
/* 307:    */   {
/* 308:418 */     if (!isParallel) {
/* 309:418 */       return paramLong;
/* 310:    */     }
/* 311:419 */     return threadReducer[paramInt].doBitAndReduce(getThreadNum(paramInt), paramLong);
/* 312:    */   }
/* 313:    */   
/* 314:    */   public static void setChunkStatic(LoopData paramLoopData)
/* 315:    */   {
/* 316:433 */     paramLoopData.chunkSize = (paramLoopData.stop - paramLoopData.start);
/* 317:434 */     if (paramLoopData.chunkSize < 0L) {
/* 318:435 */       paramLoopData.chunkSize *= -1L;
/* 319:    */     }
/* 320:436 */     paramLoopData.chunkSize = ((paramLoopData.chunkSize - 1L) / paramLoopData.step);
/* 321:    */     
/* 322:438 */     paramLoopData.chunkSize = (paramLoopData.chunkSize / getNumThreads() + 1L);
/* 323:    */   }
/* 324:    */   
/* 325:    */   public static void setChunkRuntime(LoopData paramLoopData)
/* 326:    */   {
/* 327:447 */     if (Options.isSchedChunkSet) {
/* 328:448 */       paramLoopData.chunkSize = Options.schedChunkSize;
/* 329:    */     } else {
/* 330:450 */       switch (Options.schedMode)
/* 331:    */       {
/* 332:    */       case 0: 
/* 333:452 */         setChunkStatic(paramLoopData);
/* 334:453 */         break;
/* 335:    */       case 1: 
/* 336:    */       case 2: 
/* 337:456 */         paramLoopData.chunkSize = 1L;
/* 338:    */       }
/* 339:    */     }
/* 340:    */   }
/* 341:    */   
/* 342:    */   public static boolean getLoopStatic(int paramInt, LoopData paramLoopData1, LoopData paramLoopData2)
/* 343:    */   {
/* 344:470 */     paramLoopData1.start += paramLoopData1.chunkSize * paramLoopData1.step * getThreadNum(paramInt);
/* 345:471 */     paramLoopData2.stop = (paramLoopData2.start + paramLoopData1.chunkSize * paramLoopData1.step);
/* 346:472 */     paramLoopData2.startStep = (paramLoopData1.chunkSize * paramLoopData1.step * getNumThreads(paramInt));
/* 347:473 */     paramLoopData2.step = paramLoopData1.step;
/* 348:474 */     paramLoopData2.isLast = true;
/* 349:    */     
/* 350:476 */     return true;
/* 351:    */   }
/* 352:    */   
/* 353:    */   public static boolean getLoopDynamic(int paramInt, LoopData paramLoopData1, LoopData paramLoopData2)
/* 354:    */   {
/* 355:487 */     if (!isParallel)
/* 356:    */     {
/* 357:488 */       paramLoopData2.start = paramLoopData1.start;
/* 358:489 */       paramLoopData2.stop = paramLoopData1.stop;
/* 359:490 */       paramLoopData2.step = paramLoopData1.step;
/* 360:491 */       paramLoopData2.isLast = true;
/* 361:492 */       return true;
/* 362:    */     }
/* 363:495 */     threadTicketer[paramInt].issueDynamic(paramLoopData2);
/* 364:496 */     if (paramLoopData1.step > 0L)
/* 365:    */     {
/* 366:497 */       if (paramLoopData2.start >= paramLoopData1.stop) {
/* 367:497 */         return false;
/* 368:    */       }
/* 369:498 */       if (paramLoopData2.stop >= paramLoopData1.stop)
/* 370:    */       {
/* 371:499 */         paramLoopData2.stop = paramLoopData1.stop;
/* 372:500 */         paramLoopData2.isLast = true;
/* 373:    */       }
/* 374:    */     }
/* 375:    */     else
/* 376:    */     {
/* 377:503 */       if (paramLoopData2.start <= paramLoopData1.stop) {
/* 378:503 */         return false;
/* 379:    */       }
/* 380:504 */       if (paramLoopData2.stop <= paramLoopData1.stop)
/* 381:    */       {
/* 382:505 */         paramLoopData2.stop = paramLoopData1.stop;
/* 383:506 */         paramLoopData2.isLast = true;
/* 384:    */       }
/* 385:    */     }
/* 386:509 */     paramLoopData2.step = paramLoopData1.step;
/* 387:510 */     return true;
/* 388:    */   }
/* 389:    */   
/* 390:    */   public static boolean getLoopGuided(int paramInt, LoopData paramLoopData1, LoopData paramLoopData2)
/* 391:    */   {
/* 392:521 */     if (!isParallel)
/* 393:    */     {
/* 394:522 */       paramLoopData2.start = paramLoopData1.start;
/* 395:523 */       paramLoopData2.stop = paramLoopData1.stop;
/* 396:524 */       paramLoopData2.step = paramLoopData1.step;
/* 397:525 */       paramLoopData2.isLast = true;
/* 398:526 */       return true;
/* 399:    */     }
/* 400:529 */     return threadTicketer[paramInt].issueGuided(paramLoopData1, paramLoopData2, threadNum[paramInt]);
/* 401:    */   }
/* 402:    */   
/* 403:    */   public static boolean getLoopRuntime(int paramInt, LoopData paramLoopData1, LoopData paramLoopData2)
/* 404:    */   {
/* 405:540 */     switch (Options.schedMode)
/* 406:    */     {
/* 407:    */     case 0: 
/* 408:541 */       return getLoopStatic(paramInt, paramLoopData1, paramLoopData2);
/* 409:    */     case 1: 
/* 410:542 */       return getLoopDynamic(paramInt, paramLoopData1, paramLoopData2);
/* 411:    */     case 2: 
/* 412:543 */       return getLoopGuided(paramInt, paramLoopData1, paramLoopData2);
/* 413:    */     }
/* 414:545 */     return false;
/* 415:    */   }
/* 416:    */   
/* 417:    */   public static long getTicket(int paramInt)
/* 418:    */   {
/* 419:560 */     if (!isParallel) {
/* 420:561 */       return globTicket++;
/* 421:    */     }
/* 422:563 */     return threadTicketer[paramInt].issue();
/* 423:    */   }
/* 424:    */   
/* 425:    */   public static void resetTicket(int paramInt)
/* 426:    */   {
/* 427:573 */     if (!isParallel)
/* 428:    */     {
/* 429:574 */       globTicket = 0;
/* 430:575 */       return;
/* 431:    */     }
/* 432:577 */     threadTicketer[paramInt] = threadTicketer[paramInt].reset();
/* 433:    */   }
/* 434:    */   
/* 435:    */   public static void initTicket(int paramInt, LoopData paramLoopData)
/* 436:    */   {
/* 437:585 */     threadTicketer[paramInt].initDyn(paramLoopData);
/* 438:    */   }
/* 439:    */   
/* 440:    */   public static void resetOrderer(int paramInt, long paramLong)
/* 441:    */   {
/* 442:598 */     if (!isParallel) {
/* 443:598 */       return;
/* 444:    */     }
/* 445:599 */     threadOrderer[paramInt] = threadOrderer[paramInt].reset(paramLong, paramInt);
/* 446:    */   }
/* 447:    */   
/* 448:    */   public static void startOrdered(int paramInt, long paramLong)
/* 449:    */   {
/* 450:609 */     if (!isParallel) {
/* 451:609 */       return;
/* 452:    */     }
/* 453:610 */     threadOrderer[paramInt].startOrdered(paramLong, paramInt);
/* 454:    */   }
/* 455:    */   
/* 456:    */   public static void stopOrdered(int paramInt, long paramLong)
/* 457:    */   {
/* 458:619 */     if (!isParallel) {
/* 459:619 */       return;
/* 460:    */     }
/* 461:620 */     threadOrderer[paramInt].stopOrdered(paramLong);
/* 462:    */   }
/* 463:    */   
/* 464:    */   public static void setNumThreads(int paramInt)
/* 465:    */   {
/* 466:638 */     if (isParallel) {
/* 467:639 */       throw new OMPException("setNumThreads called in a parallel region!");
/* 468:    */     }
/* 469:640 */     numThreads = paramInt;
/* 470:641 */     if (isStarted) {
/* 471:641 */       stop();
/* 472:    */     }
/* 473:    */   }
/* 474:    */   
/* 475:    */   public static int getNumThreads()
/* 476:    */   {
/* 477:654 */     if (!isParallel) {
/* 478:655 */       return 1;
/* 479:    */     }
/* 480:656 */     return threadNum[getAbsoluteID()];
/* 481:    */   }
/* 482:    */   
/* 483:    */   public static int getMaxThreads()
/* 484:    */   {
/* 485:668 */     return numThreads;
/* 486:    */   }
/* 487:    */   
/* 488:    */   public static int getThreadNum()
/* 489:    */   {
/* 490:682 */     if (!isParallel) {
/* 491:683 */       return 0;
/* 492:    */     }
/* 493:684 */     return threadID[getAbsoluteID()];
/* 494:    */   }
/* 495:    */   
/* 496:    */   public static int getNumProcs()
/* 497:    */   {
/* 498:697 */     return Machine.getNumProcs();
/* 499:    */   }
/* 500:    */   
/* 501:    */   public static boolean inParallel()
/* 502:    */   {
/* 503:710 */     return isParallel;
/* 504:    */   }
/* 505:    */   
/* 506:    */   public static boolean getDynamic()
/* 507:    */   {
/* 508:736 */     return false;
/* 509:    */   }
/* 510:    */   
/* 511:    */   public static boolean getNested()
/* 512:    */   {
/* 513:761 */     return false;
/* 514:    */   }
/* 515:    */   
/* 516:    */   public static int getNumThreads(int paramInt)
/* 517:    */   {
/* 518:776 */     if (!isParallel) {
/* 519:776 */       return 1;
/* 520:    */     }
/* 521:777 */     return threadNum[paramInt];
/* 522:    */   }
/* 523:    */   
/* 524:    */   public static int getThreadNum(int paramInt)
/* 525:    */   {
/* 526:789 */     if (!isParallel) {
/* 527:789 */       return 0;
/* 528:    */     }
/* 529:790 */     return threadID[paramInt];
/* 530:    */   }
/* 531:    */   
/* 532:    */   public static synchronized NestLock getLockByName(String paramString)
/* 533:    */   {
/* 534:803 */     if (criticalTable == null) {
/* 535:804 */       System.err.println("No critical table!!");
/* 536:    */     }
/* 537:806 */     NestLock localNestLock = (NestLock)criticalTable.get(paramString);
/* 538:807 */     if (localNestLock == null)
/* 539:    */     {
/* 540:808 */       localNestLock = new NestLock();
/* 541:809 */       criticalTable.put(paramString, localNestLock);
/* 542:    */     }
/* 543:811 */     return localNestLock;
/* 544:    */   }
/* 545:    */   
/* 546:    */   public static int getAbsoluteID()
/* 547:    */   {
/* 548:820 */     if (isParallel) {
/* 549:821 */       return Integer.parseInt(Thread.currentThread().getName());
/* 550:    */     }
/* 551:823 */     return 0;
/* 552:    */   }
/* 553:    */   
/* 554:    */   public static boolean isDynamic()
/* 555:    */   {
/* 556:832 */     return Options.schedMode == 1;
/* 557:    */   }
/* 558:    */   
/* 559:    */   public static synchronized void handleException(int paramInt, Throwable paramThrowable)
/* 560:    */   {
/* 561:843 */     if (getNumThreads() == 1)
/* 562:    */     {
/* 563:844 */       if (Options.isExceptionable) {
/* 564:845 */         threadException[paramInt] = paramThrowable;
/* 565:    */       } else {
/* 566:847 */         System.err.println("Exceptions may not be thrown from parallel constructs!");
/* 567:    */       }
/* 568:    */     }
/* 569:852 */     else if (Options.isExceptionable) {
/* 570:853 */       threadException[0] = paramThrowable;
/* 571:    */     } else {
/* 572:855 */       System.err.println("Exceptions may not be thrown from parallel constructs!");
/* 573:    */     }
/* 574:    */   }
/* 575:    */   
/* 576:    */   private static void setNumProcs(int paramInt)
/* 577:    */   {
/* 578:869 */     if (isParallel) {
/* 579:870 */       throw new OMPException("setNumProcs called in a sequential region!");
/* 580:    */     }
/* 581:871 */     numProcs = paramInt;
/* 582:872 */     Machine.setNumProcs(paramInt);
/* 583:873 */     if (isStarted) {
/* 584:874 */       stop();
/* 585:    */     }
/* 586:    */   }
/* 587:    */   
/* 588:    */   public static void setDynamic(int paramInt) {}
/* 589:    */   
/* 590:    */   public static void setNested(boolean paramBoolean) {}
/* 591:    */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.runtime.OMP
 * JD-Core Version:    0.7.0.1
 */