/*  1:   */ package jomp.runtime;
/*  2:   */ 
/*  3:   */ public class Machine
/*  4:   */ {
/*  5:   */   public static void setNumProcs(int paramInt) {}
/*  6:   */   
/*  7:   */   public static int getNumProcs()
/*  8:   */   {
/*  9:10 */     return 0;
/* 10:   */   }
/* 11:   */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.runtime.Machine
 * JD-Core Version:    0.7.0.1
 */