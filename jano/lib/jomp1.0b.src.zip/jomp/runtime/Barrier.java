/*  1:   */ package jomp.runtime;
/*  2:   */ 
/*  3:   */ class Barrier
/*  4:   */ {
/*  5:   */   private volatile int numThreads;
/*  6:   */   private volatile boolean[] IsDone;
/*  7:31 */   private int maxBusyIter = 1;
/*  8:   */   
/*  9:   */   public Barrier(int paramInt)
/* 10:   */   {
/* 11:38 */     this.numThreads = paramInt;
/* 12:   */     
/* 13:   */ 
/* 14:41 */     this.IsDone = new boolean[this.numThreads];
/* 15:42 */     for (int i = 0; i < this.numThreads; i++) {
/* 16:43 */       this.IsDone[i] = false;
/* 17:   */     }
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void setMaxBusyIter(int paramInt)
/* 21:   */   {
/* 22:51 */     this.maxBusyIter = paramInt;
/* 23:   */   }
/* 24:   */   
/* 25:   */   void DoBarrier(int paramInt)
/* 26:   */   {
/* 27:62 */     int j = 3;
/* 28:63 */     int k = this.IsDone[paramInt] == 0 ? 1 : 0;
/* 29:65 */     while (((paramInt & j) == 0) && (j < this.numThreads << 2))
/* 30:   */     {
/* 31:66 */       int m = j + 1 >> 2;
/* 32:67 */       for (int n = 1; (n <= 3) && (paramInt + n * m < this.numThreads); n++)
/* 33:   */       {
/* 34:68 */         i = this.maxBusyIter;
/* 35:69 */         while (this.IsDone[(paramInt + n * m)] != k)
/* 36:   */         {
/* 37:70 */           i--;
/* 38:71 */           if (i == 0)
/* 39:   */           {
/* 40:72 */             Thread.yield();
/* 41:73 */             i = this.maxBusyIter;
/* 42:   */           }
/* 43:   */         }
/* 44:   */       }
/* 45:77 */       j = (j << 2) + 3;
/* 46:   */     }
/* 47:79 */     this.IsDone[paramInt] = k;
/* 48:80 */     int i = this.maxBusyIter;
/* 49:81 */     while (this.IsDone[0] != k)
/* 50:   */     {
/* 51:82 */       i--;
/* 52:83 */       if (i == 0)
/* 53:   */       {
/* 54:84 */         Thread.yield();
/* 55:85 */         i = this.maxBusyIter;
/* 56:   */       }
/* 57:   */     }
/* 58:   */   }
/* 59:   */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.runtime.Barrier
 * JD-Core Version:    0.7.0.1
 */