/*  1:   */ package jomp.runtime;
/*  2:   */ 
/*  3:   */ class Orderer
/*  4:   */ {
/*  5:   */   public volatile long nextIter;
/*  6:   */   public Orderer next;
/*  7:   */   private Object[] Locks;
/*  8:   */   private volatile long[] Iters;
/*  9:   */   private int tCard;
/* 10:   */   
/* 11:   */   Orderer() {}
/* 12:   */   
/* 13:   */   private Orderer(long paramLong, int paramInt)
/* 14:   */   {
/* 15:45 */     this.nextIter = paramLong;
/* 16:46 */     this.tCard = OMP.getNumThreads(paramInt);
/* 17:47 */     this.Locks = new Object[this.tCard];
/* 18:48 */     this.Iters = new long[this.tCard];
/* 19:49 */     for (int i = 0; i < this.tCard; i++)
/* 20:   */     {
/* 21:50 */       this.Locks[i] = new Object();
/* 22:51 */       this.Iters[i] = paramLong;
/* 23:   */     }
/* 24:   */   }
/* 25:   */   
/* 26:   */   final synchronized Orderer reset(long paramLong, int paramInt)
/* 27:   */   {
/* 28:64 */     if (this.next == null) {
/* 29:65 */       this.next = new Orderer(paramLong, paramInt);
/* 30:   */     }
/* 31:67 */     return this.next;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void startOrdered(long paramLong, int paramInt)
/* 35:   */   {
/* 36:76 */     synchronized (this.Locks[paramInt])
/* 37:   */     {
/* 38:77 */       if (paramLong != this.nextIter)
/* 39:   */       {
/* 40:78 */         this.Iters[paramInt] = paramLong;
/* 41:   */         try
/* 42:   */         {
/* 43:80 */           this.Locks[paramInt].wait();
/* 44:   */         }
/* 45:   */         catch (Exception localException) {}
/* 46:   */       }
/* 47:   */     }
/* 48:   */   }
/* 49:   */   
/* 50:   */   void stopOrdered(long paramLong)
/* 51:   */   {
/* 52:92 */     this.nextIter = paramLong;
/* 53:93 */     for (int i = 0; i < this.tCard; i++) {
/* 54:94 */       if (this.Iters[i] == paramLong) {
/* 55:95 */         synchronized (this.Locks[i])
/* 56:   */         {
/* 57:96 */           this.Locks[i].notify();
/* 58:   */         }
/* 59:   */       }
/* 60:   */     }
/* 61:   */   }
/* 62:   */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.runtime.Orderer
 * JD-Core Version:    0.7.0.1
 */