/* 1:  */ package jomp.runtime;
/* 2:  */ 
/* 3:  */ public class OMPException
/* 4:  */   extends RuntimeException
/* 5:  */ {
/* 6:  */   public OMPException(String paramString)
/* 7:  */   {
/* 8:5 */     super(paramString);
/* 9:  */   }
/* ::  */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.runtime.OMPException
 * JD-Core Version:    0.7.0.1
 */