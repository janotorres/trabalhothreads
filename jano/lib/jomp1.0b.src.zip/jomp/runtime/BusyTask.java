package jomp.runtime;

public abstract class BusyTask
{
  public abstract void go(int paramInt)
    throws Throwable;
}


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.runtime.BusyTask
 * JD-Core Version:    0.7.0.1
 */