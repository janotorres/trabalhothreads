/*   1:    */ package jomp.runtime;
/*   2:    */ 
/*   3:    */ class Reducer
/*   4:    */ {
/*   5:    */   private volatile boolean[] isDone;
/*   6:    */   private volatile long[] longValue;
/*   7:    */   private volatile double[] doubleValue;
/*   8:    */   private volatile boolean[] booleanValue;
/*   9: 37 */   private int maxBusyIter = 1;
/*  10:    */   private int numThreads;
/*  11:    */   
/*  12:    */   Reducer(int paramInt)
/*  13:    */   {
/*  14: 47 */     this.numThreads = paramInt;
/*  15:    */     
/*  16: 49 */     this.isDone = new boolean[this.numThreads];
/*  17: 50 */     this.longValue = new long[this.numThreads];
/*  18: 51 */     this.doubleValue = new double[this.numThreads];
/*  19: 52 */     this.booleanValue = new boolean[this.numThreads];
/*  20: 54 */     for (int i = 0; i < paramInt; i++) {
/*  21: 55 */       this.isDone[i] = false;
/*  22:    */     }
/*  23:    */   }
/*  24:    */   
/*  25:    */   long doPlusReduce(int paramInt, long paramLong)
/*  26:    */   {
/*  27: 68 */     int j = 3;
/*  28: 69 */     int k = this.isDone[paramInt] == 0 ? 1 : 0;
/*  29: 70 */     while (((paramInt & j) == 0) && (j < this.numThreads << 2))
/*  30:    */     {
/*  31: 71 */       int m = j + 1 >> 2;
/*  32: 72 */       for (int n = 1; (n <= 3) && (paramInt + n * m < this.numThreads); n++)
/*  33:    */       {
/*  34: 73 */         i = this.maxBusyIter;
/*  35: 74 */         while (this.isDone[(paramInt + n * m)] != k)
/*  36:    */         {
/*  37: 75 */           i--;
/*  38: 76 */           if (i == 0)
/*  39:    */           {
/*  40: 77 */             Thread.yield();
/*  41: 78 */             i = this.maxBusyIter;
/*  42:    */           }
/*  43:    */         }
/*  44: 81 */         paramLong += this.longValue[(paramInt + n * m)];
/*  45:    */       }
/*  46: 83 */       j = (j << 2) + 3;
/*  47:    */     }
/*  48: 85 */     this.longValue[paramInt] = paramLong;
/*  49: 86 */     this.isDone[paramInt] = k;
/*  50: 87 */     int i = this.maxBusyIter;
/*  51: 88 */     while (this.isDone[0] != k)
/*  52:    */     {
/*  53: 89 */       i--;
/*  54: 90 */       if (i == 0)
/*  55:    */       {
/*  56: 91 */         Thread.yield();
/*  57: 92 */         i = this.maxBusyIter;
/*  58:    */       }
/*  59:    */     }
/*  60: 95 */     return this.longValue[0];
/*  61:    */   }
/*  62:    */   
/*  63:    */   double doPlusReduce(int paramInt, double paramDouble)
/*  64:    */   {
/*  65:108 */     int j = 3;
/*  66:109 */     int k = this.isDone[paramInt] == 0 ? 1 : 0;
/*  67:110 */     while (((paramInt & j) == 0) && (j < this.numThreads << 2))
/*  68:    */     {
/*  69:111 */       int m = j + 1 >> 2;
/*  70:112 */       for (int n = 1; (n <= 3) && (paramInt + n * m < this.numThreads); n++)
/*  71:    */       {
/*  72:113 */         i = this.maxBusyIter;
/*  73:114 */         while (this.isDone[(paramInt + n * m)] != k)
/*  74:    */         {
/*  75:115 */           i--;
/*  76:116 */           if (i == 0)
/*  77:    */           {
/*  78:117 */             Thread.yield();
/*  79:118 */             i = this.maxBusyIter;
/*  80:    */           }
/*  81:    */         }
/*  82:121 */         paramDouble += this.doubleValue[(paramInt + n * m)];
/*  83:    */       }
/*  84:123 */       j = (j << 2) + 3;
/*  85:    */     }
/*  86:125 */     this.doubleValue[paramInt] = paramDouble;
/*  87:126 */     this.isDone[paramInt] = k;
/*  88:127 */     int i = this.maxBusyIter;
/*  89:128 */     while (this.isDone[0] != k)
/*  90:    */     {
/*  91:129 */       i--;
/*  92:130 */       if (i == 0)
/*  93:    */       {
/*  94:131 */         Thread.yield();
/*  95:132 */         i = this.maxBusyIter;
/*  96:    */       }
/*  97:    */     }
/*  98:135 */     return this.doubleValue[0];
/*  99:    */   }
/* 100:    */   
/* 101:    */   long doMultReduce(int paramInt, long paramLong)
/* 102:    */   {
/* 103:147 */     int j = 3;
/* 104:148 */     int k = this.isDone[paramInt] == 0 ? 1 : 0;
/* 105:149 */     while (((paramInt & j) == 0) && (j < this.numThreads << 2))
/* 106:    */     {
/* 107:150 */       int m = j + 1 >> 2;
/* 108:151 */       for (int n = 1; (n <= 3) && (paramInt + n * m < this.numThreads); n++)
/* 109:    */       {
/* 110:152 */         i = this.maxBusyIter;
/* 111:153 */         while (this.isDone[(paramInt + n * m)] != k)
/* 112:    */         {
/* 113:154 */           i--;
/* 114:155 */           if (i == 0)
/* 115:    */           {
/* 116:156 */             Thread.yield();
/* 117:157 */             i = this.maxBusyIter;
/* 118:    */           }
/* 119:    */         }
/* 120:160 */         paramLong *= this.longValue[(paramInt + n * m)];
/* 121:    */       }
/* 122:162 */       j = (j << 2) + 3;
/* 123:    */     }
/* 124:164 */     this.longValue[paramInt] = paramLong;
/* 125:165 */     this.isDone[paramInt] = k;
/* 126:166 */     int i = this.maxBusyIter;
/* 127:167 */     while (this.isDone[0] != k)
/* 128:    */     {
/* 129:168 */       i--;
/* 130:169 */       if (i == 0)
/* 131:    */       {
/* 132:170 */         Thread.yield();
/* 133:171 */         i = this.maxBusyIter;
/* 134:    */       }
/* 135:    */     }
/* 136:174 */     return this.longValue[0];
/* 137:    */   }
/* 138:    */   
/* 139:    */   double doMultReduce(int paramInt, double paramDouble)
/* 140:    */   {
/* 141:186 */     int j = 3;
/* 142:187 */     int k = this.isDone[paramInt] == 0 ? 1 : 0;
/* 143:188 */     while (((paramInt & j) == 0) && (j < this.numThreads << 2))
/* 144:    */     {
/* 145:189 */       int m = j + 1 >> 2;
/* 146:190 */       for (int n = 1; (n <= 3) && (paramInt + n * m < this.numThreads); n++)
/* 147:    */       {
/* 148:191 */         i = this.maxBusyIter;
/* 149:192 */         while (this.isDone[(paramInt + n * m)] != k)
/* 150:    */         {
/* 151:193 */           i--;
/* 152:194 */           if (i == 0)
/* 153:    */           {
/* 154:195 */             Thread.yield();
/* 155:196 */             i = this.maxBusyIter;
/* 156:    */           }
/* 157:    */         }
/* 158:199 */         paramDouble *= this.doubleValue[(paramInt + n * m)];
/* 159:    */       }
/* 160:201 */       j = (j << 2) + 3;
/* 161:    */     }
/* 162:203 */     this.doubleValue[paramInt] = paramDouble;
/* 163:204 */     this.isDone[paramInt] = k;
/* 164:205 */     int i = this.maxBusyIter;
/* 165:206 */     while (this.isDone[0] != k)
/* 166:    */     {
/* 167:207 */       i--;
/* 168:208 */       if (i == 0)
/* 169:    */       {
/* 170:209 */         Thread.yield();
/* 171:210 */         i = this.maxBusyIter;
/* 172:    */       }
/* 173:    */     }
/* 174:213 */     return this.doubleValue[0];
/* 175:    */   }
/* 176:    */   
/* 177:    */   boolean doAndReduce(int paramInt, boolean paramBoolean)
/* 178:    */   {
/* 179:225 */     int j = 3;
/* 180:226 */     int k = this.isDone[paramInt] == 0 ? 1 : 0;
/* 181:227 */     while (((paramInt & j) == 0) && (j < this.numThreads << 2))
/* 182:    */     {
/* 183:228 */       int m = j + 1 >> 2;
/* 184:229 */       for (int n = 1; (n <= 3) && (paramInt + n * m < this.numThreads); n++)
/* 185:    */       {
/* 186:230 */         i = this.maxBusyIter;
/* 187:231 */         while (this.isDone[(paramInt + n * m)] != k)
/* 188:    */         {
/* 189:232 */           i--;
/* 190:233 */           if (i == 0)
/* 191:    */           {
/* 192:234 */             Thread.yield();
/* 193:235 */             i = this.maxBusyIter;
/* 194:    */           }
/* 195:    */         }
/* 196:238 */         paramBoolean = (paramBoolean) && (this.booleanValue[(paramInt + n * m)] != 0);
/* 197:    */       }
/* 198:240 */       j = (j << 2) + 3;
/* 199:    */     }
/* 200:242 */     this.booleanValue[paramInt] = paramBoolean;
/* 201:243 */     this.isDone[paramInt] = k;
/* 202:244 */     int i = this.maxBusyIter;
/* 203:245 */     while (this.isDone[0] != k)
/* 204:    */     {
/* 205:246 */       i--;
/* 206:247 */       if (i == 0)
/* 207:    */       {
/* 208:248 */         Thread.yield();
/* 209:249 */         i = this.maxBusyIter;
/* 210:    */       }
/* 211:    */     }
/* 212:252 */     return this.booleanValue[0];
/* 213:    */   }
/* 214:    */   
/* 215:    */   boolean doOrReduce(int paramInt, boolean paramBoolean)
/* 216:    */   {
/* 217:264 */     int j = 3;
/* 218:265 */     int k = this.isDone[paramInt] == 0 ? 1 : 0;
/* 219:266 */     while (((paramInt & j) == 0) && (j < this.numThreads << 2))
/* 220:    */     {
/* 221:267 */       int m = j + 1 >> 2;
/* 222:268 */       for (int n = 1; (n <= 3) && (paramInt + n * m < this.numThreads); n++)
/* 223:    */       {
/* 224:269 */         i = this.maxBusyIter;
/* 225:270 */         while (this.isDone[(paramInt + n * m)] != k)
/* 226:    */         {
/* 227:271 */           i--;
/* 228:272 */           if (i == 0)
/* 229:    */           {
/* 230:273 */             Thread.yield();
/* 231:274 */             i = this.maxBusyIter;
/* 232:    */           }
/* 233:    */         }
/* 234:277 */         paramBoolean = (paramBoolean) || (this.booleanValue[(paramInt + n * m)] != 0);
/* 235:    */       }
/* 236:279 */       j = (j << 2) + 3;
/* 237:    */     }
/* 238:281 */     this.booleanValue[paramInt] = paramBoolean;
/* 239:282 */     this.isDone[paramInt] = k;
/* 240:283 */     int i = this.maxBusyIter;
/* 241:284 */     while (this.isDone[0] != k)
/* 242:    */     {
/* 243:285 */       i--;
/* 244:286 */       if (i == 0)
/* 245:    */       {
/* 246:287 */         Thread.yield();
/* 247:288 */         i = this.maxBusyIter;
/* 248:    */       }
/* 249:    */     }
/* 250:291 */     return this.booleanValue[0];
/* 251:    */   }
/* 252:    */   
/* 253:    */   long doBitOrReduce(int paramInt, long paramLong)
/* 254:    */   {
/* 255:303 */     int j = 3;
/* 256:304 */     int k = this.isDone[paramInt] == 0 ? 1 : 0;
/* 257:305 */     while (((paramInt & j) == 0) && (j < this.numThreads << 2))
/* 258:    */     {
/* 259:306 */       int m = j + 1 >> 2;
/* 260:307 */       for (int n = 1; (n <= 3) && (paramInt + n * m < this.numThreads); n++)
/* 261:    */       {
/* 262:308 */         i = this.maxBusyIter;
/* 263:309 */         while (this.isDone[(paramInt + n * m)] != k)
/* 264:    */         {
/* 265:310 */           i--;
/* 266:311 */           if (i == 0)
/* 267:    */           {
/* 268:312 */             Thread.yield();
/* 269:313 */             i = this.maxBusyIter;
/* 270:    */           }
/* 271:    */         }
/* 272:316 */         paramLong |= this.longValue[(paramInt + n * m)];
/* 273:    */       }
/* 274:318 */       j = (j << 2) + 3;
/* 275:    */     }
/* 276:320 */     this.longValue[paramInt] = paramLong;
/* 277:321 */     this.isDone[paramInt] = k;
/* 278:322 */     int i = this.maxBusyIter;
/* 279:323 */     while (this.isDone[0] != k)
/* 280:    */     {
/* 281:324 */       i--;
/* 282:325 */       if (i == 0)
/* 283:    */       {
/* 284:326 */         Thread.yield();
/* 285:327 */         i = this.maxBusyIter;
/* 286:    */       }
/* 287:    */     }
/* 288:330 */     return this.longValue[0];
/* 289:    */   }
/* 290:    */   
/* 291:    */   long doBitXorReduce(int paramInt, long paramLong)
/* 292:    */   {
/* 293:342 */     int j = 3;
/* 294:343 */     int k = this.isDone[paramInt] == 0 ? 1 : 0;
/* 295:344 */     while (((paramInt & j) == 0) && (j < this.numThreads << 2))
/* 296:    */     {
/* 297:345 */       int m = j + 1 >> 2;
/* 298:346 */       for (int n = 1; (n <= 3) && (paramInt + n * m < this.numThreads); n++)
/* 299:    */       {
/* 300:347 */         i = this.maxBusyIter;
/* 301:348 */         while (this.isDone[(paramInt + n * m)] != k)
/* 302:    */         {
/* 303:349 */           i--;
/* 304:350 */           if (i == 0)
/* 305:    */           {
/* 306:351 */             Thread.yield();
/* 307:352 */             i = this.maxBusyIter;
/* 308:    */           }
/* 309:    */         }
/* 310:355 */         paramLong ^= this.longValue[(paramInt + n * m)];
/* 311:    */       }
/* 312:357 */       j = (j << 2) + 3;
/* 313:    */     }
/* 314:359 */     this.longValue[paramInt] = paramLong;
/* 315:360 */     this.isDone[paramInt] = k;
/* 316:361 */     int i = this.maxBusyIter;
/* 317:362 */     while (this.isDone[0] != k)
/* 318:    */     {
/* 319:363 */       i--;
/* 320:364 */       if (i == 0)
/* 321:    */       {
/* 322:365 */         Thread.yield();
/* 323:366 */         i = this.maxBusyIter;
/* 324:    */       }
/* 325:    */     }
/* 326:369 */     return this.longValue[0];
/* 327:    */   }
/* 328:    */   
/* 329:    */   long doBitAndReduce(int paramInt, long paramLong)
/* 330:    */   {
/* 331:381 */     int j = 3;
/* 332:382 */     int k = this.isDone[paramInt] == 0 ? 1 : 0;
/* 333:383 */     while (((paramInt & j) == 0) && (j < this.numThreads << 2))
/* 334:    */     {
/* 335:384 */       int m = j + 1 >> 2;
/* 336:385 */       for (int n = 1; (n <= 3) && (paramInt + n * m < this.numThreads); n++)
/* 337:    */       {
/* 338:386 */         i = this.maxBusyIter;
/* 339:387 */         while (this.isDone[(paramInt + n * m)] != k)
/* 340:    */         {
/* 341:388 */           i--;
/* 342:389 */           if (i == 0)
/* 343:    */           {
/* 344:390 */             Thread.yield();
/* 345:391 */             i = this.maxBusyIter;
/* 346:    */           }
/* 347:    */         }
/* 348:394 */         paramLong &= this.longValue[(paramInt + n * m)];
/* 349:    */       }
/* 350:396 */       j = (j << 2) + 3;
/* 351:    */     }
/* 352:398 */     this.longValue[paramInt] = paramLong;
/* 353:399 */     this.isDone[paramInt] = k;
/* 354:400 */     int i = this.maxBusyIter;
/* 355:401 */     while (this.isDone[0] != k)
/* 356:    */     {
/* 357:402 */       i--;
/* 358:403 */       if (i == 0)
/* 359:    */       {
/* 360:404 */         Thread.yield();
/* 361:405 */         i = this.maxBusyIter;
/* 362:    */       }
/* 363:    */     }
/* 364:408 */     return this.longValue[0];
/* 365:    */   }
/* 366:    */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.runtime.Reducer
 * JD-Core Version:    0.7.0.1
 */