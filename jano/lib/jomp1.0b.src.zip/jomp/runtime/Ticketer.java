/*   1:    */ package jomp.runtime;
/*   2:    */ 
/*   3:    */ class Ticketer
/*   4:    */ {
/*   5: 27 */   private long ticket = 0L;
/*   6:    */   private long add;
/*   7: 32 */   private boolean init = false;
/*   8: 34 */   private Ticketer next = null;
/*   9: 36 */   private boolean isLoopSetup = false;
/*  10:    */   
/*  11:    */   synchronized long issue()
/*  12:    */   {
/*  13: 45 */     return this.ticket++;
/*  14:    */   }
/*  15:    */   
/*  16:    */   synchronized Ticketer reset()
/*  17:    */   {
/*  18: 54 */     if (this.next == null) {
/*  19: 55 */       this.next = new Ticketer();
/*  20:    */     }
/*  21: 57 */     return this.next;
/*  22:    */   }
/*  23:    */   
/*  24:    */   synchronized void initDyn(LoopData paramLoopData)
/*  25:    */   {
/*  26: 66 */     if (!this.init)
/*  27:    */     {
/*  28: 67 */       this.ticket = paramLoopData.start;
/*  29: 68 */       this.add = (paramLoopData.chunkSize * paramLoopData.step);
/*  30: 69 */       this.init = true;
/*  31:    */     }
/*  32:    */   }
/*  33:    */   
/*  34:    */   synchronized void issueDynamic(LoopData paramLoopData)
/*  35:    */   {
/*  36: 79 */     paramLoopData.start = this.ticket;
/*  37: 80 */     this.ticket += this.add;
/*  38: 81 */     paramLoopData.stop = this.ticket;
/*  39:    */   }
/*  40:    */   
/*  41:    */   synchronized boolean issueGuided(LoopData paramLoopData1, LoopData paramLoopData2, int paramInt)
/*  42:    */   {
/*  43: 93 */     if (!this.isLoopSetup)
/*  44:    */     {
/*  45: 94 */       this.ticket = paramLoopData1.start;
/*  46: 95 */       this.isLoopSetup = true;
/*  47:    */     }
/*  48: 97 */     paramLoopData2.start = this.ticket;
/*  49: 98 */     long l1 = (paramLoopData1.stop - this.ticket) / paramLoopData1.step;
/*  50: 99 */     long l2 = l1 / (2 * paramInt);
/*  51:101 */     if (l2 < paramLoopData1.chunkSize) {
/*  52:101 */       l2 = paramLoopData1.chunkSize;
/*  53:    */     }
/*  54:102 */     paramLoopData2.stop = (this.ticket + l2 * paramLoopData1.step);
/*  55:103 */     this.ticket = paramLoopData2.stop;
/*  56:104 */     if (paramLoopData1.step > 0L)
/*  57:    */     {
/*  58:105 */       if (paramLoopData2.start >= paramLoopData1.stop) {
/*  59:105 */         return false;
/*  60:    */       }
/*  61:106 */       if (paramLoopData2.stop >= paramLoopData1.stop)
/*  62:    */       {
/*  63:107 */         paramLoopData2.stop = paramLoopData1.stop;
/*  64:108 */         paramLoopData2.isLast = true;
/*  65:    */       }
/*  66:    */     }
/*  67:    */     else
/*  68:    */     {
/*  69:111 */       if (paramLoopData2.start <= paramLoopData1.stop) {
/*  70:111 */         return false;
/*  71:    */       }
/*  72:112 */       if (paramLoopData2.stop <= paramLoopData1.stop)
/*  73:    */       {
/*  74:113 */         paramLoopData2.stop = paramLoopData1.stop;
/*  75:114 */         paramLoopData2.isLast = true;
/*  76:    */       }
/*  77:    */     }
/*  78:117 */     paramLoopData2.step = paramLoopData1.step;
/*  79:118 */     return true;
/*  80:    */   }
/*  81:    */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.runtime.Ticketer
 * JD-Core Version:    0.7.0.1
 */