/*  1:   */ package jomp.runtime;
/*  2:   */ 
/*  3:   */ public class LoopData
/*  4:   */ {
/*  5:   */   public long start;
/*  6:   */   public long stop;
/*  7:   */   public long step;
/*  8:18 */   public long startStep = 0L;
/*  9:20 */   public boolean isLast = false;
/* 10:22 */   public long chunkSize = 0L;
/* 11:   */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.runtime.LoopData
 * JD-Core Version:    0.7.0.1
 */