/*  1:   */ package jomp.runtime;
/*  2:   */ 
/*  3:   */ public class BusyThread
/*  4:   */   extends Thread
/*  5:   */ {
/*  6:   */   BusyTask mytask;
/*  7:   */   private int myid;
/*  8:   */   
/*  9:   */   BusyThread(int paramInt)
/* 10:   */   {
/* 11:21 */     this.myid = paramInt;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public void run()
/* 15:   */   {
/* 16:   */     for (;;)
/* 17:   */     {
/* 18:30 */       Thread.yield();
/* 19:30 */       if (OMP.isRunning) {
/* 20:   */         break;
/* 21:   */       }
/* 22:   */     }
/* 23:   */     for (;;)
/* 24:   */     {
/* 25:32 */       Thread.yield();
/* 26:33 */       OMP.doGlobalBarrier(this.myid);
/* 27:34 */       if (!OMP.isRunning) {
/* 28:   */         break;
/* 29:   */       }
/* 30:   */       try
/* 31:   */       {
/* 32:36 */         this.mytask.go(this.myid);
/* 33:   */       }
/* 34:   */       catch (Throwable localThrowable)
/* 35:   */       {
/* 36:40 */         OMP.handleException(this.myid, localThrowable);
/* 37:   */       }
/* 38:42 */       OMP.doGlobalBarrier(this.myid);
/* 39:   */     }
/* 40:   */   }
/* 41:   */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.runtime.BusyThread
 * JD-Core Version:    0.7.0.1
 */