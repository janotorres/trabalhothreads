/*  1:   */ package jomp.runtime;
/*  2:   */ 
/*  3:   */ public class NestLock
/*  4:   */ {
/*  5:13 */   private volatile int nestLevel = 0;
/*  6:15 */   private volatile int owner = 0;
/*  7:   */   
/*  8:   */   public synchronized void set()
/*  9:   */   {
/* 10:26 */     int i = OMP.getAbsoluteID();
/* 11:28 */     if (this.owner != i)
/* 12:   */     {
/* 13:29 */       while (this.nestLevel != 0) {
/* 14:   */         try
/* 15:   */         {
/* 16:31 */           wait();
/* 17:   */         }
/* 18:   */         catch (Exception localException) {}
/* 19:   */       }
/* 20:34 */       this.owner = i;
/* 21:   */     }
/* 22:36 */     this.nestLevel += 1;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public synchronized void unset()
/* 26:   */   {
/* 27:48 */     this.nestLevel -= 1;
/* 28:49 */     if (this.nestLevel == 0) {
/* 29:49 */       notify();
/* 30:   */     }
/* 31:   */   }
/* 32:   */   
/* 33:   */   public synchronized boolean test()
/* 34:   */   {
/* 35:62 */     int i = OMP.getAbsoluteID();
/* 36:64 */     if ((this.nestLevel != 0) && (this.owner != i)) {
/* 37:65 */       return false;
/* 38:   */     }
/* 39:67 */     this.owner = i;
/* 40:68 */     this.nestLevel += 1;
/* 41:69 */     return true;
/* 42:   */   }
/* 43:   */ }


/* Location:           C:\Users\Usuario\git\trabalhothreads\jano\lib\jomp1.0b.jar
 * Qualified Name:     jomp.runtime.NestLock
 * JD-Core Version:    0.7.0.1
 */